// // ignore_for_file: dead_code, non_constant_identifier_names
// import 'package:blockchain_utils/blockchain_utils.dart';
// import 'package:blockchain_utils/utils/binary/utils.dart';
// import 'package:monero_dart/src/exception/exception.dart';
// import 'package:monero_dart/src/models/transaction/transaction/transaction.dart';
// import 'package:monero_dart/src/network/config.dart';
// import 'package:monero_dart/src/provider/methods/binary/get_block_by_height.dart';
// import 'package:monero_dart/src/provider/methods/json/send_raw_transaction.dart';
// import 'package:monero_dart/src/provider/methods/json_rpc/estimate_fee.dart';
// import 'package:monero_dart/src/provider/methods/json/get_height.dart';
// import 'package:monero_dart/src/provider/methods/json_rpc/get_info.dart';
// import 'package:monero_dart/src/provider/methods/binary/get_o_indicies.dart';
// import 'package:monero_dart/src/provider/methods/binary/get_output_distribution_bin.dart';
// import 'package:monero_dart/src/provider/methods/binary/get_outs.dart';
// import 'package:monero_dart/src/provider/methods/json_rpc/get_output_distribution.dart';
// import 'package:monero_dart/src/provider/methods/json_rpc/get_transactions.dart';
// import 'package:monero_dart/src/provider/methods/json_rpc/hard_fork.dart';
// import 'package:monero_dart/src/provider/models/models/distribution.dart';
// import 'package:monero_dart/src/provider/models/models/fee_estimate.dart';
// import 'package:monero_dart/src/provider/models/models/get_info.dart';
// import 'package:monero_dart/src/provider/models/models/get_out_response.dart';
// import 'package:monero_dart/src/provider/models/models/hard_fork.dart';
// import 'package:monero_dart/src/provider/models/models/request.dart';
// import 'package:monero_dart/src/provider/provider/provider.dart';

// import '../junk/provider_test.dart';

// MoneroProvider? _provider;
// Future<bool> use_fork_rules(int version, int earlyBlocks) async {
//   final height = await getHeight();
//   final earliestHeight = await getEarliestHeight();
//   final bool closeEnough = height >= earliestHeight - earlyBlocks;
//   return closeEnough;
// }

// // int? _m_upper_transaction_weight_limit;
// Future<int> get_upper_transaction_weight_limit() async {
//   // if (_m_upper_transaction_weight_limit != null) {
//   //   return _m_upper_transaction_weight_limit!;
//   // }
//   int full_reward_zone = (await use_fork_rules(5, 10))
//       ? MoneroConst.cryptonoteBlockGrantedFullRewardZoneV5
//       : (await use_fork_rules(2, 10))
//           ? MoneroConst.cryptonoteBlockGrantedFullRewardZoneV2
//           : MoneroConst.cryptonoteBlockGrantedFullRewardZoneV1;
//   if (await use_fork_rules(8, 10)) {
//     return full_reward_zone ~/ 2 -
//         MoneroConst.cryptonoteCoinbaseBlobReservedSize;
//   } else {
//     return full_reward_zone - MoneroConst.cryptonoteCoinbaseBlobReservedSize;
//   }
// }

// BigInt? _m_dynamic_base_fee_estimate;
// int? _m_dynamic_base_fee_estimate_cached_height;
// int? _m_dynamic_base_fee_estimate_grace_blocks;
// List<BigInt>? _m_dynamic_base_fee_estimate_vector;
// BigInt? _m_fee_quantization_mask;
// Future<List<BigInt>> get_dynamic_base_fee_estimate_2021_scaling(
//     int grace_blocks) async {
//   int height = await getHeight();

//   if (_m_dynamic_base_fee_estimate_cached_height != height ||
//       _m_dynamic_base_fee_estimate_grace_blocks != grace_blocks) {
//     final estimate = await getEstimateFee();

//     _m_dynamic_base_fee_estimate = estimate.fee;
//     _m_dynamic_base_fee_estimate_cached_height = height;
//     _m_dynamic_base_fee_estimate_grace_blocks = grace_blocks;
//     _m_dynamic_base_fee_estimate_vector =
//         estimate.fees.isNotEmpty ? estimate.fees : [estimate.fee];
//     _m_fee_quantization_mask = estimate.quantizationMask;
//   }
//   return _m_dynamic_base_fee_estimate_vector!;
//   // fees = m_dynamic_base_fee_estimate_vector;
//   // return boost::optional<std::string>();
// }

// Future<BigInt> _get_fee_quantization_mask() async {
//   final height = await getHeight();
//   if (_m_dynamic_base_fee_estimate_cached_height != height) {
//     final estimate = await getEstimateFee();

//     _m_dynamic_base_fee_estimate = estimate.fee;
//     _m_dynamic_base_fee_estimate_cached_height = height;
//     _m_fee_quantization_mask = estimate.quantizationMask;
//   }
//   if (_m_fee_quantization_mask! == BigInt.zero) {
//     return BigInt.one;
//   }
//   return _m_fee_quantization_mask!;
// }

// Future<BigInt> get_fee_quantization_mask() async {
//   bool use_per_byte_fee =
//       await use_fork_rules(MoneroConst.hfVersionPerByteFee, 0);
//   if (!use_per_byte_fee) {
//     return BigInt.one;
//   }
//   return _get_fee_quantization_mask();
// }

// Future<BigInt> _get_dynamic_base_fee_estimate(int grace_blocks) async {
//   final fee = await get_dynamic_base_fee_estimate_2021_scaling(grace_blocks);
//   return fee.first;
// }

// const int FEE_ESTIMATE_GRACE_BLOCKS = 10;
// Future<BigInt> get_dynamic_base_fee_estimate() async {
//   final fee = await _get_dynamic_base_fee_estimate(FEE_ESTIMATE_GRACE_BLOCKS);
//   return fee;
// }

// Future<int> get_fee_algorithm() async {
//   // changes at v3, v5, v8
//   if (await use_fork_rules(MoneroConst.hfVersionPerByteFee, 0)) return 3;
//   if (await use_fork_rules(5, 0)) return 2;
//   if (await use_fork_rules(3, -30 * 14)) return 1;
//   return 0;
// }

// int get_bulletproof_fork() {
//   return MoneroConst.hfVersionBulletProof;
// }

// int get_bulletproof_plus_fork() {
//   return MoneroConst.hfVersionBulletProofPlus;
// }

// int get_clsag_fork() {
//   return MoneroConst.hfVersionClsag;
// }

// int get_view_tag_fork() {
//   return MoneroConst.hfVersionViewTags;
// }

// class Multipliers {
//   final int count;
//   final List<int> multipliers;
//   const Multipliers({required this.count, required this.multipliers});
// }

// Future<int> get_fee_multiplier(int priority, int fee_algorithm) async {
//   final List<Multipliers> multipliers = [
//     Multipliers(count: 3, multipliers: [1, 2, 3]),
//     Multipliers(count: 3, multipliers: [1, 20, 166]),
//     Multipliers(count: 4, multipliers: [1, 4, 20, 166]),
//     Multipliers(count: 4, multipliers: [1, 5, 25, 1000])
//   ];
//   if (fee_algorithm == -1) {
//     fee_algorithm = await get_fee_algorithm();
//   }
//   if (priority == 0) {
//     if (fee_algorithm >= 2) {
//       priority = 2;
//     } else {
//       priority = 1;
//     }
//   }
//   if (fee_algorithm < 0 || fee_algorithm > 3) {
//     throw DartMoneroPluginException("invalid_priority");
//   }
//   final int max_priority = multipliers[fee_algorithm].count;
//   if (priority >= 1 && priority <= max_priority) {
//     return multipliers[fee_algorithm].multipliers[priority - 1];
//   }
//   throw DartMoneroPluginException("invalid_priority");
// }

// Future<BigInt> _getBaseFee() async {
//   bool use_dyn_fee =
//       await use_fork_rules(MoneroConst.hfVersionDynamicFee, -30 * 1);
//   if (!use_dyn_fee) {
//     return BigInt.from(MoneroConst.feePerKb);
//   }
//   return await get_dynamic_base_fee_estimate();
// }

// Future<BigInt> getBaseFee({int priority = 1}) async {
//   bool use_2021_scaling =
//       await use_fork_rules(MoneroConst.hfVersion2021Scaling, -30 * 1);
//   if (use_2021_scaling) {
//     final fee = await get_dynamic_base_fee_estimate_2021_scaling(
//         FEE_ESTIMATE_GRACE_BLOCKS);
//     return fee.first;
//   } else {
//     final baseFee = await _getBaseFee();
//     final m = await get_fee_multiplier(priority, -1);
//     return baseFee * BigInt.from(m);
//   }
//   // final fee = await get_dynamic_base_fee_estimate_2021_scaling(
//   //     FEE_ESTIMATE_GRACE_BLOCKS);
//   // return fee.first;
// }

// Future<int> getHeight() async {
//   final provider = createProvider();
//   final height = await provider.request(DaemonRequestGetHeight());
//   return height.height;
// }

// int? _earliestHeight;
// Future<int> getEarliestHeight() async {
//   if (_earliestHeight != null) return _earliestHeight!;
//   final provider = createProvider();
//   final height = await provider.request(DaemonRequestHardForkInfo());
//   _earliestHeight = height.earliestHeight;
//   return _earliestHeight!;
// }

// Future<List<BigInt>> getAllDistribution({bool compress = true}) async {
//   final distributions =
//       await getOutputDistribution([BigInt.zero], compress: compress);
//   List<BigInt> offsets =
//       List<BigInt>.from(distributions.distributions[0].distribution);
//   for (int i = 1; i < offsets.length; i++) {
//     offsets[i] = offsets[i] + offsets[i - 1];
//   }
//   return offsets;
// }

// Future<void> getBlockByHeight(List<BigInt> heights) async {
//   final provider = createProvider();
//   final getTx =
//       await provider.request(DaemonRequestGetBlocksByHeightBin(heights));
//   print(getTx);
// }

// Future<GetOutResponse> getOuts(List<DaemonGetOutRequestParams> outputs) async {
//   final provider = createProvider();
//   final outs = await provider
//       .request(DaemonRequestGetOuts(outputs: outputs, getTxId: false));
//   return outs;
// }


// /// DaemonRequestSendRawTransaction
// Future<MoneroTransaction> getSingleTx(String txId) async {
//   final provider = createProvider();
//   final getTx = await provider.request(DaemonRequestGetTransactions([txId],
//       prune: false, decodeAsJson: true, split: false));
//   print(getTx[0].outoutIndices);

//   return getTx[0].toTx();
// }

// Future<void> sendTransaction(MoneroTransaction tx) async {
//   final txAsHex = tx.serialize();
//   print("serializelen ${txAsHex.length}");
//   final provider = createProvider();
//   final response = await provider.request(DaemonRequestSendRawTransaction(
//       txAsHex: BytesUtils.toHexString(txAsHex), doNotRelay: false));
//   print(response);
// }

// Future<DaemonGetInfoResponse> getInfo() async {
//   final provider = createProvider();
//   final info = await provider.request(DaemonRequestGetInfo());
//   return info;
// }

// Future<DaemonGetEstimateFeeResponse> getEstimateFee() async {
//   final provider = createProvider();
//   final info = await provider.request(DaemonRequestGetFeeEstimate(0));
//   return info;
// }

// Future<DaemonHardForkResponse> getHardFork() async {
//   final provider = createProvider();
//   final info = await provider.request(DaemonRequestHardForkInfo());
//   return info;
// }

// Future<void> getOIndexses(String txId) async {
//   final provider = createProvider();
//   final getTx = await provider.request(DaemonRequestGetOIndexes(txId));
//   print(getTx);
// }

// List<BigInt> _decodeRctOffsets(List<BigInt> offsets) {
//   // int offset = 0;
//   // List<BigInt> offsets = [];
//   // BigInt result = BigInt.zero;
//   // int shift = 0;
//   // while (distribution.length > offset) {
//   //   int byte = distribution[offset];
//   //   offset++;

//   //   result |= BigInt.from((byte & 0x7F)) << shift;
//   //   shift += 7;
//   //   if ((byte & 0x80) == 0) {
//   //     offsets.add(result);
//   //     result = BigInt.zero;
//   //     shift = 0;
//   //     continue;
//   //   }
//   // }
//   for (int i = 1; i < offsets.length; i++) {
//     offsets[i] = offsets[i] + offsets[i - 1];
//   }
//   return offsets;
// }

// Future<OutputDistributionResponse> getOutputDistribution(List<BigInt> amounts,
//     {bool compress = true}) async {
//   final provider = createProvider();
//   return await provider.request(
//       DaemonRequestGetOutputDistribution(amounts: amounts, binary: true));
// }
