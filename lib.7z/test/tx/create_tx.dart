// // ignore_for_file: non_constant_identifier_names, unused_local_variable

// import 'package:blockchain_utils/bip/address/xmr_addr.dart';
// import 'package:blockchain_utils/blockchain_utils.dart';
// import 'package:monero_dart/src/address/address/address.dart';
// import 'package:monero_dart/src/crypto/models/ct_key.dart';
// import 'package:monero_dart/src/crypto/monero/crypto.dart';
// import 'package:monero_dart/src/crypto/ringct/utils/generator.dart';
// import 'package:monero_dart/src/crypto/ringct/utils/rct_crypto.dart';
// import 'package:monero_dart/src/crypto/types/types.dart';
// import 'package:monero_dart/src/exception/exception.dart';
// import 'package:monero_dart/src/helper/transaction.dart';
// import 'package:monero_dart/src/models/rtc/signature.dart';
// import 'package:monero_dart/src/models/test/output_info.dart';
// import 'package:monero_dart/src/models/transaction/input/input.dart';
// import 'package:monero_dart/src/models/transaction/output/output.dart';
// import 'package:monero_dart/src/models/transaction/transaction/extra.dart';
// import 'package:monero_dart/src/models/transaction/transaction/prefix.dart';
// import 'package:monero_dart/src/models/transaction/transaction/transaction.dart';
// import 'package:monero_dart/src/network/config.dart';

// import 'create_tx_methods.dart';
// import 'methods_test.dart';
// import 'models.dart';
// import 'n_models.dart';
// import 'rpc_methods.dart';

// // bool use_fork_rules(int version, BigInt early_blocks)
// // {
// //   BigInt height, earliest_height = BigInt.zero;
// //   boost::optional<std::string> result = m_node_rpc_proxy.get_height(height);
// //   THROW_WALLET_EXCEPTION_IF(result, error::wallet_internal_error, "Failed to get height");
// //   result = m_node_rpc_proxy.get_earliest_height(version, earliest_height);
// //   THROW_WALLET_EXCEPTION_IF(result, error::wallet_internal_error, "Failed to get earliest fork height");

// //   bool close_enough = (int64_t)height >= (int64_t)earliest_height - early_blocks && earliest_height != std::numeric_limits<uint64_t>::max(); // start using the rules that many blocks beforehand
// //   if (close_enough)
// //     LOG_PRINT_L2("Using v" << (unsigned)version << " rules");
// //   else
// //     LOG_PRINT_L2("Not using v" << (unsigned)version << " rules");
// //   return close_enough;
// // }

// Future<void> createTransation({
//   required List<tx_destination_entry> dsts,
//   List<TransferTx> selectedTransafers = const [],
//   required int fake_outs_count,
//   required int priority,
//   required List<int> extra,
//   required int subaddr_account,
//   required Set<int> subaddr_indices,
//   required Set<int> unique_index_container,
//   Set<int> subtract_fee_from_outputs = const {},
// }) async {
//   List<TestTx> txes = [];
//   bool adding_fee = false;
//   BigInt needed_fee, available_for_fee = BigInt.zero;

//   int upper_transaction_weight_limit =
//       await get_upper_transaction_weight_limit();
//   final bool use_per_byte_fee =
//       await use_fork_rules(MoneroConst.hfVersionPerByteFee, 0);
//   final bool use_rct = await use_fork_rules(4, 0);
//   final bool bulletproof = await use_fork_rules(get_bulletproof_fork(), 0);
//   final bool bulletproof_plus =
//       await use_fork_rules(get_bulletproof_plus_fork(), 0);
//   final bool clsag = await use_fork_rules(get_clsag_fork(), 0);
//   final bool use_view_tags = await use_fork_rules(get_view_tag_fork(), 0);

//   List<MPublicKey> valid_public_keys_cache = [];
//   final baseFee = await getBaseFee(priority: priority);
//   BigInt fee_quantization_mask = await get_fee_quantization_mask();
//   print(fee_quantization_mask);
//   print(baseFee);

//   // if(substrac)
//   if (dsts.isEmpty) {
//     throw DartMoneroPluginException("zero_destination");
//   }
//   if (subtract_fee_from_outputs.isNotEmpty &&
//       subtract_fee_from_outputs.last >= dsts.length) {
//     throw DartMoneroPluginException(
//         'subtract_fee_from_bad_index: ${subtract_fee_from_outputs.last}');
//   }
//   if (subtract_fee_from_outputs.isNotEmpty &&
//       dsts.length > MoneroConst.bulletproofMaxOutputs - 1) {
//     throw DartMoneroPluginException(
//         "subtractfeefrom transfers cannot be split over multiple transactions yet");
//   }
//   BigInt needed_money = dsts.fold(BigInt.zero, (p, c) => p + c.amount);
//   final int minSize = estimate_tx_size(use_rct, 1, fake_outs_count, 2,
//       extra.length, bulletproof, clsag, bulletproof_plus, use_view_tags);
//   final BigInt min_fee = baseFee * BigInt.from(minSize);

//   BigInt total_needed_money = needed_money + min_fee;
//   BigInt unlocked_balance_subtotal = BigInt.zero;
//   BigInt balance_subtotal = BigInt.zero;
//   for (final i in selectedTransafers) {
//     balance_subtotal += i.outInfo.amount;
//     if (!i.isUnlocked) continue;
//     unlocked_balance_subtotal += i.outInfo.amount;
//   }

//   if (total_needed_money > unlocked_balance_subtotal ||
//       min_fee > unlocked_balance_subtotal) {
//     throw DartMoneroPluginException("not enough money");
//   }
//   final int tx_weight_one_ring = estimate_tx_weight(use_rct, 1, fake_outs_count,
//       2, 0, bulletproof, clsag, bulletproof_plus, use_view_tags);
//   final int tx_weight_two_rings = estimate_tx_weight(
//       use_rct,
//       2,
//       fake_outs_count,
//       2,
//       0,
//       bulletproof,
//       clsag,
//       bulletproof_plus,
//       use_view_tags);
//   final int tx_weight_per_ring = tx_weight_two_rings - tx_weight_one_ring;
//   final BigInt fractional_threshold =
//       (baseFee * BigInt.from(tx_weight_per_ring)) ~/
//           BigInt.from((use_per_byte_fee ? 1 : 1024));

//   int numNonDustOutputs = 0;
//   int numDustOutputs = 0;
//   Map<int, BigInt> balance_per_subaddr = {};
//   Map<int, BigInt> unlocked_balance_per_subaddr = {};
//   for (final i in selectedTransafers) {
//     if (balance_per_subaddr.containsKey(i.subAddress.minor)) {
//       balance_per_subaddr[i.subAddress.minor] =
//           balance_per_subaddr[i.subAddress.minor]! + i.outInfo.amount;
//     } else {
//       balance_per_subaddr[i.subAddress.minor] = i.outInfo.amount;
//     }
//   }
//   unlocked_balance_per_subaddr.addAll(balance_per_subaddr);

//   Map<int, List<TransferTx>> unused_transfers_indices_per_subaddr = {};
//   Map<int, List<TransferTx>> unused_dust_indices_per_subaddr = {};
//   for (final td in selectedTransafers) {
//     if ((use_rct || !td.isRCT) &&
//         td.isUnlocked &&
//         td.outInfo.isSubaddress &&
//         subaddr_account == td.subAddress.major &&
//         (td.subAddress.minor == 0 ||
//             subaddr_indices.contains(td.subAddress.minor))) {
//       int indexMinor = td.subAddress.minor;
//       bool isRingCt = td.isRCT;
//       if (isRingCt) {
//         if (!unused_transfers_indices_per_subaddr.containsKey(indexMinor)) {
//           unused_transfers_indices_per_subaddr[indexMinor] = [td];
//         } else {
//           unused_transfers_indices_per_subaddr[indexMinor]!.add(td);
//         }
//         numNonDustOutputs++;
//       } else {
//         if (!unused_dust_indices_per_subaddr.containsKey(indexMinor)) {
//           unused_dust_indices_per_subaddr[indexMinor] = [td];
//         } else {
//           unused_dust_indices_per_subaddr[indexMinor]!.add(td);
//         }
//         numDustOutputs++;
//       }
//     }
//   }
//   if (unused_transfers_indices_per_subaddr.isEmpty &&
//       unused_dust_indices_per_subaddr.isEmpty) {
//     throw DartMoneroPluginException("not enough money");
//   }
//   print("need fee $min_fee");
// }

// Future<MoneroTransaction> createTransfer(
//     {required List<TransferTx> selectedTransfers,
//     required List<tx_destination_entry> destinations,
//     MoneroAddress? changeAddr}) async {
//   final outs = await getOutputs(
//       selectedTransafers: selectedTransfers, fake_outputs_count: 15);
//   List<SourceEntry> sources = [];
//   // constructTx(destinations: outs, sources: sources);
//   for (int i = 0; i < selectedTransfers.length; i++) {
//     final sourceOuts = outs.item1[i];
//     final index = sourceOuts
//         .indexWhere((e) => e.index == selectedTransfers[i].outInfo.globalIndex);
//     if (index.isNegative) {
//       throw DartMoneroPluginException("Index not found.");
//     }
//     final source = SourceEntry(
//         transferTx: selectedTransfers[i],
//         outs: sourceOuts
//             .map((e) => OutsEntery(
//                 index: e.index, key: CtKey(dest: e.publicKey, mask: e.mask)))
//             .toList(),
//         realOutIndex: index);
//     sources.add(source);
//   }
//   return constructTx(
//       destinations: destinations, sources: sources, changeAddr: changeAddr);
// }

// List<BigInt> absoluteOutputOffsetsToRelative(List<BigInt> off) {
//   List<BigInt> res = List.from(off); // Copy the input list

//   if (res.isEmpty) {
//     return res;
//   }

//   res.sort(); // Sort the list to ensure order

//   // Convert to relative offsets
//   for (int i = res.length - 1; i > 0; i--) {
//     res[i] -= res[i - 1];
//   }

//   return res;
// }

// class TransactionClassifyAddresses {
//   final int num_stdaddresses;
//   final int num_subaddresses;
//   final MoneroAddress? single_dest_subaddress;
//   const TransactionClassifyAddresses(
//       {required this.num_stdaddresses,
//       required this.num_subaddresses,
//       required this.single_dest_subaddress});
// }

// TransactionClassifyAddresses classify_addresses(
//   List<tx_destination_entry> destinations,
//   MoneroAddress? changeAddr,
// ) {
//   int num_stdaddresses = 0;
//   int num_subaddresses = 0;
//   MoneroAddress? single_dest_subaddress;
//   List<MoneroAddress> unique_dst_addresses = [];
//   for (final i in destinations) {
//     if (changeAddr != null && i.address == changeAddr) {
//       continue;
//     }
//     if (!unique_dst_addresses.contains(i.address)) {
//       unique_dst_addresses.add(i.address);
//       if (i.address.type == XmrAddressType.subaddress) {
//         ++num_subaddresses;
//         single_dest_subaddress = i.address;
//       } else {
//         ++num_stdaddresses;
//       }
//     }
//   }
//   return TransactionClassifyAddresses(
//       num_stdaddresses: num_stdaddresses,
//       num_subaddresses: num_subaddresses,
//       single_dest_subaddress: num_stdaddresses == 0 && num_subaddresses == 1
//           ? single_dest_subaddress
//           : null);
// }

// MoneroTransaction constructTx({
//   required List<tx_destination_entry> destinations,
//   required List<SourceEntry> sources,
//   MoneroAddress? changeAddr,
// }) {
//   RctKey txKey = MoneroCrypto.generateKeys().secretKey;
//   // BytesUtils.fromHexString(
//   //     "c936d68c9d112a9d73bd99f88933782a8b8174859c2df613a9daa99f2e0e5d0b");

//   /// MoneroCrypto.generateKeys().secretKey;
//   RctKey txPubKey = RCT.zero();

//   List<RctKey> additionalTxPubKey = [];

//   /// if(multiple destination.);
//   List<RctKey> amountKeys = [];
//   const int txVersion = 2;
//   BigInt unlockTIme = BigInt.zero;
//   List<TxExtra> extras = [];
//   tx_destination_entry? unknowSingleAccount;
//   final unknowDsts = destinations.where((e) => e.address != changeAddr);
//   if (unknowDsts.length == 1) {
//     List<int> paymentId = List<int>.filled(8, 0);
//     paymentId = MoneroTransactionHelper.encryptPaymentId(
//         paymentId: paymentId,
//         pubKey: unknowDsts.first.address.pubViewKey.compressed,
//         secretKey: txKey);
//     final extra = TxExtraNonce.encryptedPaymentId(paymentId);
//     extras.add(extra);
//     print("extra has been added!");
//   }

//   // List<MKeyPair> inContext = [];
//   BigInt inputAmouts = BigInt.zero;
//   List<TxinToKey> vin = [];
//   for (final i in sources) {
//     inputAmouts += i.transferTx.outInfo.amount;
//     final txin = TxinToKey(
//         amount: i.transferTx.outInfo.amount,
//         keyOffsets: absoluteOutputOffsetsToRelative(
//             i.outs.map((e) => e.index).toList()),
//         keyImage: i.transferTx.outInfo.keyImage);
//     vin.add(txin);
//   }
//   final cl = classify_addresses(destinations, changeAddr);
//   if (cl.single_dest_subaddress != null) {
//     txPubKey = RCT.scalarmultKey_(
//         cl.single_dest_subaddress!.pubSpendKey.compressed, txKey);
//     print("tx pubkey here !");
//   } else {
//     txPubKey = RCT.scalarmultBase_(txKey);
//   }
//   List<MoneroTxout> vouts = [];
//   extras.add(TxExtraPublicKey(txPubKey));
//   int outIndex = 0;
//   for (final i in destinations) {
//     final key = MoneroTransactionHelper.generateOutputEpemeralKeys(
//         txSecretKey: txKey,
//         address: i.address,
//         outIndex: outIndex,
//         useViewTag: true);
//     outIndex++;
//     vouts.add(MoneroTxout(amount: i.amount, target: key.item1));
//     amountKeys.add(key.item2);
//   }
//   if (txVersion == 1) {
//     throw UnimplementedError();
//   } else {
//     int n_total_outs = sources[0].outs.length;
//     // || rct_config.range_proof_type != rct::RangeProofBorromean
//     bool use_simple_rct = sources.length > 1 || true;
//     if (!use_simple_rct) {
//       for (final i in sources) {
//         if (i.realOutIndex != sources[0].realOutIndex) {
//           throw DartMoneroPluginException(
//               "All inputs must have the same index for non-simple ringct");
//         }
//       }
//       for (int i = 1; i < sources.length; ++i) {
//         if (n_total_outs != sources[i].outs.length) {
//           throw DartMoneroPluginException(
//               "Non-simple ringct transaction has varying ring size");
//         }
//       }
//     }

//     BigInt amount_in = BigInt.zero, amount_out = BigInt.zero;
//     CtKeyV inSk = [];
//     // inSk.reserve(sources.size());
//     // mixRing indexing is done the other way round for simple
//     ///  CtKeyM mixRing(use_simple_rct ? sources.size() : n_total_outs)
//     CtKeyM mixRing = List.generate(
//         use_simple_rct ? sources.length : n_total_outs, (i) => []);
//     KeyV destinationsKeys = [];
//     List<BigInt> inamounts = [], outamounts = [];
//     List<int> index = [];
//     for (final i in sources) {
//       amount_in += i.transferTx.outInfo.amount;
//       inamounts.add(i.transferTx.outInfo.amount);
//       index.add(i.realOutIndex);
//       final ctkey = CtKey(
//           dest: i.transferTx.outInfo.ephemeralSecretKey,
//           mask: i.transferTx.outInfo.mask);
//       inSk.add(ctkey);
//     }
//     for (final i in vouts) {
//       final pk = i.target.getPublicKey();
//       destinationsKeys.add(pk!.clone());
//       outamounts.add(i.amount);
//       amount_out += i.amount;
//     }

//     if (use_simple_rct) {
//       for (int i = 0; i < sources.length; ++i) {
//         for (int n = 0; n < sources[i].outs.length; ++n) {
//           mixRing[i].add(sources[i].outs[n].key);
//         }
//       }
//     } else {
//       for (int i = 0; i < n_total_outs; ++i) // same index assumption
//       {
//         for (int n = 0; n < sources.length; ++n) {
//           mixRing[i][n] = sources[n].outs[i].key;
//         }
//       }
//     }
//     print("use simple $use_simple_rct");
//     if (!use_simple_rct && amount_in > amount_out) {
//       outamounts.add(amount_in - amount_out);
//     }
//     for (int i = 0; i < vin.length; ++i) {
//       if (sources[i].transferTx.isRCT) {
//         vin[i] = vin[i].copyWith(amount: BigInt.zero);
//       }
//     }
//     vouts = vouts.map((e) => e.copyWith(amount: BigInt.zero)).toList();
//     final tx = MoneroTransactionPrefix(
//         version: txVersion,
//         unlockTime: unlockTIme,
//         vin: vin,
//         vout: vouts,
//         extra: MoneroTransactionHelper.toTxExtra(extras));
//     final tx_prefix_hash = tx.getTranactionPrefixHash();

//     CtKeyV outSk = List.generate(
//         destinations.length, (_) => CtKey(dest: RCT.zero(), mask: RCT.zero()));
//     RCTSignature sig = RCTGeneratorUtils.genRctSimple(
//         tx_prefix_hash,
//         inSk,
//         destinationsKeys,
//         inamounts,
//         outamounts,
//         amount_in - amount_out,
//         mixRing,
//         amountKeys,
//         index,
//         outSk,
//         RangeProofType.RangeProofPaddedBulletproof,
//         4);
//     print("destination ${destinationsKeys.length} ${amountKeys.length}");
//     return MoneroTransaction(
//         version: txVersion,
//         unlockTime: unlockTIme,
//         vin: vin,
//         vout: vouts,
//         extra: MoneroTransactionHelper.toTxExtra(extras),
//         signature: sig);
//     // print("fee $fee");
//     // // return;
//     // if (true) {
//     //   sig = ;
//     // }
//     print("done $sig");
//   }

//   // std::vector<unsigned int> index;
// }
