// import 'package:blockchain_utils/blockchain_utils.dart';
// import 'package:monero_dart/src/crypto/models/ct_key.dart';
// import 'package:monero_dart/src/crypto/types/types.dart';
// import 'package:monero_dart/src/models/transaction/signature/signature.dart';

// class OutputEntry {
//   final BigInt index;
//   final CtKey key;
//   const OutputEntry({required this.index, required this.key});
// }

// class MultisigKLRki {
//   final RctKey k;
//   final RctKey L;
//   final RctKey R;
//   final RctKey ki;
//   MultisigKLRki({
//     required RctKey k,
//     required RctKey L,
//     required RctKey R,
//     required RctKey ki,
//   })  : k = k.asImmutableBytes,
//         L = L.asImmutableBytes,
//         R = R.asImmutableBytes,
//         ki = ki.asImmutableBytes;
// }

// class MultisigOut {
//   List<RctKey> c;
//   List<RctKey> muP;
//   List<RctKey> c0;
//   MultisigOut({
//     required List<RctKey> c,
//     required List<RctKey> muP,
//     required List<RctKey> c0,
//   })  : c = c.map((e) => e.asImmutableBytes).toList().immutable,
//         muP = muP.map((e) => e.asImmutableBytes).toList().immutable,
//         c0 = c0.map((e) => e.asImmutableBytes).toList().immutable;
// }

// class MultisigSig {
//   final RCTSignature sigs;
//   final Set<MPublicKey> ignore;
//   final Set<RctKey> usedL;
//   final Set<MPublicKey> signingKeys;
//   final MultisigOut msout;
//   final KeyM totalAlphaG;
//   final KeyM totalAlphaH;
//   final KeyV c0;
//   final KeyV s;
//   MultisigSig(
//       {required this.sigs,
//       required Set<MPublicKey> ignore,
//       required Set<RctKey> usedL,
//       required Set<MPublicKey> signingKeys,
//       required this.msout,
//       required KeyM totalAlphaG,
//       required KeyM totalAlphaH,
//       required KeyV c0,
//       required KeyV s})
//       : ignore = ignore.map((e) => e.asImmutableBytes).toImutableSet,
//         usedL = usedL.map((e) => e.asImmutableBytes).toImutableSet,
//         signingKeys = signingKeys.map((e) => e.asImmutableBytes).toImutableSet,
//         totalAlphaG = totalAlphaG
//             .map((e) => e.map((d) => d.asImmutableBytes).toImutableList)
//             .toImutableList,
//         totalAlphaH = totalAlphaG
//             .map((e) => e.map((d) => d.asImmutableBytes).toImutableList)
//             .toImutableList,
//         c0 = c0.map((e) => e.asImmutableBytes).toImutableList,
//         s = s.map((e) => e.asImmutableBytes).toImutableList;
// }
