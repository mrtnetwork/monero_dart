// // ignore_for_file: constant_identifier_names

// const int APPROXIMATE_INPUT_BYTES = 80;
// int estimateRctTxSize(int nInputs, int mixin, int nOutputs, int extraSize,
//     bool bulletproof, bool clsag, bool bulletproofPlus, bool useViewTags) {
//   int size = 0;

//   // tx prefix

//   // first few bytes
//   size += 1 + 6;

//   // vin
//   size += nInputs * (1 + 6 + (mixin + 1) * 2 + 32);

//   // vout
//   size += nOutputs * (6 + 32);

//   // extra
//   size += extraSize;

//   // rct signatures

//   // type
//   size += 1;

//   // rangeSigs
//   if (bulletproof || bulletproofPlus) {
//     int logPaddedOutputs = 0;
//     while ((1 << logPaddedOutputs) < nOutputs) {
//       logPaddedOutputs++;
//     }
//     size +=
//         (2 * (6 + logPaddedOutputs) + (bulletproofPlus ? 6 : (4 + 5))) * 32 + 3;
//   } else {
//     size += (2 * 64 * 32 + 32 + 64 * 32) * nOutputs;
//   }

//   // MGs/CLSAGs
//   if (clsag) {
//     size += nInputs * (32 * (mixin + 1) + 64);
//   } else {
//     size += nInputs * (64 * (mixin + 1) + 32);
//   }

//   // View tags
//   if (useViewTags) {
//     size += nOutputs * 1; // Assuming crypto::view_tag is 1 byte in size
//   }

//   // pseudoOuts
//   size += 32 * nInputs;

//   // ecdhInfo
//   size += 8 * nOutputs;

//   // outPk - only commitment is saved
//   size += 32 * nOutputs;

//   // txnFee
//   size += 4;

//   return size;
// }

// int estimate_tx_size(
//     bool useRct,
//     int nInputs,
//     int mixin,
//     int nOutputs,
//     int extraSize,
//     bool bulletproof,
//     bool clsag,
//     bool bulletproofPlus,
//     bool useViewTags) {
//   if (useRct) {
//     return estimateRctTxSize(nInputs, mixin, nOutputs, extraSize, bulletproof,
//         clsag, bulletproofPlus, useViewTags);
//   } else {
//     return nInputs * (mixin + 1) * APPROXIMATE_INPUT_BYTES +
//         extraSize +
//         (useViewTags
//             ? (nOutputs * 1)
//             : 0); // Assuming crypto::view_tag is 1 byte
//   }
// }

// int estimate_tx_weight(
//     bool useRct,
//     int nInputs,
//     int mixin,
//     int nOutputs,
//     int extraSize,
//     bool bulletproof,
//     bool clsag,
//     bool bulletproofPlus,
//     bool useViewTags) {
//   int size = estimate_tx_size(useRct, nInputs, mixin, nOutputs, extraSize,
//       bulletproof, clsag, bulletproofPlus, useViewTags);

//   if (useRct && (bulletproof || bulletproofPlus) && nOutputs > 2) {
//     final int bpBase = (32 * ((bulletproofPlus ? 6 : 9) + 7 * 2)) ~/ 2;
//     int logPaddedOutputs = 2;

//     while ((1 << logPaddedOutputs) < nOutputs) {
//       logPaddedOutputs++;
//     }

//     int nlr = 2 * (6 + logPaddedOutputs);
//     int bpSize = 32 * ((bulletproofPlus ? 6 : 9) + nlr);
//     int bpClawback = ((bpBase * (1 << logPaddedOutputs) - bpSize) * 4) ~/ 5;
//     size += bpClawback;
//   }

//   return size;
// }
