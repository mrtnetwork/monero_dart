// import 'package:monero_dart/src/address/address/address.dart';
// import 'package:monero_dart/src/crypto/ringct/bulletproofs_plus/bulletproofs_plus.dart';
// import 'package:monero_dart/src/helper/transaction.dart';

// import 'tx/create_tx.dart';
// import 'tx/methods_test.dart';
// import 'tx/models.dart';
// import 'tx/rpc_methods.dart';

// /// 1722470
// /// 51ccafb3e3da92de8040d4b0fc44721d8cf1a17744d0babd3b8c7908950576ea
// /// bc74bbef8ee586ca40e2047e077c8a07189e2a0d0d8f20e5d8112ea0bef2d1e8
// void main() async {
//   // final txHex =
//   //     "020002020010f2c4eb0281fc930195ff18f3cb14a3cb08bdac01ad288a16d0248a14c605931d88098102e901bd05f480e0d4f2104266bc6e39650ac32c21c674226b23f70cd776b54add5c27a939020010eff58f04c2bd1fe5c006ed27a016ee17c525f97ffc16f903cf03c6118e02b206d403aa04d5669f37549359362a00b71b9390bf64ee757efcc2dee607e685d5a3cec77a770200036d4309febb3aa8808ead3c8104810deb65161a6a12e9df162f244f1944df9036ce0003963f862166e4782fde5a9be0137ad547efcc72681e5d47ea2aa6586cbe8813c8802c010810a5ccdce626f6315a9aebb35aceb12117a9cab61258b19d451c2dda375459020901f27e8833a4f498d006a0b2ba30524ca8606bf7f27dc4a7b927bc1267ebaaac9d0bda1953420119928ab4090fceab7dae39b3a93e37205cb09dcbd6fd3e60e867326d31634a6e481aa658b2fc885fdb489c381c4f1eca4a4c91dde0b8da0183aa6d3bdb500fd33c50c070e05227f61a19598dec2515f7e1ebbb328f5484fd5ce767b617113d7a8804c15a1e4e403a13588c06754a4932ce08aa555b62ab5c5a947c33ece601afc01ca1504c8818b8b8ccd3af0c9b054fcecee82eb3f4bcae99b13e1ff923f771864af6f575e4017406a4794bc6949c7909e9e475a93e5b00a4fb6626272e488915d6fe338e20d4036fa7a7ef9fe91ba9a3fdb6aabd86a90446c9f38763162691c150e9be0892b9bc52fddfaeef4f821c07092d511744060207155feadf0e8c33204c473b2563eb53215c515d1fe28b8710901e2f758369250221b5db8da30ca1563133eb6cdd4b86ab6b80d636217852ea2700df156880c0fd360495c8802cadd708bc8ceeef629b1f2e44c103f4f8aed9b133bdf4e3c6922732ca1c04cf5e65e1bea7ea6e15b18df29d29019e287230d38c6d622c7d765dea247944093840c5ed802b36e356034f69c96244ca96112aa6c1d94df98dbc7242756b13cd1ac25ea859d34c54af42034e4a1d084e3e797dfe03974ef6496ecf308fe5a19705b803adc67e27d88156a7f9c6e1a92217e53567afbee091c43de7c707bcd1d38e19c8eb4bf4cb57f39f15e9594b66a3a62e0204e91eb06626e905a23a8327c575967cf2bda3050d4c62eb195966922166929c1cd3abb972ab6a91afdd3b0dc11825a757876641a0a4192f7dfd85cc7827caebc78efae14e516653ea2628218b0fe73121d548534b871d1d5ada43a023e0869a47314349f84e003cc99287ec2a799a1e41abcc2f4499e02245d9089dd3b9bf30cef7f144e176011f24b1bb82a9122b473b65b225058829b26dfebb29a4fceea7b4d2576a11ca7375ac8c792b97e103312f601fb4f2cb4b2ec350f2e90f0abcea4bb0c725c6eec181e270468f00df04cbf2b0c82b581f14b6601e0019b4cbefb267b6a5a61defe85b08029f423a0103a4b30c07647c0876420c59f04e1b4f6f39ee34629e07b8ff63f408b15afb869e4c958a9627afe34ef9aa96d6e9be190978ba06e44c7a1b4ab578082b8b8fb09d6d2c2d52d4ff83b2832a52e0f4d9711d7770e179ec8ca3fe99520af9ba12244b13c7d5bf478fa8c79f820abf5a2eac56b1407db7f24380db63960971ec0599acbf0e1eb807d28fdee2eac92726607a2a4f03cb31111dc721112f04ce764efaaff1e5cd354768a8b35b88a81a2d5269530135e5d4d6ae60bc166d014f91d0f78fa8d03156a8ca14e59a6bcd5386a93aa191c1eaa936b2d7e6b580094751e7cefa0d45faf581e5cb4a62a374aec1a74c69b51b1d68d88a97ab915b03f45f0a2c5ce48207da52e6ffde5569f14042cc6ec2ff3621f19877f604f5f20e933d729be3ae8bdc9d78ec769f70fd4ab66f1d21f36f92a537106a2dec3a6b03f6429710635c12b15e53849f610ac9d51abd90b296de30947e9c57183b58a709a12cfe2c30c6a89bdbf61758ebbd19455a00caedd6183064f24e64d806ae8b09d44c0ab037404f15356eedd722d78f97a9eabee0ced76e5786200220d532300a5ed18f36454eabb3ef657bf195f37f62c1d1cbb4056a08b5aa4bc8fe18e0e203d97ef3bc844dcee4635b18ecd9d3db312bb62fbe954a8520c09039567080d10f348d9b546d05783584abbd17943b4341517444690f8b4095f9a520ce26f74b0a7d3df4aa953337a7ebbcd1983e2a588ae3084a3e9e258abe4ce3e48eff31ac58f6976c2d55677d3ade7916cc29bcc3c26e56bb981522d7a8718a86456d5afe00eeae8790ea9768681a8bf4445dc83c7c3a31d2fa7544b170c3e3c8f5ff96c70a521c26886b8901f0e07fa08b0a58c3dfc30155265f7f9e9fac0f5ccde104f10a23968b40c7f0b6778d03b02649090f64048b910209749fc99d7b045173d6e602777be3c6b3204f298a74115645d302dfa8df0a8f148fdbafafb8a538bfec720ed2b39c80a4bcd35632876327053664308a9af37dc2a51eb4cf4c1c09ede41d048b0ebbbe8753f8bc281e1d8d6499575f368bcb47606b893b2c46f2800ec2a80446041bbba056f20a5cba420a2b730bc8d29e210dbf3a551eee625fcabe27a5062010e7363c92131430f5eeb3fa2dcb65a07ffd75aaa0715dd4b8c75de1bbf6004efe7bd0d33fab7eb10fcd25e0b0c911f3df4fb3a79303cd09c6fb6d9c45ec02d10da9e82c8ceea418fcdadfa84a36bc404f14f0e724ca4acedbb3e950a6de0b9936ef7940a16b17633dd1b171701d35978f13c7ce979c42d2d5bd6364cd2b02739d8fe33c55b701d5eae2113e3180332915dc676f72e1a0cb09f5870386500ce82c90e47dab996af92b3450aaec4482eed45a70cc69187f706eeafd380bee0d38edb5109a4667c167574e37c7dc0673285f5cfd7f39ea8cb6f647f9a4005e0c5760f939e26acc012e5731f24f85ca0fe84d9df93235f2548db4f341b3a03c07644274f359dba9b0ac6eb8c8740873c29d696de1f90046024779313ed570d00520a94d9a73089e7573f9f68bd4dfba69e377121895206ac066c395811777bf58d575ef1fd93fe4053696a7d7a606a5ff3c76bff6a28da2e6626dadb52cb3ff5fe9c0232c6bed75e16168ec8aed275ab54ce749ba020fc1f0799becda24030c12";
//   // final tx = MoneroTransaction.deserialize(BytesUtils.fromHexString(txHex));
//   // print(tx);
//   // final ser = tx.serializeHex();
//   // print(ser == txHex);
//   // return;
//   // // final tx = await getSingleTx(
//   // //     "51ccafb3e3da92de8040d4b0fc44721d8cf1a17744d0babd3b8c7908950576ea");
//   // // // print(tx);
//   final tx = await getSingleTx(
//       "96f26fcc16d4e07fcb70f643b42f2ce9f95758ba4d7fdd454699521d1a88a3ed");

//   // final myTx = getMyTxs();

//   final transfer = getTxTransfer(tx: tx, account: getMyAccount());
//   // print(transfer.first.amount);
//   // return;
//   BulletproofsPlusGenerator.init();
//   final amount = BigInt.from(8999898380000);
//   final fee = MoneroTransactionHelper.toXMR("0.001");
//   final r = amount - fee - BigInt.from(2000000000000);
//   // print(r);
//   // return;
//   final s = await createTransfer(
//       selectedTransfers: transfer,
//       destinations: [
//         tx_destination_entry(
//             amount: r, address: MoneroAddress(getMyAccount().primaryAddress)),
//         tx_destination_entry(
//             amount: BigInt.from(2000000000000),
//             address: MoneroAddress(getReceiptAccount().primaryAddress)),
//       ],
//       changeAddr: MoneroAddress(getMyAccount().primaryAddress));
//   // print("transfer done!");

//   print(tx.toJson());
//   print("=======");
//   print(s.toJson());
//   // await sendTransaction(s);

//   ///
//   // print(transfer);
//   // final ser = s.serialize();
//   // print(ser.length);
//   // final txOne = getMyTx();
//   // return;
//   // final account = getMyAccount();
//   // final tx = getMyTx();
//   // final selectedTransafers = getTxTransfer(tx: tx, account: account);

//   // // await getOutputs(
//   // //     selectedTransafers: selectedTransafers, fake_outputs_count: 15);

//   // await createTransation(
//   //     dsts: [],
//   //     fake_outs_count: 15,
//   //     priority: 1,
//   //     extra: [],
//   //     subaddr_account: 0,
//   //     subaddr_indices: {},
//   //     unique_index_container: {});

//   // return;
// }
