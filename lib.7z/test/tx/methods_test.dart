// // // ignore_for_file: dead_code

// // import 'dart:math';

// // import 'package:blockchain_utils/blockchain_utils.dart';
// // import 'package:blockchain_utils/crypto/crypto/cdsa/utils/ed25519_utils.dart';
// // import 'package:monero_dart/src/crypto/gamma/gamma.dart';
// // import 'package:monero_dart/src/crypto/models/ct_key.dart';
// // import 'package:monero_dart/src/crypto/monero/crypto.dart';
// // import 'package:monero_dart/src/crypto/ringct/utils/generator.dart';
// // import 'package:monero_dart/src/crypto/ringct/utils/rct_crypto.dart';
// // import 'package:monero_dart/src/crypto/types/types.dart';
// // import 'package:monero_dart/src/exception/exception.dart';
// // import 'package:monero_dart/src/helper/transaction.dart';
// // import 'package:monero_dart/src/models/test/output_info.dart';
// // import 'package:monero_dart/src/models/transaction/transaction/transaction.dart';
// // import 'package:monero_dart/src/provider/methods/binary/get_block_by_height.dart';
// // import 'package:monero_dart/src/provider/methods/methods.dart';
// // import 'package:monero_dart/src/provider/methods/json_rpc/estimate_fee.dart';
// // import 'package:monero_dart/src/provider/methods/json/get_height.dart';
// // import 'package:monero_dart/src/provider/methods/json_rpc/get_info.dart';
// // import 'package:monero_dart/src/provider/methods/binary/get_o_indicies.dart';
// // import 'package:monero_dart/src/provider/methods/binary/get_output_distribution_bin.dart';
// // import 'package:monero_dart/src/provider/methods/binary/get_outs.dart';
// // import 'package:monero_dart/src/provider/methods/json_rpc/get_transactions.dart';
// // import 'package:monero_dart/src/provider/methods/json_rpc/hard_fork.dart';
// // import 'package:monero_dart/src/provider/models/models/distribution.dart';
// // import 'package:monero_dart/src/provider/models/models/fee_estimate.dart';
// // import 'package:monero_dart/src/provider/models/models/get_out_response.dart';
// // import 'package:monero_dart/src/provider/models/models/get_info.dart';
// // import 'package:monero_dart/src/provider/models/models/hard_fork.dart';
// // import 'package:monero_dart/src/provider/models/models/request.dart';
// // import 'package:monero_dart/src/provider/models/models/rpc.dart';
// // import 'package:monero_dart/src/provider/models/models/tx_response.dart';
// // import 'package:monero_dart/src/provider/provider/provider.dart';

// // import '../junk/provider_test.dart';
// // import '../tests/crypto/derive_public_key_test_vector.dart';
// // import 'rpc_methods.dart';

// // int CRYPTONOTE_DNS_TIMEOUT_MS = 20000;

// // int CRYPTONOTE_MAX_BLOCK_NUMBER = 500000000;
// // int CRYPTONOTE_MAX_TX_SIZE = 1000000;
// // int CRYPTONOTE_MAX_TX_PER_BLOCK = 0x10000000;
// // int CRYPTONOTE_PUBLIC_ADDRESS_TEXTBLOB_VER = 0;
// // int CRYPTONOTE_MINED_MONEY_UNLOCK_WINDOW = 60;
// // int CURRENT_TRANSACTION_VERSION = 2;
// // int CURRENT_BLOCK_MAJOR_VERSION = 1;
// // int CURRENT_BLOCK_MINOR_VERSION = 0;
// // int CRYPTONOTE_BLOCK_FUTURE_TIME_LIMIT = 60 * 60 * 2;
// // int CRYPTONOTE_DEFAULT_TX_SPENDABLE_AGE = 10;
// // double RECENT_OUTPUT_RATIO = 0.5;

// // int BLOCKCHAIN_TIMESTAMP_CHECK_WINDOW = 60;

// // // Future<OutputDistributionResponse?> getOutputDistribution2(List<int> amounts,
// // //     {bool compress = true}) async {
// // //   final provider = createProvider();
// // //   print("max ${max(STAGENET_SEGREGATION_FORK_HEIGHT, RECENT_OUTPUT_BLOCKS)-RECENT_OUTPUT_BLOCKS}");
// // //   return null;
// // //   return await provider.request(DaemonRequestGetOutputDistribution(
// // //       amounts: amounts,
// // //       cumulative: true,
// // //       fromHeight:
// // //           STAGENET_SEGREGATION_FORK_HEIGHT - RECENT_OUTPUT_BLOCKS.toInt(),
// // //       toHeight: STAGENET_SEGREGATION_FORK_HEIGHT + 1));
// // // }

// import 'package:blockchain_utils/bip/monero/conf/monero_coins.dart';
// import 'package:blockchain_utils/bip/monero/monero_base.dart';
// import 'package:blockchain_utils/utils/binary/utils.dart';



// // List<MoneroTransaction> getMyTxs() {
// //   final tx1 = MoneroTransaction.deserialize(BytesUtils.fromHexString(
// //       "020002020010b8e49602d0bc8b029bb10e858103c4c2028c0db810980d9c11ae0db80496023fa802e203c802eb5aac316daf9a7ff583c3aaa164fd6c834f43a7b1f9ca9923b27ecb4847de3b020010bdebee0197a919d0bda601f5b08301f39104891ac3089c118606aa078c09e80180039905d501ec03560190a4edb08f9a6dd971954c8999eeb4d48d282d1bf32fe3b729f60c95cbf5020003ec349eec0ba89b780e602a011fcdf7bfc4488cf90ef938775af3d230a7032320ee0003736424e973330b22a98e8ca5dca9a51fe6cfcfd2002a1e87b5cbfd79a05b23697b2c011b8f615709e9092fafaab251dc13372717c3ad5916682cb6d79c948439e10df7020901da80f4c29d07782d06c0edb3c80150bb44d885433da65422649960681c730f5b3b9bb0037db755c1cfaa0e1d519817e420cc80578102c7df40a554632a801b19a1488c2ddcec0729959f1fed213f833e40d2c6466756d5978f3cbc85587701fd7d42a0e74a82299e21bff39107bffa6bc7adae8cd3ca18de2b04b11b71e0cb82c588dadb895bde4444675197e7363b01ff8c34a32d04c1d0f0031fa9bfa8e286ab086a8290a7481cdc7e7f3ff1387e21a91ec3b488c8ee3141d4e843e162e1dc2fe6a0d5c5e3359fb5e13d0e5f1264ff89bd6fe3b56147e83808c0c72bba0ea72dc33f38a877051d5d83b083bfc0c6f03233ab64bbf6e7c37a0f8811aaa30e7db3b950605fb1f3484b115df929736f7a9f5a348e2fe3630384061062bcbc07076ce202ca2c8a993979828d1be94ffb1d922ddbebee13a06f755989579b04612f0aac6dcd0cd3fab7ea8e5dcf55a9ab5a334bf0aafc17ea19ac04594cf9a226b76101c53a84a453fbc76ea2056e7526b2d593d77903140a50e338518bf97a7876a47ff6352aacfc2fd12f2868932dae283e57e1d776c5e4d5499507350a7845242f0deb115063abcbff29f732c4badb6d80b94b62286e77a7d902532bdcc56916437e76c0819cd79ac408e48e26204202a63ae11033113939548ce8942bed61b083612e2a8c1a5ec548b13899edf838051592911a9dc8697173f3082966a2bbe207b02463375d8a98604ec1b28d3994336accae3a6846dc41aba23ec2b4221e3a34a12dc8ffe09f750b0aa4ed1ae38d5384436c4f40caa987624b2a27f9d73ef8bbc89a2f01d0005d307e21bfcca367169041b17c6c6ef5f739b70743d51fbef25f4315b7c5d7149f79c98802ed18b8b5881a85cbf55b10110f5a2ec2639c9f596a4fc60317d91c9de69fdc808d23c5bcd2e70e27a7cc7e356ccc3738a105150282f14ed874d2478bab785e49b08831ce78354e9796e208c29b72a13a157a463e6cdf1cc10ff7d5a951bb480ecc70dca901af3595ee0f5400c3d29609b01fe5f24090adbb1a4dcfcd1bcb931cd9a7088668b6f2a8517638f53b39d5ffb5eee53902e6a4271370fadddba4cef165dda4b6a49b9e508b4a59bf60e1965a7ca470b5057fca35ba3677552dd15f5bc18c4052b24f50420d06ee0b17fce4b8c348b40005868ec8ed8ff505a47ce9d1d3dad01a6ff5ce07046d58dc6f783d0b0d2a9b6b027d5b26dceb4f0d1dfe1d3c8a40acea76e4dac02a1893c6ce0fd37deb28008a0356a3693fe002512ea1f4096520ea9c188bc11e24c4813e4627a002849623340b54ef8734dd77e6e8772b6ff304dca34436c4d56aa1b0e11c29358e63d106da00c737244c5c4cae2db3dbe96e9d7625eef99517dcf3cdcba374ceeeed5077250eb1d4e0b4d26a601113afcf6072c995199fe718abb2862edee5b79b746b98be03bc1a85d4bd14b8fe415943b823f1c8672bd584799a9636aa48006c105b874e01244018ac6165b9530e488760eee05e9db35c5711dfc383d67e015351ba40ef0187d14139f7eb81d1d928bc733d885301e7c60fd898edc118b6290487037ca302b6881e46ea8e6aad92ccaa80e0b71043e599d225918a44c769347bf2975b5b08177563c5c48a1bbb3adf73b95a3573781eb1ec65f2e5f5637916584cd66c2406fb913a1b0beebc96ad308331840df3cf9f75d005bb395dc10e7b936b94c32b03b407bdad6df6feaa546436318e1385318831793badbb5fbbf327b2e2888fbb04b8fec8d6398c26f39fd22339888eab0768a8e5aa78f01a3fc5db741b2bde1d0f5ec743a07b5f24835db3cf012dc42108d1126e6683978f25f80a3f6dc13ec1c75741d8159a8f96facea3524020239e641db75b61b8aaf9736ef8703587d1330d2914c889272384e4ef4bfd3eecd5c12c4f6b40e82257ca76899158f052116d0528b517c15bb777b9e0633e4bae647cde48c2983edcf9d0d4740428d7afd69f0406626b1abe9a89e6b3c1a41b36c7d5a4ce8a3110404acfb52e93a60f9e2a2006d4abb3192f39f89120640fdb63747fc4f56f096014ba0c649c627c9ea71e110abb4d0c0b02b51312c95643024e1dba6fd0f5559cc66afc7e1b751b859636890ec0f4b2e3157edfb4ca1dd698c3b1ef29e056071befb27a7b658a715e87ff7d09ac4736f7076f72d6623f5c62a15afb8cd44b80d5bbb0d622804e558d1494920b74babadf57ae18fa533ef7f8606052b3aa45684d8727bce8632f45d8edd6be07da2f0b768dfd8a5941ebf12ba9707a4589f76048d5d56f097c7f95b1f8b0bd0716656506d26a452e7f0682dd3f24c35bf5b3e8c67b8440ed660038bab1928b08615fab0e79ac864f730c8614b14ddc6ad0be2f6bc0c699ad773c8b007bf6a601ac485844095ebdefe0c10cf3f34bf47cf9db85d92cde4c0a8074a4a184eb6502d011c81283724c3405298b38e8817695076f32490eb27f8c775f3e0681fa96032c94131563206fcd9fe28d9524d047ae4f50b408bfb479fff81459c30419c20f8d5d78b540967ad17d52ad7a75173085d76496254fde0dc09d5751aeeafcd60f1389f806ac5d2a77a074d7c75211838082ebb0e90e2d608e7d682ca39aadca072f8b6aa3f89b40001da44a267edae252391bc05fc88378ed52ae7fedddaaf99120a6f39fe409934d00b0626cf4c85b6041437751998e6ee4a0df772ae2c9f89aaa9b95347476cfd5c0bea277dc512d1d627e4b8c0229711d4600074201aa3656"));
// //   final tx2 = MoneroTransaction.deserialize(BytesUtils.fromHexString(
// //       "020002020010b2a2d702e69bdc0196be019e26ff89018705e30dd9259109db02db0691028704f4013f810160f9976e961ac513e4fcd1d2373cd6455a7f8db645c5cecb8c8c799ba99d6714020010acf894049ef70ec2e401a9d501a3b20c899101a366b63480028519a753d804c40679256c5cd197962cb2dd516dcbfae4b2ac5ac6eca86b28365e9d7ca0cfb0ededb4d795020003de8063db546d2e0010d6d9da9ed89501d766268e011ac89beef96d2acc76d1c0dd0003b2cfd1de4a268ebd91f74a8400bbf8aa2cb31187a254a4ddefc14e2714fc7dee482c01aee30e15868848c3e8771f84cc3bd8097f5b3e8caaeafb813ebf8936b1b19508020901dcdfc9ff43dbb51506d081bf321d4d56f77ddeabf9eefb40d119102370ede5657ea1554d3e100b27e543be0ba287ca288aca3125b1f4512488e68e483ea607ea4c5998e6f0eae91ad672a4909571e94e148242ecb1be8979ea0f7464350145a3b61f8ba40e781f3fa4dbdbd32e284476eb21a262402df5c1829de0ce36a6c532a625a6f645e4e917061efe67f94623172daeec3e41b9745f9cc61a7c911c9cccc2056af412f98d68594bf40fe404bcc8c06f645f7c93e1d67901dbea5bb5b20f3b6cf2b05ab156bdf1b669d063da8a4034e0c911dd1e3aeee59449e6d70fe9d5ab1ffb28c757ab1338892dd877dd73179bb5289c271a277fdf5e17f27f04d46a5a03a732bef4c86e4b6e79e89c2f49f8e156d74828a4ab2e71ad98864107079afe6de68a51f7f6fd4886b12443342ab3e670a56bbc5730585a77eb356c5c8098783f3c563ca2352fdc0917c61393d2b69bb6561e675fb61315e1002bf7a12b357a82ff6af9615234cc967f79fae60de8139b3f007c8b298b24740682fc8f2aec315ef60b63bc8891ccb3997daf498eb2d1f30329c2c68c7c59855da51f55e55c1c5e716413928ba5bfc40102252b0dbb6d25b98c05c79af40f474425f63ad95eda51ddb7150297c16419c3c31de8449d26db47b24f9bcbfc1cfd34048f6cb01bf3da9666d80a9c7820e47d24cb8d270de4fd6ce88a367ce85bbc025409499c070a8e0284aa2475a81d93bdecb06e311dc6e9371b0ebad958c50405cdd34d402489b18b52a8b4e31586f572b7d2fe67410be49510696a4472e7516d491b193e9b4b709c3e7b03af8dbb11c109b8313306a3b341fbcecac2c0389b0bafa52cbad46a45ec0f282f0279cf4e1e642e2332fe9820a661d5a17799c624d43bcde380227f3b185037a8d5f15255c19c35920db56b6c7efb06c4db437700f3fd9e17628708c96010dba401143ab905317f3b0360a5be59e00dc03997dce0456689fc21466173292e954f09cd485ef58e21bb69ceb20b5a53e81a119b9e6b84d5a5bf1912c4b2685c6fb5e25e960e14de47405fa8acdf2b129ed9501cc06bba38da734d0c9dbb41918d4cafe284075bb1bfa5eb4e6bff9b262486573bd30068682019cc05e497587d9630ba44637c8e26fb25890b8eda1be36beed6fccc892ec2aeadf90f16834a929872d06ed20d0fc0a9e30ef0690363279e758b440fdd593a08f7bc0ead586a07dafa9e9b9e6d4a0a6b57a2ff9815cec310aae992014494778d6d2c06f855c274ee39c666ea27a4486f5e7b459733a722eb8ef81562c05ecf766ee4015433571befeadee75f8ae54fd1e82ec9490084f418395235a65e3656eaf7430da65d8a0de44c5ce756118d66e67dc9a4be85603dda2460deac4f3d9f46e9e00821a2c797c8d62e06fe1bd94cfee62ee58de029f81f668056fac460b7c9e80c0da705a77735befb804f2e68f63cbe2ee22b15b62436d81f3b8781053a06842a02ba3f6917cb91490371cbf83911495dffe803528ebd8772da299d934d98104d046da6ab12686608ef925f6f811cc8c47e60ec5db9bb4498f4c58bf35d0d41cb0ff8d0b2ddb8760a605f8c10a903bd2badd85e8ee7f340e0c1ad1f8626a8449b0144189f07d0cf9e118df573ea24fc3c4fde1f8aba6cef4da5730c6bb4afa83a0eca13b9efd16054cc1c8d3fbf06c68c629115059d08dc7e16d7674c97ea2e8706863757cc374ae45fd3e6f987dd192124558f2813f7d008dbd529dc6262862905225f17fece27fe97e14f0d37a044e0ec061e3909479a0ce4d7409f548cdd7702ca8dcb7b81d40ea2e00241140c5b5860439bb948da433e5698aeb15e4f1254232d076089190f65350ba42256b1aa559dcfb8c3d2ef34910c04ae0d46db06c70e3887a2eb4516288e66a3c6c98fbfa74f2f8b00227df2333fade9369c3debc70bdd81d5ab8ffcde3584e3f3a849811db166979e28c7cabb7aebd8f4dcff1c0306de30d6465747d9c4e52c3a354b24093b133653d25b64c3af6ebc0bdcd3d1270eba4580c88c5963d38d6c10a612e0a4d770f3ef2482c9d3d126bec82f3457c5003a0032950e5c293fe69df2ac80e9a549633be0637f365d451822d5d691f7b50681d8505a047bc1088166850d6cba2d89536c62278db94a6f6f75ea7f19ac48029216e173e19dea676657da6d7ca6153002b046c2762c0881f70908580482ca0bed08440ab55a0dcfec7ad1d4acf2fd0647c1b951462d47bf4f5996630f03180ecd4fe388078ec692ce0d46bf9fa6e681d5b4a11f8dacee4fb131b128daa2fc01c735d5f43a08790ebe00cb0109f3d8ccc29a7b6ae8e1a0f7fd0d4db8abdc1c033bda8ce4060aa2bde4228e6eaa05d0b924c01148ddbe94b3163e7a4644ec8d05d7e94ff99d5861de85c77de8a0789a31c09f8bcb9d4c465e652dec2e0188240edb45857174a5b062601d3f5974eb701ac82771b0f424c2e9abe2a74168c07e0b9b3aa81f386cea572953e9ee0c66adb811488b657cbd1f9250d3f0dadadc8304d28a80508a6415a0712891601b62889a4e3eb03516f4c58e75fe1f9cd82fc80d465483451d6294eb1a74553f1aae941c98ff486ba1f789ad260525b15070b60a3fc63e9e4397e9e4d91736ba2f8d5ffcf94df42abb9de7d14292fc91f7ad8568170408dc97e03d7a528202cd81dd687b7989afaa9804eedf55bb70303e789e7b7884dd785b90f21d7603b4dc156d0f2e25bda7cb6fbbc894705bb02274ab7787"));

// //   return [tx1, tx2];
// // }
// // // List<MoneroTransaction> getMyTxs() {
// // //   final txBytes = BytesUtils.fromHexString(
// // //       "020002020010b2a2d702e69bdc0196be019e26ff89018705e30dd9259109db02db0691028704f4013f810160f9976e961ac513e4fcd1d2373cd6455a7f8db645c5cecb8c8c799ba99d6714020010acf894049ef70ec2e401a9d501a3b20c899101a366b63480028519a753d804c40679256c5cd197962cb2dd516dcbfae4b2ac5ac6eca86b28365e9d7ca0cfb0ededb4d795020003de8063db546d2e0010d6d9da9ed89501d766268e011ac89beef96d2acc76d1c0dd0003b2cfd1de4a268ebd91f74a8400bbf8aa2cb31187a254a4ddefc14e2714fc7dee482c01aee30e15868848c3e8771f84cc3bd8097f5b3e8caaeafb813ebf8936b1b19508020901dcdfc9ff43dbb51506d081bf321d4d56f77ddeabf9eefb40d119102370ede5657ea1554d3e100b27e543be0ba287ca288aca3125b1f4512488e68e483ea607ea4c5998e6f0eae91ad672a4909571e94e148242ecb1be8979ea0f7464350145a3b61f8ba40e781f3fa4dbdbd32e284476eb21a262402df5c1829de0ce36a6c532a625a6f645e4e917061efe67f94623172daeec3e41b9745f9cc61a7c911c9cccc2056af412f98d68594bf40fe404bcc8c06f645f7c93e1d67901dbea5bb5b20f3b6cf2b05ab156bdf1b669d063da8a4034e0c911dd1e3aeee59449e6d70fe9d5ab1ffb28c757ab1338892dd877dd73179bb5289c271a277fdf5e17f27f04d46a5a03a732bef4c86e4b6e79e89c2f49f8e156d74828a4ab2e71ad98864107079afe6de68a51f7f6fd4886b12443342ab3e670a56bbc5730585a77eb356c5c8098783f3c563ca2352fdc0917c61393d2b69bb6561e675fb61315e1002bf7a12b357a82ff6af9615234cc967f79fae60de8139b3f007c8b298b24740682fc8f2aec315ef60b63bc8891ccb3997daf498eb2d1f30329c2c68c7c59855da51f55e55c1c5e716413928ba5bfc40102252b0dbb6d25b98c05c79af40f474425f63ad95eda51ddb7150297c16419c3c31de8449d26db47b24f9bcbfc1cfd34048f6cb01bf3da9666d80a9c7820e47d24cb8d270de4fd6ce88a367ce85bbc025409499c070a8e0284aa2475a81d93bdecb06e311dc6e9371b0ebad958c50405cdd34d402489b18b52a8b4e31586f572b7d2fe67410be49510696a4472e7516d491b193e9b4b709c3e7b03af8dbb11c109b8313306a3b341fbcecac2c0389b0bafa52cbad46a45ec0f282f0279cf4e1e642e2332fe9820a661d5a17799c624d43bcde380227f3b185037a8d5f15255c19c35920db56b6c7efb06c4db437700f3fd9e17628708c96010dba401143ab905317f3b0360a5be59e00dc03997dce0456689fc21466173292e954f09cd485ef58e21bb69ceb20b5a53e81a119b9e6b84d5a5bf1912c4b2685c6fb5e25e960e14de47405fa8acdf2b129ed9501cc06bba38da734d0c9dbb41918d4cafe284075bb1bfa5eb4e6bff9b262486573bd30068682019cc05e497587d9630ba44637c8e26fb25890b8eda1be36beed6fccc892ec2aeadf90f16834a929872d06ed20d0fc0a9e30ef0690363279e758b440fdd593a08f7bc0ead586a07dafa9e9b9e6d4a0a6b57a2ff9815cec310aae992014494778d6d2c06f855c274ee39c666ea27a4486f5e7b459733a722eb8ef81562c05ecf766ee4015433571befeadee75f8ae54fd1e82ec9490084f418395235a65e3656eaf7430da65d8a0de44c5ce756118d66e67dc9a4be85603dda2460deac4f3d9f46e9e00821a2c797c8d62e06fe1bd94cfee62ee58de029f81f668056fac460b7c9e80c0da705a77735befb804f2e68f63cbe2ee22b15b62436d81f3b8781053a06842a02ba3f6917cb91490371cbf83911495dffe803528ebd8772da299d934d98104d046da6ab12686608ef925f6f811cc8c47e60ec5db9bb4498f4c58bf35d0d41cb0ff8d0b2ddb8760a605f8c10a903bd2badd85e8ee7f340e0c1ad1f8626a8449b0144189f07d0cf9e118df573ea24fc3c4fde1f8aba6cef4da5730c6bb4afa83a0eca13b9efd16054cc1c8d3fbf06c68c629115059d08dc7e16d7674c97ea2e8706863757cc374ae45fd3e6f987dd192124558f2813f7d008dbd529dc6262862905225f17fece27fe97e14f0d37a044e0ec061e3909479a0ce4d7409f548cdd7702ca8dcb7b81d40ea2e00241140c5b5860439bb948da433e5698aeb15e4f1254232d076089190f65350ba42256b1aa559dcfb8c3d2ef34910c04ae0d46db06c70e3887a2eb4516288e66a3c6c98fbfa74f2f8b00227df2333fade9369c3debc70bdd81d5ab8ffcde3584e3f3a849811db166979e28c7cabb7aebd8f4dcff1c0306de30d6465747d9c4e52c3a354b24093b133653d25b64c3af6ebc0bdcd3d1270eba4580c88c5963d38d6c10a612e0a4d770f3ef2482c9d3d126bec82f3457c5003a0032950e5c293fe69df2ac80e9a549633be0637f365d451822d5d691f7b50681d8505a047bc1088166850d6cba2d89536c62278db94a6f6f75ea7f19ac48029216e173e19dea676657da6d7ca6153002b046c2762c0881f70908580482ca0bed08440ab55a0dcfec7ad1d4acf2fd0647c1b951462d47bf4f5996630f03180ecd4fe388078ec692ce0d46bf9fa6e681d5b4a11f8dacee4fb131b128daa2fc01c735d5f43a08790ebe00cb0109f3d8ccc29a7b6ae8e1a0f7fd0d4db8abdc1c033bda8ce4060aa2bde4228e6eaa05d0b924c01148ddbe94b3163e7a4644ec8d05d7e94ff99d5861de85c77de8a0789a31c09f8bcb9d4c465e652dec2e0188240edb45857174a5b062601d3f5974eb701ac82771b0f424c2e9abe2a74168c07e0b9b3aa81f386cea572953e9ee0c66adb811488b657cbd1f9250d3f0dadadc8304d28a80508a6415a0712891601b62889a4e3eb03516f4c58e75fe1f9cd82fc80d465483451d6294eb1a74553f1aae941c98ff486ba1f789ad260525b15070b60a3fc63e9e4397e9e4d91736ba2f8d5ffcf94df42abb9de7d14292fc91f7ad8568170408dc97e03d7a528202cd81dd687b7989afaa9804eedf55bb70303e789e7b7884dd785b90f21d7603b4dc156d0f2e25bda7cb6fbbc894705bb02274ab7787");
// // //   return [MoneroTransaction.deserialize(txBytes)];
// // // }

// // List<OutputInfo> getTxMyOutputs({
// //   required MoneroTransaction tx,
// //   required MoneroAccount account,
// // }) {
// //   final List<OutputInfo> outputs = [];
// //   final extra = tx.getTxExtraPubKey();
// //   for (int i = 0; i < tx.vout.length; i++) {
// //     final out = tx.vout[i];
// //     final isAccOut = MoneroTransactionHelper.inOuttoAcc(
// //         account: account, txPubkey: extra.publicKey, out: out, outIndex: i);
// //     if (isAccOut) {
// //       final derivation = MoneroCrypto.generateKeyDerivation(
// //           pubkey: extra.publicKey, secretKey: account.privVkey.raw);
// //       final sharedSec =
// //           MoneroCrypto.derivationToScalar(derivation: derivation, outIndex: i);
// //       final mask = RCT.zero();
// //       final amount = RCTGeneratorUtils.decodeRct_(
// //           sig: tx.signature.cast(),
// //           secretKey: sharedSec,
// //           outputIndex: i,
// //           mask: mask);
// //       if (amount == null) continue;
// //       final scalarStep1 = MoneroCrypto.deriveSecretKey(
// //           derivation: derivation,
// //           outIndex: i,
// //           privateSpendKey: account.privateSpendKey.raw);
// //       // print(BytesUtils.toHexString(scalarStep1));
// //       RctKey scalarStep2;

// //       final outPk = out.target.getPublicKey();

// //       /// source: generate_key_image_helper_precomp
// //       /// we have some more condition for multisig address. skip for now
// //       /// check if my account is subaddress. skip for now
// //       // if (isSubaddress) {
// //       //   //   subaddr_sk = hwdev.get_subaddress_secret_key(ack.m_view_secret_key, received_index);
// //       //   // hwdev.sc_secret_add(scalar_step2, scalar_step1,subaddr_sk);
// //       // }
// //       scalarStep2 = scalarStep1.clone();
// //       RctKey ephemeralSecretKey = scalarStep2.asImmutableBytes;
// //       RctKey ephemeralPublicKey =
// //           MoneroCrypto.secretKeyToPubKey(secretKey: ephemeralSecretKey);
// //       if (!BytesUtils.bytesEqual(outPk, ephemeralPublicKey)) {
// //         throw DartMoneroPluginException(
// //             "given output pubkey doesn't match the derived one");
// //       }
// //       final keyImage = MoneroCrypto.generateKeyImage(
// //           pubkey: ephemeralPublicKey, secretKey: ephemeralSecretKey);
// //       print("keyImage ${BytesUtils.toHexString(keyImage)} $amount $i");

// //       final outInfo = OutputInfo(
// //           amount: amount,
// //           internalOutputIndex: i,
// //           derivation: derivation,
// //           ephemeralPublicKey: ephemeralPublicKey,
// //           ephemeralSecretKey: ephemeralSecretKey,
// //           keyImage: keyImage,
// //           mask: mask,
// //           publicKey: outPk!,
// //           globalIndex: BigInt.from(9312447));
// //       outputs.add(outInfo);
// //     }
// //   }
// //   return outputs;
// // }

// // List<TransferTx> getTxTransfer(
// //     {required MoneroTransaction tx, required MoneroAccount account}) {
// //   final outs = getTxMyOutputs(tx: tx, account: account);
// //   if (outs.isEmpty) return [];
// //   final txPubKey = tx.getTxExtraPubKey();
// //   List<int>? encryptedPaymentId = tx.getTxEncryptedPaymentId();
// //   // print("encrypted ${BytesUtils.tryToHexString(encryptedPaymentId)}");

// //   if (encryptedPaymentId != null) {
// //     encryptedPaymentId = MoneroTransactionHelper.encryptPaymentId(
// //         paymentId: encryptedPaymentId,
// //         pubKey: txPubKey.publicKey,
// //         secretKey: account.privateViewKey.raw);
// //   }
// //   // print("encrypted ${BytesUtils.tryToHexString(encryptedPaymentId)}");
// //   final paymentId = tx.getTxPaymentId();

// //   return outs
// //       .map((e) => TransferTx(
// //           transaction: tx,
// //           outInfo: e,
// //           txPubkey: txPubKey.publicKey,
// //           encryptedPaymentid: encryptedPaymentId,
// //           paymentId: paymentId,
// //           subAddress: SubaddressIndex(major: 0, minor: 0),
// //           isRCT: true))
// //       .toList();
// // }

// // Future<Tuple<List<List<OutsEntery>>, List<RctKey>>> getOutputs(
// //     {required List<TransferTx> selectedTransafers,
// //     required int fake_outputs_count}) async {
// //   List<RctKey> valid_public_keys_cache = [];
// //   List<List<OutsEntery>> outs = [];
// //   if (fake_outputs_count > 0) {
// //     bool is_after_segregation_fork = false;
// //     bool m_segregate_pre_fork_outputs = true;
// //     bool m_key_reuse_mitigation2 = true;
// //     bool is_shortly_after_segregation_fork = false;
// //     bool has_rct = false;
// //     BigInt max_rct_index = BigInt.zero;
// //     List<DaemonHistogramResponse> histogram = [];
// //     // int segregation_fork_height = STAGENET_SEGREGATION_FORK_HEIGHT;
// //     for (final i in selectedTransafers) {
// //       if (i.isRCT) {
// //         has_rct = true;
// //         final globalIndex = i.outInfo.globalIndex;
// //         if (globalIndex > max_rct_index) {
// //           max_rct_index = globalIndex;
// //         }
// //       }
// //     }
// //     final rct_offsets = await getAllDistribution();
// //     if (rct_offsets.length < CRYPTONOTE_DEFAULT_TX_SPENDABLE_AGE) {
// //       throw DartMoneroPluginException("Not enough rct outputs");
// //     }
// //     if (rct_offsets.last < max_rct_index) {
// //       throw DartMoneroPluginException(
// //           "Daemon reports suspicious number of rct outputs");
// //     }

// //     /// handle none rct transfers
// //     /// skip for now
// //     /// line 9392 wallet
// //     for (final i in selectedTransafers) {}
// //     Map<BigInt, Tuple<BigInt, BigInt>> segregation_limit = {};
// //     Map<String, BigInt> existing_rings = {};
// //     List<RctKey> ring_key_images =
// //         selectedTransafers.map((e) => e.keyImage).toList();
// //     int base_requested_outputs_count =
// //         ((fake_outputs_count + 1) * 1.5 + 1).ceil();
// //     print("base ${base_requested_outputs_count}");
// //     List<OutKeyResponse> daemon_resp = [];
// //     List<DaemonGetOutRequestParams> secret_picking_order = [];
// //     List<DaemonGetOutRequestParams> req = [];

// //     void add_output_to_lists(DaemonGetOutRequestParams out) {
// //       secret_picking_order.add(out);
// //       req.add(out);
// //     }

// //     Gamma? gamma;
// //     if (has_rct) {
// //       gamma = Gamma(rctOffsets: rct_offsets);
// //     }
// //     int num_selected_transfers = 0;
// //     for (final i in selectedTransafers) {
// //       num_selected_transfers++;
// //       BigInt amount = i.isRCT ? BigInt.zero : i.outInfo.amount;
// //       Set<BigInt> seen_indices = {};
// //       int requested_outputs_count = base_requested_outputs_count +
// //           (i.isRCT
// //               ? CRYPTONOTE_MINED_MONEY_UNLOCK_WINDOW -
// //                   CRYPTONOTE_DEFAULT_TX_SPENDABLE_AGE
// //               : 0);
// //       int start = req.length;
// //       bool use_histogram = amount != BigInt.zero;

// //       ///   td.m_block_height < segregation_fork_height;
// //       const bool output_is_pre_fork = true;

// //       BigInt num_outs = BigInt.zero, num_recent_outs = BigInt.zero;
// //       BigInt num_post_fork_outs = BigInt.zero;
// //       double pre_fork_num_out_ratio = 0.0;
// //       double post_fork_num_out_ratio = 0.0;
// //       if (is_after_segregation_fork &&
// //           m_segregate_pre_fork_outputs &&
// //           output_is_pre_fork) {
// //         num_outs = segregation_limit[amount]!.item1;
// //         num_recent_outs = segregation_limit[amount]!.item2;
// //       } else {
// //         for (final h in histogram) {
// //           if (h.amount == amount) {
// //             num_outs = h.unlockedInstances;
// //             num_recent_outs = h.recentInstances;
// //           }
// //         }
// //         if (is_after_segregation_fork && m_key_reuse_mitigation2) {
// //           if (output_is_pre_fork) {
// //             if (is_shortly_after_segregation_fork) {
// //               pre_fork_num_out_ratio =
// //                   33.4 / 100.0 * (1.0 - RECENT_OUTPUT_RATIO);
// //             } else {
// //               pre_fork_num_out_ratio =
// //                   33.4 / 100.0 * (1.0 - RECENT_OUTPUT_RATIO);
// //               post_fork_num_out_ratio =
// //                   33.4 / 100.0 * (1.0 - RECENT_OUTPUT_RATIO);
// //             }
// //           } else {
// //             if (is_shortly_after_segregation_fork) {
// //             } else {
// //               post_fork_num_out_ratio =
// //                   67.8 / 100.0 * (1.0 - RECENT_OUTPUT_RATIO);
// //             }
// //           }
// //         }
// //         num_post_fork_outs =
// //             num_outs - (segregation_limit[amount]?.item1 ?? BigInt.zero);
// //       }
// //       if (use_histogram) {
// //         if (num_outs == BigInt.zero) {
// //           throw DartMoneroPluginException(
// //               "histogram reports no unlocked outputs for $amount");
// //         }
// //         if (num_recent_outs > num_outs) {
// //           throw DartMoneroPluginException(
// //               "histogram reports more recent outs than outs for $amount");
// //         }
// //       } else {
// //         num_outs = gamma!.num_rct_outputs;
// //         // print("num outs $num_outs");
// //         if (num_outs == BigInt.zero) {
// //           throw DartMoneroPluginException(
// //               "histogram reports no unlocked rct outputs, not even ours");
// //         }
// //       }
// //       int pre_fork_outputs_count =
// //           (requested_outputs_count * pre_fork_num_out_ratio).ceil();
// //       int post_fork_outputs_count =
// //           (requested_outputs_count * post_fork_num_out_ratio).ceil();
// //       // how many fake outs to draw otherwise
// //       int normal_output_count = requested_outputs_count -
// //           pre_fork_outputs_count -
// //           post_fork_outputs_count;
// //       int recent_outputs_count = 0;
// //       // print("pre_fork_outputs_count $pre_fork_outputs_count");
// //       // print("post_fork_outputs_count $post_fork_outputs_count");
// //       // print("normal_output_count $normal_output_count");
// //       if (use_histogram) {
// //         // X% of those outs are to be taken from recent outputs
// //         recent_outputs_count =
// //             (normal_output_count * RECENT_OUTPUT_RATIO).ceil();
// //         if (recent_outputs_count == 0) {
// //           recent_outputs_count = 1; // ensure we have at least one, if possible
// //         }
// //         if (BigInt.from(recent_outputs_count) > num_recent_outs) {
// //           recent_outputs_count = num_recent_outs.toInt();
// //         }
// //         if (i.outInfo.globalIndex >= num_outs - num_recent_outs &&
// //             recent_outputs_count > 0) {
// //           --recent_outputs_count; // if the real out is recent, pick one less recent fake out
// //         }
// //       }
// //       // print("recent_outputs_count $recent_outputs_count");
// //       BigInt num_found = BigInt.zero;

// //       /// if we have a known   ring, use it
// //       // if (!i.outInfo.isMultiSigPartial) {
// //       // }
// //       if (num_outs <= BigInt.from(requested_outputs_count)) {
// //         for (BigInt i = BigInt.zero; i < num_outs; i += BigInt.one) {
// //           add_output_to_lists(DaemonGetOutRequestParams(amount: amount, index: i));
// //         }
// //         // duplicate to make up shortfall: this will be caught after the RPC call,
// //         // so we can also output the amounts for which we can't reach the required
// //         // mixin after checking the actual unlockedness
// //         for (BigInt i = num_outs;
// //             i < BigInt.from(requested_outputs_count);
// //             i += BigInt.one) {
// //           add_output_to_lists(DaemonGetOutRequestParams(amount: amount, index: i));
// //         }
// //       } else {
// //         if (num_found == BigInt.zero) {
// //           num_found = BigInt.one;
// //           seen_indices.add(i.outInfo.globalIndex);
// //           add_output_to_lists(DaemonGetOutRequestParams(
// //               amount: amount, index: i.outInfo.globalIndex));
// //         }
// //         Map<String, Set<BigInt>> pick = {};
// //         BigInt num_usable_outs = num_outs;
// //         bool allow_blackballed = false;
// //         while (num_found < BigInt.from(requested_outputs_count)) {
// //           if (BigInt.from(seen_indices.length) == num_usable_outs) {
// //             // there is a first pass which rejects blackballed outputs, then a second pass
// //             // which allows them if we don't have enough non blackballed outputs to reach
// //             // the required amount of outputs (since consensus does not care about blackballed
// //             // outputs, we still need to reach the minimum ring size)
// //             if (allow_blackballed) break;
// //             allow_blackballed = true;
// //             num_usable_outs = num_outs;
// //           }
// //           BigInt i;
// //           String type;
// //           if (amount == BigInt.zero) {
// //             if (num_found - BigInt.one <
// //                 BigInt.from(recent_outputs_count + pre_fork_outputs_count)) {
// //               do {
// //                 i = gamma!.pick();
// //               } while (i >= (segregation_limit[amount]?.item1 ?? BigInt.zero));
// //               type = "pre-fork gamma";
// //             } else if (num_found - BigInt.one <
// //                 BigInt.from(recent_outputs_count +
// //                     pre_fork_outputs_count +
// //                     post_fork_outputs_count)) {
// //               do {
// //                 i = gamma!.pick();
// //               } while (i < (segregation_limit[amount]?.item1 ?? BigInt.zero) ||
// //                   i >= num_outs);
// //               type = "post-fork gamma";
// //             } else {
// //               // std::cout << "gamma called4 " << std::endl;
// //               do {
// //                 i = gamma!.pick();
// //               } while (i >= num_outs);
// //               type = "gamma";
// //             }
// //           } else if (num_found - BigInt.one <
// //               BigInt.from(
// //                   recent_outputs_count)) // -1 to account for the real one we seeded with
// //           {
// //             // std::cout << "num_found - 1 " << std::endl;
// //             // triangular distribution over [a,b) with a=0, mode c=b=up_index_limit
// //             int r = gamma!.gammaDistribution.randomIndex(
// //                 1 << 53); // Generates a random integer in [0, 2^53)

// //             double frac = sqrt(r / (1 << 53));
// //             i = BigInt.from((frac * num_recent_outs.toInt())) +
// //                 num_outs -
// //                 num_recent_outs;
// //             // just in case rounding up to 1 occurs after calc
// //             if (i == num_outs) i -= BigInt.one;
// //             type = "recent";
// //           } else if (num_found - BigInt.one <
// //               BigInt.from(recent_outputs_count + pre_fork_outputs_count)) {
// //             int r = gamma!.gammaDistribution.randomIndex(
// //                 1 << 53); // Generates a random integer in [0, 2^53)

// //             double frac = sqrt(r / (1 << 53));
// //             i = BigInt.from((frac *
// //                 (segregation_limit[amount]?.item1 ?? BigInt.zero).toInt()));
// //             // just in case rounding up to 1 occurs after calc
// //             if (i == num_outs) {
// //               i -= BigInt.one;
// //             }

// //             type = " pre-fork";
// //           } else if (num_found - BigInt.one <
// //               BigInt.from(recent_outputs_count +
// //                   pre_fork_outputs_count +
// //                   post_fork_outputs_count)) {
// //             int r = gamma!.gammaDistribution.randomIndex(
// //                 1 << 53); // Generates a random integer in [0, 2^53)

// //             double frac = sqrt(r / (1 << 53));
// //             i = BigInt.from((frac * num_post_fork_outs.toInt())) +
// //                 (segregation_limit[amount]?.item1 ?? BigInt.zero);
// //             if (i ==
// //                 num_post_fork_outs +
// //                     (segregation_limit[amount]?.item1 ?? BigInt.zero)) {
// //               i -= BigInt.one;
// //             }
// //             type = "post-fork";
// //           } else {
// //             int r = gamma!.gammaDistribution.randomIndex(
// //                 1 << 53); // Generates a random integer in [0, 2^53)

// //             double frac = sqrt(r / (1 << 53));
// //             i = BigInt.from((frac * num_outs.toInt()));
// //             if (i == num_outs) i -= BigInt.one;
// //             type = "triangular";
// //             // just in case rounding up to 1 occurs after calc
// //           }
// //           if (seen_indices.contains(i)) {
// //             continue;
// //           }
// //           seen_indices.add(i);
// //           pick[type] ??= {};
// //           pick[type]!.add(i);
// //           add_output_to_lists(DaemonGetOutRequestParams(amount: amount, index: i));
// //           num_found += BigInt.one;
// //         }
// //         while (num_found < BigInt.from(requested_outputs_count)) {
// //           add_output_to_lists(
// //               DaemonGetOutRequestParams(amount: amount, index: BigInt.zero));
// //           num_found += BigInt.one;
// //         }
// //       }
// //       final lastPart = req.sublist(start)
// //         ..sort((a, b) => a.index.compareTo(b.index));
// //       req = [...req.sublist(0, start), ...lastPart];
// //     }

// //     int offset = 0;
// //     while (offset < req.length) {
// //       const int chunk_size = 1000;
// //       int outChunSize = min(req.length - offset, chunk_size);
// //       List<DaemonGetOutRequestParams> chunkRequest = [];
// //       for (int i = 0; i < outChunSize; i++) {
// //         chunkRequest.add(req[offset + i]);
// //       }
// //       offset += chunk_size;
// //       final outs = await getOuts(req);
// //       daemon_resp.addAll(outs.outs);
// //     }
// //     Map<BigInt, int> scanty_outs = {};
// //     int base = 0;

// //     // print("len ${daemon_resp.length}");
// //     for (final td in selectedTransafers) {
// //       int requested_outputs_count = base_requested_outputs_count +
// //           (td.isRCT
// //               ? CRYPTONOTE_MINED_MONEY_UNLOCK_WINDOW -
// //                   CRYPTONOTE_DEFAULT_TX_SPENDABLE_AGE
// //               : 0);
// //       List<OutsEntery> out = [];
// //       final mask = td.isRCT
// //           ? RCT.commit(xmrAmount: td.outInfo.amount, mask: td.outInfo.mask)
// //           : RCT.zeroCommit(td.outInfo.amount);
// //       BigInt num_outs = BigInt.zero;
// //       BigInt amount = td.isRCT ? BigInt.zero : td.outInfo.amount;

// //       /// true
// //       bool output_is_pre_fork = true;
// //       if (is_after_segregation_fork &&
// //           m_segregate_pre_fork_outputs &&
// //           output_is_pre_fork) {
// //         num_outs = segregation_limit[amount]?.item1 ?? BigInt.zero;
// //       } else {
// //         for (final h in histogram) {
// //           if (h.amount == amount) {
// //             num_outs = h.unlockedInstances;
// //             break;
// //           }
// //         }
// //       }
// //       bool use_histogram = amount != BigInt.zero;
// //       if (!use_histogram) {
// //         num_outs = gamma!.num_rct_outputs;
// //       }
// //       bool real_out_found = false;
// //       for (int n = 0; n < requested_outputs_count; ++n) {
// //         int i = base + n;
// //         if (req[i].index == td.outInfo.globalIndex) {
// //           if (BytesUtils.bytesEqual(daemon_resp[i].key, td.outInfo.publicKey)) {
// //             if (BytesUtils.bytesEqual(daemon_resp[i].mask, mask)) {
// //               if (daemon_resp[i].unlocked) {
// //                 real_out_found = true;
// //               }
// //             }
// //           }
// //         }
// //       }
// //       if (!real_out_found) {
// //         throw DartMoneroPluginException(
// //             "Daemon response did not include the requested real output");
// //       }
// //       out.add(OutsEntery(
// //           index: td.outInfo.globalIndex,
// //           key: CtKey(dest: td.outInfo.publicKey, mask: mask)));
// //       // then pick outs from an existing ring, if any
// //       // if()
// //       for (int ring_pick_idx = base;
// //           ring_pick_idx < base + requested_outputs_count &&
// //               out.length < fake_outputs_count + 1;
// //           ++ring_pick_idx) {
// //         // print("come here ${out.length}");
// //         final attempted_output = secret_picking_order[ring_pick_idx];
// //         // print("attempted_output ${attempted_output.index}");
// //         // print(ring_pick_idx);
// //         int i;
// //         for (i = base; i < base + requested_outputs_count; ++i) {
// //           if (req[i].index == attempted_output.index) {
// //             break;
// //           }
// //         }
// //         // print("i $i");
// //         // print("base: $base");
// //         // print("requested_outputs_count ${requested_outputs_count}");
// //         if (i == base + requested_outputs_count) {
// //           throw DartMoneroPluginException(
// //               "Could not find index of picked output in requested outputs");
// //         }

// //         tx_add_fake_output(
// //             out,
// //             OutsEntery(
// //                 index: req[i].index,
// //                 key:
// //                     CtKey(dest: daemon_resp[i].key, mask: daemon_resp[i].mask)),
// //             td.outInfo.globalIndex,
// //             daemon_resp[i].unlocked);
// //       }
// //       outs.add(out);
// //       if (out.length < fake_outputs_count + 1) {
// //         scanty_outs[td.isRCT ? BigInt.zero : td.outInfo.amount] = out.length;
// //       } else {
// //         out.sort((a, b) => a.index.compareTo(b.index));
// //       }
// //       base += requested_outputs_count;
// //     }
// //     if (scanty_outs.isNotEmpty) {
// //       throw DartMoneroPluginException("not enough outs to mix");
// //     }
// //   }
// //   return Tuple(outs, valid_public_keys_cache);
// // }

// // bool tx_add_fake_output(
// //     List<OutsEntery> outs, OutsEntery out, BigInt realIndex, bool unlocked) {
// //   if (!unlocked) return false;
// //   if (out.index == realIndex) return false;
// //   if (outs.isEmpty) return false;
// //   if (outs.contains(out)) return false;
// //   // if (!validPublicKeysCache
// //   //         .any((e) => BytesUtils.bytesEqual(e, out.publicKey)) &&
// //   //     !RCT.isInMainSubgroup(out.publicKey)) {
// //   //   return false;
// //   // }
// //   // validPublicKeysCache.add(out.publicKey.clone());
// //   // if (!validPublicKeysCache.any((e) => BytesUtils.bytesEqual(e, out.mask)) &&
// //   //     !RCT.isInMainSubgroup(out.mask)) {
// //   //   return false;
// //   // }
// //   // validPublicKeysCache.add(out.mask.clone());
// //   outs.add(out);
// //   return true;
// // }
