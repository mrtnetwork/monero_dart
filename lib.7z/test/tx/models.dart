// // ignore_for_file: non_constant_identifier_names, camel_case_types

// import 'package:blockchain_utils/blockchain_utils.dart';
// import 'package:monero_dart/src/address/address/address.dart';
// import 'package:monero_dart/src/crypto/types/types.dart';
// import 'package:monero_dart/src/exception/exception.dart';
// import 'package:monero_dart/src/models/test/output_info.dart';
// import 'package:monero_dart/src/models/transaction/transaction/transaction.dart';

// import 'methods_test.dart';
// import 'n_models.dart';

// class TxSourceEntry {
//   List<OutputEntry> output_entry = [];
//   BigInt? real_output;
//   RctKey? real_out_tx_key;
//   List<RctKey> real_out_additional_tx_keys = [];
//   BigInt? real_output_in_tx_index;
//   BigInt? amount;
//   bool rct = false;
//   RctKey? mask;
//   MultisigKLRki? multisigKLRki;
// }

// class tx_destination_entry {
//   BigInt amount = BigInt.zero;
//   final MoneroAddress address;
//   tx_destination_entry({required this.amount, required this.address});
// }

// class TxConstructionData {
//   List<TxSourceEntry> sources = [];
//   tx_destination_entry? change_dts;
//   List<tx_destination_entry> splitted_dsts = [];
//   List<TransferTx> selected_transfers = [];
//   List<int> extra = [];
//   BigInt? unlock_time;
//   bool use_rct = false;
//   bool use_view_tags = true;
//   List<tx_destination_entry> dests = [];
//   int? subaddr_account;
//   List<int> subaddr_indices = [];
//   int? construction_flags;
// }

// class PendingTxTest {
//   MoneroTransaction? tx;
//   BigInt dust = BigInt.zero;
//   BigInt fee = BigInt.zero;
//   bool dust_added_to_fee = false;
//   MoneroAddress? change_dts;
//   List<TransferTx> selected_transfers = [];
//   String? keyImages;
//   RctKey? txKey;
//   List<RctKey> additional_tx_keys = [];
//   List<MoneroAddress> dsts = [];
//   List<MultisigSig> multisig_sigs = [];
//   MSecretKey? multisig_tx_key_entropy;
//   TxConstructionData construction_data = TxConstructionData();
// }

// class TestTx {
//   List<TransferTx> selected_transfers = [];
//   List<tx_destination_entry> dsts = [];
//   List<bool> dsts_are_fee_subtractable = [];
//   MoneroTransaction? tx;
//   PendingTxTest ptx = PendingTxTest();
//   int weight = 0;
//   BigInt needed_fee = BigInt.zero;
//   List<List<OutsEntery>> outs = [];
//   bool add(tx_destination_entry de, BigInt amount, int original_output_index,
//       bool merge_destinations, int max_dsts, bool subtracting_fee) {
//     if (merge_destinations) {
//       int i = dsts.indexWhere((e) => e.address == de.address);
//       if (i.isNegative) {
//         if (dsts.length >= max_dsts) {
//           return false;
//         }
//         dsts.add(tx_destination_entry(amount: amount, address: de.address));
//         dsts_are_fee_subtractable.add(subtracting_fee);
//       } else {
//         dsts[i].amount += de.amount;
//       }
//     } else {
//       if (original_output_index > dsts.length) {
//         throw DartMoneroPluginException("original_output_index too large");
//       }
//       if (original_output_index == dsts.length) {
//         if (dsts.length >= max_dsts) return false;
//         dsts.add(de);
//         dsts.last.amount = BigInt.zero;
//         dsts_are_fee_subtractable.add(subtracting_fee);
//       }
//       final dest = dsts[original_output_index];
//       if (dest.address != de.address) {
//         throw DartMoneroPluginException("Mismatched destination address");
//       }
//       dest.amount += amount;
//     }
//     return true;
//   }

//   List<tx_destination_entry> get_adjusted_dsts(BigInt needed_fee) {
//     BigInt dest_total = BigInt.zero;
//     BigInt subtractable_dest_total = BigInt.zero;
//     List<int> subtractable_indices = [];
//     for (int i = 0; i < dsts.length; ++i) {
//       dest_total += dsts[i].amount;
//       if (dsts_are_fee_subtractable[i]) {
//         subtractable_dest_total += dsts[i].amount;
//         subtractable_indices.add(i);
//       }
//     }
//     if (subtractable_indices.isEmpty) {
//       return dsts;
//     }
//     if (subtractable_dest_total < needed_fee) {
//       throw DartMoneroPluginException("subtractable_dest_total");
//     }
//     // List<tx_destination_entry> res = dsts.clone();
//     BigInt subtractableRemaining = needed_fee;
//     BigInt amountToSubtract = BigInt.zero;
//     int siIndex = 0;
//     while (subtractableRemaining > BigInt.zero) {
//       // Set the amount to subtract initially to spread it equally across all subtractable indices
//       if (siIndex == 0) {
//         amountToSubtract =
//             subtractableRemaining ~/ BigInt.from(subtractable_indices.length);
//       }
//       final d = dsts[subtractable_indices[siIndex]];
//       if (d.amount <= amountToSubtract) {
//         throw DartMoneroPluginException(
//             "Amount is too low to subtract the fee.");
//       }
//       subtractableRemaining -= amountToSubtract;
//       d.amount -= amountToSubtract;
//       siIndex++;
//       // Wrap around to the beginning if we've reached the end of subtractable indices
//       if (siIndex == subtractable_indices.length) {
//         siIndex = 0;
//       }
//     }
//     return dsts;
//   }
// }
