import 'package:blockchain_utils/crypto/quick_crypto.dart';
import 'package:blockchain_utils/helper/helper.dart';
import 'package:blockchain_utils/utils/binary/utils.dart';
import 'package:blockchain_utils/utils/tuple/tuple.dart';
import 'package:monero_dart/src/crypto/models/ct_key.dart';
import 'package:monero_dart/src/crypto/ringct/bulletproofs/bulletproofs.dart';
import 'package:monero_dart/src/crypto/ringct/utils/generator.dart';
import 'package:monero_dart/src/crypto/ringct/utils/rct_crypto.dart';
import 'package:monero_dart/src/crypto/types/types.dart';
import 'package:monero_dart/src/models/transaction/signature/rct_prunable.dart';
import 'package:monero_dart/src/models/transaction/signature/signature.dart';
import 'package:test/test.dart';

void main() {
  BulletproofsGenerator.init();
  _test();
}

void _test() {
  test("range proof padded bulletproof", () {
    const rands = [
      "ee4fde0d43e38743dd98e1c7d7a3f83cad5c21ef1267d41e500feca22af97903",
      "bbf7a73d9ce14dd1d3afbf04d0b612501f648e1d9efb7c454fc3afb06c09e304",
      "e8b57c9dc406cce9c00f36893978d68698fd932352cb7eba5de50afa7145740f",
      "c1111e8057328db62c0b55ecd60938efb7e7af8025f8a530c26d223281d14205",
      "1ea8cd77cd9f81fede042951c999ddaea14cdd609c1b741cce89b79b0dab3506",
      "2cfbb652caf90c118fc3a74aaa023e994e60e47e47522a891515e806944b8b03",
      "b0f97e9c988e0436f8e940ac82f95487b2645c32d6e5743a602e9a77448a6a03",
      "7bf7961528e2b36168bfa60e229e94438a7abfb2bd8fa741ddc9e65bb35dd50e",
      "a9ddd9283c0f8eba3c63d391582dfd3239fd09f177328bfc3dfb7a8cdb745f08",
      "30ccca17e5c558c492786f1806718316ae2a522fc3ea2aa014a939069937e80e",
      "080c1f44d118a8a848689b6f5314b3c31f7fbf86766a592f2ddbf350afe22c07",
      "fb9f4d2278477960d211c297f62afe80f2d2f06a1e61d2650ec3947f0709d704",
      "ce0c592451f7523245512824d98a557474362a6625d0594125f3fc441881460b",
      "f4829c45b80dd7bfeff97b604550315bb3df0a4c94df7344db5b3a4a75dd5404",
      "c93a94ecf586b2bc48f36b8741979ffceb9ff63e0b7b1d1ff1fe1b3beb49e906",
      "e5e4adc3099258623a798437b2a91aa1adb520969c1aa6d288b81f2588f46901",
      "4ce2f8263d765b71da952a8f8afd06d7db7fd3721c497155d1d5fde77aff9b09",
      "51f27448cf48991d7e002693fc8dabfd654be1637cc10755b24f656f67060803",
      "3fd724b69b24944a3a0ad1791f7c9bab8ed5911f411be4df3a31fd4cbbd1260c",
      "d5ea974829168b5ce73654fda4c3019ea7695458e8143065c1d94a86f07af801",
      "86e5d0b19cabe11a877a25cca81ce797584ca5907d8da5575a97058a02db4202",
      "124f19ab9eec52068176fa3706d0a151cebaa4e4820bd13976a393c9eedaf00d",
      "ff1f5eccf49161595bf0988fb84b74867e45ef73625aef223b52003255bcda00",
      "76adeebd961c8b8118c3ae66ac98de09d53fa92e84d5b2392279bf250210cb00",
      "258a48eb6aefb39c249d0e2dbd717aa1e7054ea6c5606355b50a6c6b4c035604",
      "8fe0751070b595ee78df064ccb95a2ac81bf7ffd5054c38643084f566fc5a503",
      "e08a6cf240f5946efecf5f334690dc41e629cc9bb4c25d85cee15d895c3c8a01",
      "f6026dda1d8ae511021b9e104266b23de5e1e38ae3c5cc6e28be55505cfd8f0a",
      "9f1785295b303950f65ca385d33396d65968ab21f43fa0542ea23068755a8206",
      "6ca88a93f278eb6085b98e6069c4dad681d36bf30fd42554d45ce89ced882007",
      "48abf798f2223db08636068b58f11628c31a71ed4b8bce1e895f32caf5b2d100",
      "051ace8977e4118ea9b1a8ba709f2e3e7dffd40ef898f4ac1999761d3b60b00a",
      "b69265ceef9920d986a5f6933ef3eeb2e394221d04f319490e68361801031605",
      "cb2db507ee489718b149b866969fa4648b6d277ed92cda80c0da1eca1920840d",
      "dece9abccaa3d28a78b97f993e29014a934df83c88bed9b139c216f18567d10e",
      "54be75a7893f3b6f140efc9f212144077dd0096085bff240c5061121a90f6508",
      "ef052e3a9a98960ecc298727fc375bd1e2f3936557d5d6e30fb24113352eb20f",
      "5e617f6627a5d3ef6fa5338a27690bfeedd3f1921de6fe847a5eb0e1daa6d700",
      "0b34c9be4eaaf2da5ae0a4add771a1aa8eb26c2d00d5fa22cbe6a6185f6d1c0c",
      "4e640c3e68bc014280aff6006b03c204d9cec1feab65f018eb1c14496c22cc08",
      "79af502b93a4f926d98a197ce5f589ad7585837df240cd746e8815540c603a08",
      "a18a7cfa2a8bf3cfbcfbb6b073a2f98297657f65651cbef6fe58c375448ff30b",
      "30425453a8765524e008d0950b88b911c4d56e60bffb13baa221c297129e3001",
      "2003a106ada04c84276b3320a9e57f0e1383090b8e877c979029fa7fa267350e",
      "84c70db01098a2aacbe16a99b7635125f659eb6c4d3e0d84cc0ebe1643043f0c",
      "fc7c84f103c86433d64ff9e727acd899c8b9a2d3327feaab0e8756e4d788b009",
      "b440f17a2c99751f9901c0e41fb308bf3b51faaf5af709833b220340f3e8810b",
      "d0f4ad8ea5ee5aa546f08471010b1cd6772af69ec7663f376825b78f28069f02",
      "52a3f044edfe8821974f610b4b91ba2b047b2ac63a1f95a45eab4e1dbaa52601",
      "b28c5caecb9a5c3df4d30c8edc2953cfcbead93259dfe8c68587c0039d557708",
      "a92aaa57943d698ead5db6dbcf6bf901af42a259226cfdc003554e7e586cff09",
      "5f17c2baef2485df481838a9ffed7ffdfd964f012a3f86096b2d451061af2109",
      "e3a2c123a2b492ddc5048d25ffd3f2025f674bb8c5ffda956710b9d987ca9804",
      "e5afff9b43341118180d951323a8094405a07053e4b274bd502312f218ecfb03",
      "6fb5f0f05c4390082747c494bc56d4c552623c6a9ee5a95c0c2143d33d651d02",
      "58f93596500b7e3689333c333f441a48f3f172bc6f91f3c51e0248db51a0b50d",
      "565af5d8dd025ad4603096f08fedbb3e615b89d4a5d8cad216c793e40b81070c",
      "035636b2b911a1e02bf9fb510b41180841116f305b44656fbb6670315395fb0f",
      "538857eec35a6452fc2b341ca2393613bb6fe08f32807a047fa8ca2f1a19820a",
      "aa1e65893a330eb00699fefc9f8d1bce01f64069ef0ff345d7a4e5366be0b805",
      "b3fe5457dc7fc36de549cccd84db9c514d92aef08242ce65be1ac476890e2902",
      "29dc3a212f0251ec3ab5084f3b01eafa9b70c37a9e539b34f3c9c0c763f50208",
      "a85238e238b11142309b16e59fcdd6363fb340e1b5e1f1f038d45142d9e93b07",
      "4e0fb6481b36971adce9b43c572ece03c31fdec93d787209d29e7f2535533204",
      "6556a111600e30d77c91ab8b46a295bc512e9004fdbd4592d318431a6dcd1207",
      "e207f33970f2423c33bca7f34ebb0047773afe99fde616b853a571479aa2fc02",
      "bf380601ed92c2fe56d7e3429ae47ab3def0e27d9f3dbc18016d0dd3f8f7790e",
      "9b74bafc2d3bbe2a1c886003af9f9343a8efd5b20fb81b20890cae6769fcff01",
      "327e540113f1e03b02763220f263a097d0510ad109a7b155a4af13faafce0f0a",
      "287ae500fef52e5c531720b739d29b4c8506bd840a2b0619cf3791c96cacd805",
      "357c7c95a3d40dcbd7f37015a8e89f1b5ae474631cc2462870761347c13fd603",
      "3932228d117561e9c49f14efccb3f31003c8852f3f2c2db62ffb6548f8a2a20f",
      "5aa8e6187cde60af9ce670b0da5b0f6740cdde64f24ed7706e1c1f6a4ecaaf0d",
      "bcd37a98e7083bb9e14d14d63ba15db4e9dcadb213d3e709a5f19caa71f37c01",
      "6bd05182f8211cfa4674fcf5aada355c83b4b571b23f22ad09ce514b3a3dad0d",
      "0b54e673c61848f916ed8c69d0b551262345bf062fcb2b9b0cbf08b4863fc20c",
      "3683d15644e3cc0a7772bd4942fb5e49933d5ec783004f47786fb9980188fb0d",
      "8609ff2eee9bab080120b1f0a1e121acdc8be75ac77eac8806745071d21d3a0e",
      "44b7dbf5ad7a3911f836f3a5edf3b6a0feaed86f2030c72884496b628acaa409",
      "1ab1310d7cd8cc46e16f0bedf24805c443422d4740430dd9d94e05d7c2fe5e03",
      "7ebc39e2d13d08b42426c3cf91160e93f90f4f6e2cc4be66e192ed7307492c0d",
      "5c69244c91039bb8467e435433ee3440279245a193054fdaf5b8dc4b7ce04d03",
      "d4f2365480f1f19a4578f5c6c25ca0891d1c3da1fdb2dcdf39560a2d1d97360c",
      "d1813b5f9df351d2890c0d08588cdaaca40a24813ccbc4834f9655c6cb4a2703",
      "6d7732d14393ce2a3d60d0da69c0bdba0b2f18911601658cb24530b10064540a",
      "f015654419acaf9b0838b407ee1dd78d425a99da5fcd470986bf28c25b992802",
      "f4378e3b1c14be8890fec95658101d19f330dd9452b22d5ac1afe6be17f58d00",
      "a07edd449f7cfe86d1ab6b9035c00fde82a5f03495718d9492608d6f0c3e960c",
      "fd21276a6b6a2429e7412f366f11bc38929da5ce883d6d2bc22b7b3595f48c0d",
      "8a62458ea78c504db7897be6f085c9f98ee1f7cc0d65a1dd356f1d3d934c3205",
      "8abb295261b7a7eb4263904c213d33f67896a4e785b2bb0a5530c3b9c263d208",
      "a8455362afd07693ae63f1c5e3e73dc9b6bc3e260449cb42695a3ca59227a307",
      "50fe14638330ce4b719800dd7536e47d63ee23c1719488ed59ff7df270fe8403",
      "ca0b8223977b88412b04f283fa01f6b2079dca7d52f63f0644cb55faf5b5eb0d",
      "7bd3642166c4c28a6c6ed0ddd3035ccdc4024d7115da73b2155853154469cc09",
      "a481c969bf59c4a0bbbe49cc8c14b38c81f592ac40498d7d110768e16acb7808",
      "c43f6dc8accaf6d90d25f5fe690ec5a1851a0709401220e23606bfcc1b7d000a",
      "132d5b7a95b4905af352f4ade76ae5e2bee783e8d5ff5051b4ccf87a1a321c06",
      "02478b39f555b2dfff22b98cea4119f48365e459a9a3c494cadb302384c0bd04",
      "fd75b22fa17c41ac8e8553089496917d63908b52da1bb83b945d9bcf623fe503",
      "4127b715117172e7d962ec3b35ca160c81761714aa8c48f4280e4f2469195203",
      "dc7e46bc40e4598ee567975583c70a09d760a23f43265ec1654204b4ad0e2c05",
      "61b0dbcd06fe12693d3c31eab7deca7fb9117ac543938d24849a316ea6462406",
      "731f33174ee74ab9338f145f4863e93611fbc520a54b5bbbfc48e84f28b3bd0c",
      "9b16390390f17b525a7c0c1d2fc4128e21c0f80ca4c7ded01f784a8d59fea503",
      "062727ee544ef753ed27dcda3a6c700dcee712d705e6849fd8447b44dfecaa06",
      "9ac617431f55c31fc8e3696fbc50b206bdff29e047300674ecd29e72455de608",
      "c891916cddda4cedd9097d99932f75de21e04667b9ab05dc4e84afd86da58c0c",
      "867cdf81faea11828ca68fff3b4e35ab727fb4a62383de063e376432b9dfd201",
      "9de00a3c897f799e3e28cf6fc7ec76745c7af3aa99b6dbeb3b7257e524151603",
      "c5c9ef3b9f148797ec9514da8c01b4e0e620ae633514db4bc4cf0a936c19dd03",
      "d9fc42b5fc14cc90d1d13ff8939f68f254ebe509c6b8beb1da2c0203dc4d280b",
      "c45d135234f4054c46b9425a7adb8bb09378dcbb0996d00feea20781a785370c",
      "5fedae5e2ffb9031f908e1c1bccc50aaf9b425058fc634a78d8b7e6fe2571c07",
      "958a9fb6a8d0d3f1e868721a08dc4327718c207b4a306f0bfbc4aa95f22d1f0f",
      "c2c8c9ba510835ec5769ddf2b329a5326d9ca3c6d7059b8a91010635576a5b0e",
      "e5ae1943f1ce8e51888fd290611c97a686f0270755d501f3c643a6b47555ea00",
      "6a4d4cc948c107fd713960c5537c8369cfd28ea2f182b854a91d9205385dfe02",
      "25acb842c9d05c578d3e9ac8f9918940abc26b38b54ef5129fa3c3fbbbe59702",
      "6434de2b7293e2a70f249219e79289ca3412716c41e8dc78ee6b4cc0b3defd02",
      "c8d16525a5769c30d91fa3227dfcd922589d6e02e8fe3c89e8c189e51f86700d",
      "8b401bcf6b653cc0b77f092349747a65b7fc50382fb9fd8fa1b056715d8c780d",
      "49413338f213b7355bf5c6aecf148d8a600a6b422e15358b25a4b28e12cbe908",
      "7db8b569faa1e7bf9e7e8560da434bb38b81832073d66b1031ba3c7abaa9fe0e",
      "1d7568471f424b6cb7c72cd112dc0a75c42af235a3f3e143448c2197fa159307",
      "0a16de60ddca70892f6c2a8473aea923b539aea61dd79f7282bebe553fb96008",
      "dcca2b600abdb7f10a9f7ef71403c19cdec6b7039b1dd15457180fe6a6ecfb04",
      "75b56838d9a48f11690fc0c094363273cc9f1d31c9b242707a1678f7ec650d0b",
      "1810525c669bfe3bc75e1336d97c712fc8ac1dda68debaacb9946bc0c493a602",
      "40f2f35f7dc01f7c5b401edbb1ea543e007f1c210fcc603bbec997044c451805",
      "6b9d3d4f3772edef703b43e021235335ec657ad8a7919ac36f350f3d4649b20a",
      "5fe8d22ca719b774f877d7d5bf0839464cb83d2317fca33dd4bba40381a89304",
      "bef7213b170fedac5d3a4de344f4374afec45d458eaa36c7135569f334ff6d05",
      "10f423db9595d91f5cdd579efe6e15d271fba3b6e3a5c2823648f1c33be00801",
      "c160ee933de06fd282292fb47993bba9ea4777ae119290196e3751f97e0a2b09",
      "6aff42ae10c3d800b8d82653e9843867c258e97d9e4ecfc796444f55b317ba0d",
      "e7d48b49d1b65be32ff89a7c9775c527003d56001876f6fe87f74e1409a53902",
      "00a6a28a431208754d9f0cf0d3cf54303fb1119fdc086d74761316c42b8c8e01",
      "143326aa9ba3aa7cdde4f65bff330111c455a0bda6d8542403dfd1ff3634370a",
      "0a9f31af3f0727ed75f939e2a9277a3bcddfa2f11c18c901fc8ddca53e2a7a01",
      "4c824f061807013bdb2a7a67a9782488ac10abff696e89033cbb75c1c2b5dc07",
      "7c0b8e9c7b360464f91c303b439e118e14e903245a4481ebe7c2ca235ba4540c",
      "e1868a538c6d84567b74da512ce30e22b8018b2eed4a5b8254b6f53d8fa14a0d",
      "38e901b591ad2f48989a5a511611d476eb1528de6d5e54d858d6986a774df60f",
      "0a2e88d7961678ddecc777e2294ca90c0bddbb2cd5e5d0f48797b556ac97da0d",
      "d88c94ad6769a4038682baec296384f3586fb577d74767e5fc87a46f5aa7840c",
      "72f66c84c193692df276adadbeb856fdb353567a7c7008d01a10734eb5b6b70d",
      "5788974469507b32726b5f754cc82a4839d9ec1a2616ce0dc41531098d2d3a09",
      "d5a34508e2496d7e588e3c04984323ebb941522c5ab464e602a62bda8d295305",
      "22760e0a8932b6ce40c3800de9eb13f09c01482be9bdb2aadd9738050bfa2f05",
      "86e2ec2cfeedb3b6251a28cd93a3265e4aaaf2b97725f3d1d0be331592a9a609",
      "488c1799c54aef2a7c95bf8f6152519d1da068dc95200190e767e0b36e094806",
      "5010df732a8d110978973e55aef983e38efd07576f57c7e2d5ceceb2e48bbb00",
      "d7a69a9039bc87a984671e43d0085c37defe88e284df004349143365b5d4c80b",
      "73dbb1b4073dc86359a5e0a9c0311cbd15cdf692b08f95d825b7a5f2526eb106",
      "673294fbb618d022e6ac50d80a9741cdb74d869dec64ec742273d65371933206",
      "28375c38db65e5b86414651b1016839d5745435e54da5b0b2a108a0011db9f05",
      "beadf36327b5164ee96e6530ea2e195ae849f33fc9114aa3833038b1cfcad90f",
      "2d5185b18a0664ce43169a822128ecbe1c86c13b9404738b639c6af2b091fa04",
      "0cda8fea99510a3bf16abfb5851f206bc87a5f4b338676ea464e488c91903b0f",
      "91097560672a364fec8c290ba571e40243c3be1cb444b1aac8da4840e298100f",
      "b35f3321b37d83f65bef01f7945558e8e2b0cf1c28cee57cdc8be94c65e5b603"
    ];
    int index = 0;

    QuickCrypto.setupRandom(
      (length) {
        if (index >= rands.length) {
          index = 0;
          assert(false, "should not be here!");
        }

        return BytesUtils.fromHexString(rands[index++]);
      },
    );
    final List<BigInt> inamounts = [];
    final CtKeyV sc = [], pc = [];
    // CtKey sctmp, pctmp;
    inamounts.add(BigInt.from(4000));
    Tuple<CtKey, CtKey> f = RCT.ctskpkGen(inamounts.last);
    sc.add(f.item1);
    pc.add(f.item2);
    inamounts.add(BigInt.from(10000));

    f = RCT.ctskpkGen(inamounts.last);
    sc.add(f.item1);
    pc.add(f.item2);
    final List<BigInt> amounts = [];
    final KeyV amountKeys = [];
    // add output 500
    amounts.add(BigInt.from(13500));
    amountKeys.add(RCT.hashToScalar_(RCT.zero()));
    final KeyV destinations = [];
    final RctKey sk = RCT.zero(), pk = RCT.zero();
    RCT.skpkGen(sk, pk);
    destinations.add(pk.clone());
    final RCTSignature<RCTCLSAG, RctSigPrunableCLSAG> sig =
        RCTGeneratorUtils.genRctSimple_(
            message: RCT.zero(),
            inSk: sc,
            inPk: pc,
            destinations: destinations,
            inamounts: inamounts,
            outamounts: amounts,
            amountKeys: amountKeys,
            txnFee: BigInt.from(500),
            mixin: 3,
            rangeProofType: RangeProofType.rangeProofBulletproof,
            bpVersion: RCTType.rctTypeCLSAG);
    final verify = RCTGeneratorUtils.verRctSimple(sig);
    expect(verify, true);
    expect(sig.signature.message, RCT.zero(clone: false));
    expect(sig.signature.mixRing?.length, 2);
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].first.mask),
        "114a2d62b76e028e2df9a0703bfd8b37d7b61b2f2b6236c6efe9dbeee5fd2a4a");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].first.dest),
        "46c54fda991245e8b4c6de9a40d80841ab6c168a3141342db9a611c44e751791");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].last.mask),
        "f34aa067114d478968f3f55cc83328ac3ff64c6c591cc68f85d5df231bb035c5");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].last.dest),
        "01434cafd227843a774db2bc8bcd518fa1605e02593bfe725c0fb7cd9a23d7ea");

    ///
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].first.mask),
        "243b34f72804915de49d056dadcf05c10c6c9114fe5d7b8a1c5e046afb8e1b26");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].first.dest),
        "01d6dad81d39d74cd4a68ea4751e1074c6291b87b64771984d54de2bbd4fb242");

    expect(BytesUtils.toHexString(sig.signature.mixRing![1].last.mask),
        "a66219cc5e340871841d9b7b7637f876867bd55c56844d65e922ca01814c8d9c");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].last.dest),
        "68cbb0b0bab55bf86f62d22960d766fd42cbf16c5b40ff1e7f3520f1670f3bcf");

    expect(sig.signature.outPk.length, 1);
    expect(BytesUtils.toHexString(sig.signature.outPk[0].mask),
        "d8697a3858fbb639c3ca692c4cc81c72c0f45d99fabe46f2ca34067147cc98b1");
    expect(BytesUtils.toHexString(sig.signature.outPk[0].dest),
        "0737f62c8bfd63c2956091dfb1e060eb427881f097317b303352fe69ed47efec");
    final ecdh = sig.signature.ecdhInfo.cast<EcdhInfoV2>();
    expect(ecdh.length, 1);
    expect(
        BytesUtils.toHexString(ecdh[0].amount),
        "7b986ebab7c67708000000000000000000000000000000000000000000000000"
            .substring(0, 16));

    expect(sig.rctSigPrunable!.pseudoOuts.length, 2);
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.pseudoOuts[0]),
        "3c71d447530da9f8beaa4c10be3f08d245af878a5e2c6f78659f4d8e4437c4ef");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.pseudoOuts[1]),
        "dd34454c5bd07748ba10f3d5de48095c2bd75c3924fc6469a6d62262fb4a21fd");

    expect(sig.rctSigPrunable!.clsag.length, 2);
    expect(sig.rctSigPrunable!.clsag[0].s.length, 4);
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[0].s[0]),
        "673294fbb618d022e6ac50d80a9741cdb74d869dec64ec742273d65371933206");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[0].s[1]),
        "c9a784bee4d3a10e0b123aed3af5b3b3b1a91120252f2e75532722c23466060f");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[0].s[2]),
        "d7a69a9039bc87a984671e43d0085c37defe88e284df004349143365b5d4c80b");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[0].s[3]),
        "73dbb1b4073dc86359a5e0a9c0311cbd15cdf692b08f95d825b7a5f2526eb106");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[0].c1),
        "08d6c3d6b1803a1592a9788a773f9a9dfe77538f5aea71d2c19990b146a4d007");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[0].i!),
        "7e8625aea66a87a793997d65ed66a5cfd73d2cc50b637834a9875d112a17f24d");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[0].d),
        "7bfde3944bc1ff769b6db8bb7078b79484787ba3b85d20b012aa70358cd5bb4b");
    //
    expect(sig.rctSigPrunable!.clsag[1].s.length, 4);
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[1].s[0]),
        "2d5185b18a0664ce43169a822128ecbe1c86c13b9404738b639c6af2b091fa04");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[1].s[1]),
        "0cda8fea99510a3bf16abfb5851f206bc87a5f4b338676ea464e488c91903b0f");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[1].s[2]),
        "1dda0802f4b7a43881f000ec8717db4faab42efe1ebd00b9e6df9eb794dad20e");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[1].s[3]),
        "beadf36327b5164ee96e6530ea2e195ae849f33fc9114aa3833038b1cfcad90f");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[1].c1),
        "51d394fb0d5ecb7bda9bfab2072d52ccbcbc6ea118bb2d939bf594c6516c0e07");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[1].i!),
        "4f74275ddef90809e48697476ebf4332c0afbc1a9c15f26aa7df776a168a6be8");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[1].d),
        "97b72050a3273c0967b021985c50f092d5fd3d7945e1e1ce4a84b51ffb4aa243");
    //
    expect(sig.rctSigPrunable!.bulletproof.length, 1);

    final Bulletproof bulletProof = sig.rctSigPrunable!.bulletproof[0];
    expect(bulletProof.v.length, 1);
    expect(BytesUtils.toHexString(bulletProof.v[0]),
        "10f44612272545f0a17c3e00cb6659806743a9c6321befec72f0db7dd372d1f9");

    expect(BytesUtils.toHexString(bulletProof.a),
        "ad562593ae5e7f7c137acd45e5e35f050999d805128b95c99a311cbfdc03ea66");
    expect(BytesUtils.toHexString(bulletProof.s),
        "04b1259528390adbef41091c46bfeabd20f5492e2880b2266506f007533c3765");
    expect(BytesUtils.toHexString(bulletProof.t1),
        "b2502570d357f0ad6db9cb312e901fac4ef214af1604091cf8d114309da9add0");
    expect(BytesUtils.toHexString(bulletProof.t2),
        "e4fec2130833f356148384cf39b2e3f7a50c3090f61ff131d201b7904605c930");
    expect(BytesUtils.toHexString(bulletProof.taux),
        "41939679d2f29d76893388b6689dc48121a993508831c227e4cb3e1d0023eb04");
    expect(BytesUtils.toHexString(bulletProof.mu),
        "5a3fb6c8f239a7366732b674a9b2d841e4d4a9293538c0be5f2e2adf12e6f90d");
    expect(bulletProof.l.length, 6);
    expect(BytesUtils.toHexString(bulletProof.l.first),
        "af155edaebb1340060f5a7b8d9dc9a8fac570883d7fb4f1967cbc79d1191996a");
    expect(BytesUtils.toHexString(bulletProof.l.last),
        "d26379ca5aff63c3e91ebd26344fd07a54c35f43df1bd7b2360068c6d8be8429");
    expect(bulletProof.r.length, 6);
    expect(BytesUtils.toHexString(bulletProof.r.first),
        "ff29cad6bcd790617a9956c9581a31f4de21aa3c130ea3668e7d968391c1f348");
    expect(BytesUtils.toHexString(bulletProof.r.last),
        "f5b3e3c7aa88df7c10032c16ab798c283786a7fbf369354c39f30a78e24cbd8c");

    expect(BytesUtils.toHexString(bulletProof.a_),
        "96f024bc3ef0e7d2b4b1d31223f032f36db5a853e33020ed24e2bed6c468e608");
    expect(BytesUtils.toHexString(bulletProof.b),
        "b8f176fc27c3d348c7958a2937585626bc7613b904d80102da32ef183bc8e604");
    expect(BytesUtils.toHexString(bulletProof.t),
        "7e0d869005567d48ada9fc8225aafef95e518f82140ef80af382e981c9b14a06");
  });
}
