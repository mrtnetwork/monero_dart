import 'package:blockchain_utils/crypto/quick_crypto.dart';
import 'package:blockchain_utils/helper/helper.dart';
import 'package:blockchain_utils/utils/binary/utils.dart';
import 'package:blockchain_utils/utils/tuple/tuple.dart';
import 'package:monero_dart/src/crypto/models/ct_key.dart';
import 'package:monero_dart/src/crypto/ringct/bulletproofs/bulletproofs.dart';
import 'package:monero_dart/src/crypto/ringct/utils/generator.dart';
import 'package:monero_dart/src/crypto/ringct/utils/rct_crypto.dart';
import 'package:monero_dart/src/crypto/types/types.dart';
import 'package:monero_dart/src/models/transaction/signature/rct_prunable.dart';
import 'package:monero_dart/src/models/transaction/signature/signature.dart';
import 'package:test/test.dart';

import '../bullet_proof_plus/t1_test.dart';

void main() {
  BulletproofsGenerator.init();
  _test();
}

void _test() {
  test("range proof padded bulletproof", () {
    const rands = [
      "43e4570d70e372d6f182576e12ac03d67d08916b7d1ff2086cf996832178ab06",
      "830b6025e5aa47a27eda67e2f47fc3f2b60618198799dd9d7518641d5602c603",
      "7ba5466a1a4e686731846e5a88f0b083b4773544793938d526587c5166526b06",
      "68e651b2f3979a181d19b54a9752379bb0586aca86b4794b7248a3c2dec11401",
      "fc92122e385a51be9244fd19015de8f1201f2c3d28d0e0bc2956a7f10f49d108",
      "624970cd0079a0ff47b451e23662fbda92122fda736f6cbdd1a0d5a309513104",
      "c30d63638b081a24e872fc9346fc07c9844efb4492c735c325b48d5b09e7ad0a",
      "3d21f0eadafd6a8abac8be457b1d315a3e38928732e0b5d34e58d9baeb73bf09",
      "eb6b97d7ae87fed0363a1d960e508b9fb430ce9bf0cca8c76dabbec39029fc08",
      "fa37698de2986346a11f9e107d090c9785c6d03fc6f3be8c8f51f838dd087206",
      "956b909e1530b92a3699f19d563fb38d86fb23787c9210c14263ce756ed05204",
      "7b0dacd9c1d370207b11fcdc6422e6738f7d54539b774ba7ef1df6ad5e5b6503",
      "4a7b00265ab517e29c7fdddf052a73c04e3c19505739c49a92faae6f49051300",
      "7e504afe77015ec2d659ced3574b5003deff15954cf1d49799308e816ebd3609",
      "233ee66ae3c9ab5acdb93dc399621c07684f0ff1468da06cfe25deb6bc778301",
      "470785ab2deabe82b7b6e83248e11cfa60d9e172c620ecb40a0c0bdfbf3b0f0f",
      "e0fd4ed54a369a3cd73a0c0f987f39a827d632c479ef66278336caefd80dee02",
      "86d5d7ff5440c472b9d09d55aa778e5fe855aaab3327d14b16581ff49bb0810b",
      "c87acf1ce8061cd3755d03ed44779f5661a51b8606c1f2d5d984329aa4071b03",
      "8687022586dbc0efca77d5de4bfeb77e050a4d528e01018df415186f1fcba30f",
      "bb4fa1bb89f08757a3c1416252e3451122933dbc58be459ae37f068e3e1a1905",
      "864950d57d6e0a4d1479f491e9d772164b392811ff303322e5f50ae64c97c30a",
      "57794ba3318a2f13c94a4b11146ccffea0d15dc9484f6a889814e63a14f54701",
      "4d87ee5e357c807618efe62e83575d79a7b3a849dd10ff109f90da4c0a3ef30c",
      "db2b585706a13f97cf8b093b094def262da3484897a122c8288257354d2bf30c",
      "e8601baa2ca540b1ccc8a947864ea1527dd38ac74a54097da1b8a44214a20d0f",
      "e3fcb6724dd9aab209bb791a00fca651d6940d3c3967b3b071868d7ea2afc90f",
      "f8286d5b3a0937993114a4fc8de37d917b4609d93c18c0bb087b9b1193eaf807",
      "fd6ae9ba3072c4e33ba768a6af132ff96f874e9894cd78d3b6f766d0a1176902",
      "cb3103d24fb41f4b8bda51701efb1b65cad96d3b657d4dbf2b70a508d1fac209",
      "2314ea931d0de7bb17ac94d3d24ffbfa0415710860ab797203670d9168764102",
      "1ac14b4655f07e56d48009c83a959d5052e736ae2546a6ff7f67b1159a989e0f",
      "6f5958370d23b3a26b728b7ccea3e2b35add8afa4ae1befeae06ff43c8d43e07",
      "8de33caa87cd046e49cf38268f788c259f1d6eebfcef1d1d60d537ae8704570c",
      "e0b923c8763f1224019a9fa0e5467bc20cae920f04a442fa8d866af8f6d01105",
      "7d4f90ec9f8df1e701da39604c7d50c60802955cb12301eda58a5877c2fbae01",
      "d8ac5a147140bb6d927a7cb755ff05b768ba450faff5e625c9f78a7afa64630e",
      "013839c88ee33a9fee719fc91e2090fd1b61328380f6fec704386411efdc890d",
      "1582a3174c0688a1c777ad0e6e57dde35251adf9fe310b9fb1b0fbb10aca2902",
      "93e53c850d6bf319e4ab2b2b21dd11b862da23071e4a10767c6470678b01610c",
      "abe3fe1dd15266e157f1acddae44d6e7d840d575bd7289e24af0c1b7f0bc350b",
      "cc1f78381946ed09fcfdbdd25990f50325ce4cce15dcec482bb8915b60d93f00",
      "898034db4a7c0bf23b63b98ea8e4a545f8ba1c0889adbd8d557f6b64663c750d",
      "d7d2b3fe7b8fc90e54f8404a33bb70318881baa22f355c2fda65fb2f034a7f01",
      "a2e5735039f61bab4fa87c5daa044828eb68fbefee84fee2235781a9fd222000",
      "7f3a78a23cc85973ef4942bfea5ceb9a66708c4abc986746839441187b4b9803",
      "30e40ccf9c983fba034a2a2d90b2198de94ea70c200a0325c7e4525261148408",
      "98a4d7eb432a801917301d60d49d274dc1b81631d2ea02e2fb83bee9ff0a8a07",
      "c22494dc289e839bc194f38cccaf4136bf3f32972899da55a819b7c66679a307",
      "8314d499b0ae0d33c9bbcb0a8c7bf23a911b29011d406e9bfbcd1a069474bd0f",
      "fec7bf3d5d427234bdedceddddac5c878e44a4d6185b911945eb0d6d4202fa03",
      "4818c166f72c4147d0c3f136e522159f88f835c2391c9019315c6e70d84dcf01",
      "33b031fa945419907b1d750793af8e118db62422779ea74284a6190dda62640c",
      "596e2ef9f2a59c0b2744ce19d922dede3c2a67e727a8a0e2865ef2e20e938e09",
      "e07f9caeadb62c6a9a00082e1f57c62305dc92ca03a6331aec00e0f601453902",
      "7738254f3639b9139eb7fcc2ad4eb5271af87936f694b8c06611101b6c1e9000",
      "6da208a1014bba95bb79aed4b00e629e620c4e8fb5112115a6db4a9643eaf00c",
      "669332b4793777c14fb4a5ee826fd307a591f60d14e5de6b56e6544601a2ca0a",
      "95561baa3d655dae086baace83d31929027d1b654f664c311fa4efbc041ff607",
      "c4eb64beb7b8e265e3c9528e2d3718ecdc5589787c00fc0664bc8ea736f96200",
      "2effd1b157e7eb51645bfb87a3cbfb574bbeb995b3ee7f1f22d93c49bd7c2c06",
      "397a7e847fab8fcbc23f66e0e3f04b834eda1ae08a9737d65721d96b9d0c7609",
      "069e7835a3d254d7d329ecb0abb8372fc3b86faed81ffb3a93f1e39f30782b0b",
      "0b18de2388f330c1d7832321c5d8d1c6734716121899738113702d4a35478308",
      "9571bd0c1744420a6ad3dc38a4cf99aeb467b73ae819de27200c818ad6eb8706",
      "76e83dd8df54f38d26ead9cc605fe3243d58bd1748e5adc05afd924bda3c3703",
      "6ac14386f4b0c90d46923e6b3571a1b900c9723a39e1cfcac99b6a7d38ba7205",
      "f99bfc9ed908fb11b93a01539e6c0f486896effc052e1dae2611e5dc3249cb00",
      "c5c395db9c1950cb6907260088eaf558ce14478e94ba35daa652fc3b70222006",
      "45d930a5c76180fd9ec2f53cc075c00d825f8639473fa6cafcd51634bbdfa702",
      "f937540c7db2e380f3516605f0d19470d506f3c2af3606cd684ef025b948e90e",
      "4b6195845b8dc353cad2932626ad10357b8e8f1b3d872c999d0178a75a59250d",
      "449ebca8d195136fd74cecc32c16cb5e89d0db7c0e3ce0c6ac378d483039b90b",
      "8d58cabf6b1c3a89dc016ecc411a6eba480dc25b133928e45921eead31114903",
      "8e345e1852f1f5ca24d7da710ee8c179d8ed792d449a338ce06aeed019257207",
      "43cd42ad9197e28f99ce4ca0f4b43b719b5df64e4480b9d61ad074657a1df305",
      "18b65476a5c54402d0881ce46f7eee4104b102e35945061d4da159120ecfeb01",
      "a694dfa36073d356e082172d1e879fff8b040594fea2e8f7ba515083b52bd508",
      "5ebd9069db9b19416affd39ec8ca4e4d9e8b1286d718c25c760b07c9d4c4d90e",
      "a5fe6314127d80f75e6aee64c36306fba61dadac9ee92743fa4a83adb97e3709",
      "1ae26b2153c91f519c6db7058387cbb623caed95b9af0068e612347afb3bcb0e",
      "b2eb46728046962ec7753b20eb035e4a2e32b1e474652aa9b7b18de950aa660e",
      "640d0163b5c5d9768b5252beb00a99499cbbeb38af2220bd2765b83e494c6203",
      "2db790562535ff098e8933f13b229e34e8a6108efac12afa3877aef8a490eb0c",
      "ed013e2cb985dc60fff1a45420c802c88378fa96453695506b7052261ac2010b",
      "1f95550b07627b09c8904ed9fe56892d0df9f0b17e36a0fc41efbf1ab9fd850e",
      "3081df78f61ba2ef8c8fdc35aca5bbe9d1d52cf087340bfc9261a08d11288e0b",
      "77d94f1a8686cc6547ed0ac4a93dd63f5d749c02b96102586b320ec4e8daef0b",
      "b4f6c7405e9fc2c704ce957b2842ae07a69680aa349180e81b968c53834c6901",
      "476b62a562403879003f8eb1fdb4845d256b13e0583b528365485b91ca6f230a",
      "288879849ca4fe3a1e2d2d15ad5c9dccc88855438623da5b1e164c1787057b00",
      "747172215976711c134b230ebf7e2b6aa9475c0e83686d36bb1d9cc4f6303c08",
      "194fa1937f88df663fe80532d6dfd81fc6305c00b5745982d00d796551885e0f",
      "4d6ffa34f43ce0957ac482487ac2ba9317644969da7686737980624dd5fe9a07",
      "457d7a62402d60da86309c5b9c14a151f00449c6ab5fa05511a9b541309e4c08",
      "bcc00ea58f2c4bfc318e3ee597d79e352c42455a3ce013062457bc7270110006",
      "042adb5fd3173bfd64387ac91524dbfa906282eaef36f3cc2cf4b8a2a3565903",
      "6946b4dbb196f55e95f317dcd260674696d56e3c155b3f6df991ad99eb7e9001",
      "e6dcf1ca1815ab231d51c02e58f7b5c496390a52bd45b6143bc5405d7ae14b0f",
      "42b4f5e298c2ba1f5ab67c583222ce32c774f141d8ba21bc4c92f4aa71f7c308",
      "3e404a008bdd1f2f88e4d6dfa2911d31841321e21182173dc871483a11c65e04",
      "7f1bb946b479bc2a1b9716c98bbdc43999c7f7bf5076b4e76ba16eb2474dd501",
      "f00c0cc28b78402f8068ca7716f8fe62007bfb0a46e5e2dfb5bcb886f0256508",
      "0c1123940da5976f3157dc43e217bccec2e114a7e698007eca70dfc2449cec0e",
      "272705e1e3a72e2319161acc3dd39b8d31fe0681c403d8cab0f631c4cbcc3908",
      "05afff1b6bd0951743a755d01fb2fdce2b5399b510a13ac295a00061ea902409",
      "f5258bc43a456d368466729a55a5008cf8b2908cf00852bf96ac8f5ca4479f00",
      "16c2f41e6065d6c21614d45ee9b9a5567f9d7dc6e1d19f3244fccdd0c4391a07",
      "aad0f906ab312975d83d5e68f4e39e0aca8e3ed3b0adbd99a9c3edc4d5bf3401",
      "4efcffced0f1be2bc8327506fb0b0614bfdf1b3a9eb4e6a37691525c53ae800d",
      "53a3d5266c8dd0e606fefb993d5c0af5b8ff0fc3ae8bcb03d6a8ec5bd6179f05",
      "dd7b0fbc29d3dcd29be182648c7915dd73510d6260d5b69f543ab4764a7a4c0e",
      "00164973554cd2271016ba90fb42e99eb86bc7f0e62b1a739bcf2b6751e0a10b",
      "699b5d7a0d9b8288a2edd286dd18ee707a2b35d78a2c917b20585ef31225ba07",
      "273f97b6bcb3bd02bb40b6bb0968d0bbc8ef6ae24fa524fe1b01d2fffa6bb10b",
      "fc0045a3afc32e5cfab3144cb129b4fcfaebc2c6670b10704793b3db95cd770f",
      "5df4c948bd916d0fef2da51ffe29c58a8937f92b35373dbf9d58fd7a7ca0fb08",
      "4e4fe1b9154168e51fcf975a0df7c5b536239b267a368f1343e5889420988f01",
      "868d7efc6b6261760f44fb86a91c8e430f5ae7a981c21f69ced34d33f7e3410e",
      "04fd9b064355971e31956b27497d37a28372bcab73db79eee5887f1f50447c04",
      "670a46a8dda8961e372f2deb9b3b047578b637deb6bbd7d537eefecddfa98f05",
      "dce0aedff87660460bf5947706534cfadb253dbdf733b54a6d405b1a78c6d000",
      "34d4fbee08e3714434d2f4f3cd54c7d6ec8223dfe760b0236715c453cce31a09",
      "2fc1e626ba91655effbeacdf64a0dd8be0f1e0a7ab7ebac78c1a7fdef4bff407",
      "28ec244beec5fa5e5b35dd5bdda7836ba1e51e69e772fc6196ff238f82febd0b",
      "e81bf215921daaa7eaa95a4509e45ebc9e9502d72ca36952bcbb94e14e777f00",
      "b8f121dfd4991983f7098ac1b321d32f5a1f686cc34d9f1eac597c78ab2ac90d",
      "d894aa2e30379d13c2940613d38ae1ad998f81e4b0910d8985751f99224c660f",
      "3ceabfc5e01475efc0607db8faf59d252a51d838db6cac6e9490226464504e08",
      "9ea0275cd8c1d482daa943752008ef5709b7b2dc2dc523679466993089aaf206",
      "9d8966f1504f657b8728f84c2a35dcd89a80d3638f9ed5578339963e8ae92301",
      "a78a8cbffd8cdbefb796bb60f61220c8898b59fb19dcad9afd2bfcd6004a1201",
      "e21b688ea724be0d8eb1d5d72514cf0c232598e321682d52ad77f4d79296690e",
      "84154d556fc5fe4e30201a5349cc52137ed7e99c3bcf21bc810ad699dd98d002",
      "2b475133df8be820b698ec4fdb867fbb56c6f5cd41e87bd81966cb016edb7001",
      "8c2800023135d13465653b47b986ee92e5f014f8ea52142b39f9c8f558647b06",
      "5ca1cf14da5e3e5d0c5fb64b51d802f925d91cf3ffcdbd30699cc1766f5a9b0a",
      "cbf66515eef4a7a9e1ea22a82016e77e47ab70f564034766ae643f42682d5c08",
      "48a5f809d17070e25553a1c3a98a95430e7fecca310fd5e68b5db48a8d996208",
      "f2694e6d309f7782019b16478183b5d3e1fde972c9269ccda4246ef28582ff0f",
      "dae36e46795909e0f0a7b8203e52c70b2a4061fc6bdacc7cfd0e9a1ce668aa0f",
      "215ea942a74a6cd9ba31a48b5102112969a1f4cb654dc5170cd37ac5d3517905",
      "2b734eb5016d3858670b948eb873734c50e9631769398a83306c582311bf1209",
      "60fb4e08c96b723e790db060ce195e45ef93f820896c9e3674f2c92e6944270a",
      "8cdf9272a63686a4959021f3a960efcdc0d5fc43bb7fab58ed05611293cf2c04",
      "16cc0c456e68f3f214c79d50b0e8bfaae2f36082f9fe755395b7007b31baab00",
      "7c40be3c7736e6e8a9a1f15ee0bb840f586a1e87383fbfbe72ce3c4c609e2e00",
      "ef6688c47477fc6bd6f5458194cfa7df119ae8c9e37990965c5f68c66ce52f02",
      "fe55c3d23fd9b5e0356c0d1796ca37d16fb981d5f98fbe7dbcdda449ba629307",
      "9d1897fbbefe2f2cf469cf1eb2c7cf2115af40e35457323cd2d997acb4db640f",
      "d88bdc0923069007a4ad850e296351cea26480818fe17948b031698651b5b709",
      "9ec0b3e1017ba11d2195658eb88850afe10f26a7721409d8e0d1d96a06ebc702",
      "d4e31789bf7562f65ef425ad05f75617344200fd57ba43426b3734493dfd660c",
      "f6176bf4b4aa3185675e0a44337f7c9576ff258af003b3f380e4411830946400",
      "d33e5eb9378738a48ed12a2c67c3a00c12c0182f66f4f550cec37d86c357cc0f",
      "653efe524bd9d5c49d4f8ba387efd738d4572ea5ec7880960a215224c1cfc40d",
      "cd1f7d6479ba40b310cc3291b6155f146d03762953221c872ee6329b3f54200e",
      "978b81db1662b4e361de197592f0381c5927c75a68b187e1544453c9adf04c02",
      "d5e634cde6d5fe1eedabba34c1c740ebb4c8bbdb54256c7e72645360b4605a0e",
      "7ce872be6daf1ed19362186716efcabc78ebd6350ef531f7708b61814e82120b",
      "ba03cda981a514ab5187b1d017132439713f78a980f528518be9f0050c20db0f",
      "08d08d6821e09e895c705a27f50c041420b7dd27fd26b85406407e5735592c0b",
      "064e5dabb11cad659bad41312fe429c865e19e090803d77a2fa61878cbcd1204",
      "e65b6b739630da90aca9c0adb9c79e7765524403875a9ee4e11f35635ea05a06",
      "8d9fb59b15ccf10cea8e1e5e3f34ff64e5e4422b4d5d23cd9414e58433091806",
      "6551dc49c91d6524564d824c4f39b0f57bdf8190e3ffb3d9b85b71265d234e0b",
      "ccc3af687de89290126112c50eccf573c62cf86365c73edc3cffd2239acd360f",
      "04c6156786755c3578cb272364a25cb441ef65d788f33fba874eb1ae362c9409",
      "d0ecc80bbe498045821135032f4bcbec548f0660e6158bedae92455e40c68f03",
      "c6c31fd58310be84456a09dc91df091cdfdaacfdc2684b41bcf96616c938ca06"
    ];
    int index = 0;

    QuickCrypto.setupRandom(
      (length) {
        if (index >= rands.length) {
          index = 0;
          assert(false, "should not be here!");
        }

        return BytesUtils.fromHexString(rands[index++]);
      },
    );
    final List<BigInt> inamounts = [];
    final CtKeyV sc = [], pc = [];
    // CtKey sctmp, pctmp;
    inamounts.add(BigInt.from(4000));
    Tuple<CtKey, CtKey> f = RCT.ctskpkGen(inamounts.last);
    sc.add(f.item1);
    pc.add(f.item2);
    inamounts.add(BigInt.from(10000));

    f = RCT.ctskpkGen(inamounts.last);
    sc.add(f.item1);
    pc.add(f.item2);
    final List<BigInt> amounts = [];
    final KeyV amountKeys = [];
    // add output 500
    amounts.add(BigInt.from(13500));
    amountKeys.add(RCT.hashToScalar_(RCT.zero()));
    final KeyV destinations = [];
    final RctKey sk = RCT.zero(), pk = RCT.zero();
    RCT.skpkGen(sk, pk);
    destinations.add(pk.clone());
    final RCTSignature<RCTBulletproof, RctSigPrunableBulletproof> sig =
        benchmark(() => RCTGeneratorUtils.genRctSimple_(
            message: RCT.zero(),
            inSk: sc,
            inPk: pc,
            destinations: destinations,
            inamounts: inamounts,
            outamounts: amounts,
            amountKeys: amountKeys,
            txnFee: BigInt.from(500),
            mixin: 3,
            rangeProofType: RangeProofType.rangeProofBulletproof,
            bpVersion: RCTType.rctTypeBulletproof));

    final verify = benchmark(() => RCTGeneratorUtils.verRctSimple(sig));
    expect(verify, true);
    expect(sig.signature.message, RCT.zero(clone: false));
    expect(sig.signature.mixRing?.length, 2);
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].first.mask),
        "7548a1aa09471d630c79cba17c06104779fc67119ea48298ee1a6622ca991a86");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].first.dest),
        "fe7eab7cf9b95b580655255b46d73e6b3b590af5e1d9a099cbdd812fbe080420");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].last.mask),
        "5e194ab897a59a9b8f6abe67b97f03a157ad59e8f0de8c61f683575979286c28");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].last.dest),
        "ddefb15dc53682fa59c11b003bb2952a71735df6bdce77c03779230f0a8591ec");

    ///
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].first.mask),
        "d45d4b3d616091cd35d00623ccea64b18f51dbd4a51c496858c1297a134b76e7");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].first.dest),
        "fdc95062e4684eec88cfee230bda40ab4306718de8adcfd1c28e0f786d475447");

    expect(BytesUtils.toHexString(sig.signature.mixRing![1].last.mask),
        "eb4724076a291bc4e1c6c02ab18d466d5c520db18bca2194f78ef6ab3c23e8dc");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].last.dest),
        "e29b610b5c7b9240d8cf4ae7ee51f3ec831d955761100adffe169a69fe0d8c52");

    expect(sig.signature.outPk.length, 1);
    expect(BytesUtils.toHexString(sig.signature.outPk[0].mask),
        "d8697a3858fbb639c3ca692c4cc81c72c0f45d99fabe46f2ca34067147cc98b1");
    expect(BytesUtils.toHexString(sig.signature.outPk[0].dest),
        "5e5ab2a648e4bfddc408fd22becc45ffe2a9ef6b24ff5f083829ec40fe139923");
    final ecdh = sig.signature.ecdhInfo.cast<EcdhInfoV1>();
    expect(ecdh.length, 1);
    expect(BytesUtils.toHexString(ecdh[0].mask),
        "fec8361fe974af0d6545ea1ea6ca7191d29976eda826b1a0489b3502ba56700c");
    expect(BytesUtils.toHexString(ecdh[0].amount),
        "87499d8adb5a26568e497eb8e376a7d7d946ebb1daef4c2c87a2c30b65915506");

    expect(sig.rctSigPrunable!.pseudoOuts.length, 2);
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.pseudoOuts[0]),
        "d828fd15b722f9291f6f2f85b9fde5e89613cd20697a8b2e08ffe5e79e8b0d60");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.pseudoOuts[1]),
        "1b71e095adffa107070207e33a760f133ec3cf18ed4b4feab0d3907f67015a5e");

    expect(sig.rctSigPrunable!.mgs.length, 2);
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].cc),
        "4e19a305e743b92a48e821041c8d19ec33080dcccaf568ff8aab50a161015b01");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].cc),
        "12465d886f16fb70d87e37bf7d70cc8a6b73557a150bb978e4c8fc9a01bc6706");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ii[0]),
        "8023efefa3b7f12dace3f6f72e5a96144743e834f45966231e9c96cde7c9200e");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ii[0]),
        "746cc8fa16ab81855277c28511c6f71c31b39aa070e005463eae7966e17d8f39");
    for (final i in sig.rctSigPrunable!.mgs) {
      expect(i.ss.length, 4);
    }
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ss[0][0]),
        "d5e634cde6d5fe1eedabba34c1c740ebb4c8bbdb54256c7e72645360b4605a0e");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ss[0][1]),
        "7ce872be6daf1ed19362186716efcabc78ebd6350ef531f7708b61814e82120b");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ss[1][0]),
        "3b55f88cb7d6329993651674693f0f4281d5dcd14e0569e23471b30933fc1c06");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ss[1][1]),
        "522378f701797de769f5a57db32fd9be8f09939d9b80786accb3a337eab05402");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ss[2][0]),
        "d33e5eb9378738a48ed12a2c67c3a00c12c0182f66f4f550cec37d86c357cc0f");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ss[2][1]),
        "653efe524bd9d5c49d4f8ba387efd738d4572ea5ec7880960a215224c1cfc40d");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ss[3][0]),
        "cd1f7d6479ba40b310cc3291b6155f146d03762953221c872ee6329b3f54200e");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ss[3][1]),
        "978b81db1662b4e361de197592f0381c5927c75a68b187e1544453c9adf04c02");

    //
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ss[0][0]),
        "8d9fb59b15ccf10cea8e1e5e3f34ff64e5e4422b4d5d23cd9414e58433091806");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ss[0][1]),
        "6551dc49c91d6524564d824c4f39b0f57bdf8190e3ffb3d9b85b71265d234e0b");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ss[1][0]),
        "ccc3af687de89290126112c50eccf573c62cf86365c73edc3cffd2239acd360f");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ss[1][1]),
        "04c6156786755c3578cb272364a25cb441ef65d788f33fba874eb1ae362c9409");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ss[2][0]),
        "24f91dc91e222a74c2b0093f8a821fa278bc9e893566ea9682725d9642e0bc0c");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ss[2][1]),
        "86440fef484b1172076e106b09f1cf07192bd8036a1ef8210f5679ee5a34fc03");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ss[3][0]),
        "064e5dabb11cad659bad41312fe429c865e19e090803d77a2fa61878cbcd1204");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ss[3][1]),
        "e65b6b739630da90aca9c0adb9c79e7765524403875a9ee4e11f35635ea05a06");

    //
    expect(sig.rctSigPrunable!.bulletproof.length, 1);

    final Bulletproof bulletProof = sig.rctSigPrunable!.bulletproof[0];
    expect(bulletProof.v.length, 1);
    expect(BytesUtils.toHexString(bulletProof.v[0]),
        "10f44612272545f0a17c3e00cb6659806743a9c6321befec72f0db7dd372d1f9");

    expect(BytesUtils.toHexString(bulletProof.a),
        "760df3a0060cbdbcff624d14a45dcb3997540eae9d20886092bbe7b29e9eb433");
    expect(BytesUtils.toHexString(bulletProof.s),
        "8b2b21418b952b60cee429c9b49a365c9b5a88c8ee739b02aa8f7ffd0f66eaa8");
    expect(BytesUtils.toHexString(bulletProof.t1),
        "3e459c0d9315e0319e569c49c36144aa0f30093b9092879e462b852d571fd13c");
    expect(BytesUtils.toHexString(bulletProof.t2),
        "f176bc93771a64f835506a0b0fcbc330f0f22f08002e9487b61e632fe744f5b3");
    expect(BytesUtils.toHexString(bulletProof.taux),
        "445b41de02f92bf281071ca1f0a2d3713143ac8b6a1b0761a68f00c9c91ada07");
    expect(BytesUtils.toHexString(bulletProof.mu),
        "14a565967b2dca1378334d52f816ac835456b68fc17761605a9791020f08cf01");
    expect(bulletProof.l.length, 6);
    expect(BytesUtils.toHexString(bulletProof.l.first),
        "5b827ba6c32fb3171df0ca91821abef24e05661c87ac52a56c939f120a5baaaa");
    expect(BytesUtils.toHexString(bulletProof.l.last),
        "9d702e4c27c04289f378980e476e1cff04822530bd5f137dad6a0d9a2398c6de");
    expect(bulletProof.r.length, 6);
    expect(BytesUtils.toHexString(bulletProof.r.first),
        "66bd407d9356027fda2f46e58d74a4c2fca43e8aaf647b5ee937e6f9b8cb52b0");
    expect(BytesUtils.toHexString(bulletProof.r.last),
        "1c8a55cd13644bd40544f8ddd67c211b9371dce7c7b176e2fff17ca0c537bb0f");

    expect(BytesUtils.toHexString(bulletProof.a_),
        "e09ad99883ccdc21e8e768aa008d00b4df246d3ecab0a562f2af7531bb73b806");
    expect(BytesUtils.toHexString(bulletProof.b),
        "20322c9a137143eb426cc75909eca5fc797f4362284c0df0e37ea52ae313e207");
    expect(BytesUtils.toHexString(bulletProof.t),
        "8f91605b73b52d62b75ec39aab17887457a993916325febbc19580fdb78a950c");
  });
}
