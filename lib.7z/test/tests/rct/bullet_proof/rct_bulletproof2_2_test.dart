import 'package:blockchain_utils/crypto/quick_crypto.dart';
import 'package:blockchain_utils/helper/helper.dart';
import 'package:blockchain_utils/utils/binary/utils.dart';
import 'package:blockchain_utils/utils/tuple/tuple.dart';
import 'package:monero_dart/src/crypto/models/ct_key.dart';
import 'package:monero_dart/src/crypto/ringct/bulletproofs/bulletproofs.dart';
import 'package:monero_dart/src/crypto/ringct/utils/generator.dart';
import 'package:monero_dart/src/crypto/ringct/utils/rct_crypto.dart';
import 'package:monero_dart/src/crypto/types/types.dart';
import 'package:monero_dart/src/models/transaction/signature/rct_prunable.dart';
import 'package:monero_dart/src/models/transaction/signature/signature.dart';
import 'package:test/test.dart';

void main() {
  BulletproofsGenerator.init();
  _test();
}

void _test() {
  test("range proof padded bulletproof", () {
    const rands = [
      "870dcd38b53d3ecc2da19f2c1e96cb5c1c5cb69f06fe6129c278f9aa83b46f0b",
      "f280c08e1b388713756f93fb4e711c0661523ae28feb5e9968518f2491b3040e",
      "d0cf6eb6cf3ebb38424966230a56b0a5fea343c46b3dd8f3b11dda52e386330e",
      "85b8991dc7b892d44e07b9644246ddee2d04c94a81ab1c03f2f9d32724ecec0f",
      "1d807640fbefa4bc691f6d225617c08b9ee7ca8c5ea184ebcd798eccd4161402",
      "865724124ebed03c6ecedc9b511bc2e6a61e2589f612117dbd7788ee4387ac05",
      "084e8a54c5b96db54be83d7e42bb8ef7d584509eb1e44d36bfb3288a3d7c7d06",
      "e0818c79ca5fe0b7500183bd778cfe463b621ca08e76c9102c4326b1fcca410d",
      "70658cbe0003eb044d1c7e49ae318bbc926c94968ec487511a955412322d860b",
      "891c31802d8400259bff4e0115e579ed271c7bd5550eabbd98174a5cbcbb8304",
      "a8d7cf0d71ff11bef469418df72647429040dfae2b57157eba7bd8eb7a169603",
      "98ef38a448980cc742b7944942fe3e54ae8874434e77328e88bd042b45e6f901",
      "c6ab7cb9d5a8313751775a437b8c64bde75938489635deb8491c6841b80eef01",
      "8b463419ea95e3cb3e1e2112cadb8cff1ba7c0f805c2a6a60c6776ebbb61780c",
      "c388f14eaf7927d1ace743fc57ea6f6de2f93e2285ce5148fff839578965a701",
      "b9cdec41e673501f2c0e3eca3df824e80b7dbb7324b985ff8c05b37998c2220e",
      "4d98beb368da2ae8cb88b5d316f5aa54ed894de3ef55eb16a223fb20dde2d80c",
      "9609de344a0544fb702dd3ab838534889fb3c3e463385e8fec494bb5326b2e00",
      "8d6ddda857390cdc5951589f49631d989ceb61e76e9277d4a4bbcfd07c8cd900",
      "e507e92e58338f355ef3e6986f1f375c91fcc266c66ae01fb55c12bc050c0b0c",
      "b0f0c7dc498e42747146f97e5510cb7671902e643be5ba1bdf527fc4acdc6309",
      "1cce3022c81f68194ead1fa2c33a15a24006b5ee79f8006146fc12e13009d203",
      "c685c9e6d88fc627b94f4960f860c4c35a218a88402e302fc986d245eb007905",
      "b4e8ab0057b3a53b5b1d88e38a5ce08e65a42c2b97972483bf81d55167ea1b04",
      "6fa87872db7603597a9f8b6c8e662ea44781a59a8ce964089f59e7c832ff9202",
      "628364624071bbda7027d127ad4e4f862410546e8691cee7f7022f7163ffec07",
      "3c21f7cef66ac64218b178ce00aeb1912d7f051dcf837072cf6606fa58211c01",
      "4957ac51f6041bd7efe3acb06ab81bc87b94d28e7cae80004a9a834177986706",
      "1ea96b477283481878cf3431fb06f98efef3f2f38c1229229c8d8cd42289bb0b",
      "34149d50661c97673c37e9c868ced1caa39b36fe1d30dc95f9f26ec1c1e2b509",
      "01d69a6a9c7f610b9d7f2ed30cf2cc414c6a9491c9640017294056d684a05206",
      "7f7e48d9bd02e3c022f1321c4feb2406d938948433f3eba34146918d32be8b09",
      "11f4ce130b253c0888ee64e787e0d06cb94e7cf29d352823b6b2e4630aa2420e",
      "522685b0cbaed7ff01fd3528f3ae76812907540f9081bbddd6818bdf33121504",
      "16acb62afe6d96d8a8a78ab43ea5ea2adce6da47778dcf620bbd363a51df0009",
      "e25037a94a4f0f7a94858484f2f19dbdc3598112f7e8169fcd0c008d7639ec0d",
      "dc77dc155ac0d7cf3c49ae2e17d84a69bfd8d398cd9afaaac915de993577c903",
      "8345af804414a95c48a900f99769e6b97cd5ad46cfc56f21fe296e77927fdd05",
      "e2a77e6c9828c96c56d41ba2fbef1bca65570970e2e36145649a8a9efe5f930e",
      "fe9e1c67c608ba7d3a8121b0b2d4fc344e73e4c912741f11c420a79444442108",
      "09b04f5491ed01608e5de3458497e648a56fbd4d32546779b8bd2252945a3d01",
      "d74c179f4348e3ca5b5818b54d832718fb6314206713c7cead44c113b883ea0c",
      "180d2771f99300cd66530e1b01e1ef02344cfef8d3be0e34fc5e3879e4723402",
      "c12546bacb44067ec190afd92ef69e53bb6e3707b1d6ac89d50eed2df5596800",
      "78acf5c5dafbd965d325902fcc2ef399f7086b47e8b74388b2e2f8df01fd1000",
      "549b5d1099670f6d4aa386bc9dafa8685a78fa3c4ccc877e3cf265f99db2d805",
      "ce60cf1340fd7cf4809b18a7e43cfa39921bcb57cf6bbc9bd208863eab1eea09",
      "b04d34c4c889865093e3a2bdb3a0ed01767f50ecfca40c0a452085b24c84270a",
      "1760072b2fad61c298d47afdeed9f3784ef1923bbc422be28b3750221326ce0b",
      "b7e97ddd299f7448782fc9f20de253a83ab20d4fa754e61e3097a5c9a9ed0c0b",
      "c814aff66d42e917222f5674a07fe2fda3aa4ae419dc8a614be20262ee36500b",
      "fc27c53edce12f5113827af714a29591f25e7abf3c352d306803790854a8c300",
      "d0cef451c8b7bbe827bc7957c2598c952ddfbaf64ce2bc9a6664ff2560631807",
      "4c1a5c66be96a64d73237e4665804ab0b0cd70bd1bf147eb16ae8b11725e5706",
      "6382f2a435f0ffa374fad234b957e07ae65a95c3ae57fee0f2613c8bb294c90a",
      "7c7918be10fe8ca4d1ac3f479a9ad29e79f649acde646828dbb5c4ee1135c304",
      "c0eb41570b3661edafccfef590de8efa3d1a9ab33583a1b84cb0a9fe614e430d",
      "34b84220c929a081e4ccb53ef1f30fd13d74f58fe7378e1fde2342e7235f740d",
      "01c97e5b9a0f48d5d716df1cbb200ee34ddccbbb4aeaf409cac76285eac03102",
      "31d4fe40b23926563d84be9b4cc5a940e1ed3a18c047e26df713d2829556780f",
      "8bf94a0722839fc69c6d23ab780a45d08d0258d71ee2ef92617230fe1df8710f",
      "2464e75b29b8254f650a49802c1b2c8ec313dd29aad93cba772b072985bb180e",
      "d99503240155a904fda3f8d52198ee253e0ffa9dfdd05f42db2b3f539cc6380a",
      "7bb4e1af79aaa12b2004955c4f96b54dfdf0c461e60d412153343e0c0a85010d",
      "352a602a790c97aca8402c4fb258a6812d5eca24425f7ba0a16602afc2247b0b",
      "f38382084fd1b1072766a53b572465656e66af88256d523c93d91a3afa916504",
      "17fd067f037e8f45f88dbbdbb1d4530b4f4302dbacbcb98aafe2121b2570d00e",
      "1cc864f6c4c7dc37df810271e2d8d0627c6c295687f6269bc62aefeed3b9af09",
      "5c881586ec475d9e7a1abf693f9778c9e308341702f56b6d0260f7809bc38208",
      "2d2ea5a107357511c5b8b5c8a22f0ba96cf7bcb1d93df6801921d267e22bc304",
      "48b5b56e96a99380625c7a18d2ace6205cbdec1fbcb98b6a04e1edbc8763f20e",
      "c48d739a51dfefa1b7292f31963a74c80a660eb553f1d50f51ff741cb318b908",
      "41487fda068aa480ab5285f61990ce6b327d74e92d1486f6501b97383c4c6801",
      "0dcc0664a4985c089e6a35936016fc21102f8cf0d87faa21573810300a29b40c",
      "3e7913ab20e03381c0535768214b18c81de471db02d33b965e623f18f25a2a0f",
      "d1ed700f9d4d4b0e40b532d7764c6c645fc79ea97c5a6aa0b39147f2ff3af309",
      "e3ee92aa181001c0459a3a6e509ca1371b7ac5cdb43f68299d7517db1b363d07",
      "c25738c89e5856b28e2783eef6d2cb16a5c8854ab8fad1a26522478ef460ef0e",
      "1fa2b06e36757129e1c7e04b4906dc967395c6b9cdd6407eac9d0f708cf2700e",
      "09df772f5a34301b58219546f947946c11bc4c21d03cc1265cb2ad97ff841f01",
      "4655566ea844c4e9c67c120f0c24ef677639feeb67a94be55791adeaa707ee0c",
      "eea73c1c0b0a6b858d486736bd77ff71f162dacb3d4e95ce1ed8c9ba07a9b60a",
      "7ea3bdb1a289da18f7323cc7c25a98fb3ef54711540ccbd5744b235441a96d0f",
      "c4ff0d98588fb4948695f72e7d9cedc92820668f41c6ba9ce20afee9f62b8d0f",
      "7cb98ae5c4db44ba51d659e8fbaf3bda912469260d531d109efeb1d999765607",
      "8a57cd29ae060f0bcce17d194f10cac6e362946a06895d748de1897ad9e9e909",
      "1331abcf6c09b36e3102a702033ea55c3708e71df4cd22dd1aabe19ec0cb4702",
      "9447abbbeeebf072c0e042c108acf61b7ed8032f76637850c91ecf476d185b00",
      "dbec204009cae39f52905d26f7fee03eaff4b7ab8cadea184cb090c179b07409",
      "182595546f3799d10c29534955b32584f9d13cd0210e5a064096e15962c81505",
      "2b806967269601a86d5bc4c147786d34bd89e26ab797effed24426ffb4804902",
      "c084634f8793c3c4e79364d4b2a26d67d109f92c7831a8cc6eaf2f6de8bb3a0d",
      "3b43944931a9217c244321fa992b66c9872e45dcbe42e59ec77500e125db440c",
      "14c713b29c6a358a643338af0d9b36d97b7f69fe85423c6b54f7030b447b5209",
      "dc397f8812b06893e0e5a9198f4014d59ef9930089db7c82a11d00088b4f5b0a",
      "67ce1f57af8ac07e7771dcee0d230e8e392ae764448aad42aaab59ad0469ee01",
      "f6c64a829fde8608d2606cc1a444afeeeee2dc4ecc9b457c4b0d571af02ce90d",
      "cca4e501e2a57d3486c4640ba218670f9c4bf32c58c8632d82844c048890ff06",
      "f9e407f528a61c2d86ac46c051070ae749680e83f3eea3c951ccb8818ec7d802",
      "583bd99c93fa7a19758d29cdf059da1f3dc4bcfda476b572989a4419d1269e08",
      "617ae4c4a146d26e31faefb819a8935c189d4b5fb9f6a36275bd08bc201a4e04",
      "885c59f225cc95cb56ec8e92db5f28b43cfed7e9d0af5fe2e566d27b3429db05",
      "57a9c6b71831da19e6317978d882265c06006a9e11e447052216212d18dd230b",
      "45c1520e81a235850681dad98a6bcfda2f0e619e244e10ea643a8c3698691e04",
      "a60cfcde2357b241b42cf2ee785553ad7f2516e0753a05da02f7c2bb28ae9805",
      "e2d6f083bc0f60b12545b14363cdec753154f719779e4aa3c5d74e42a2cc9a0c",
      "e7e712b0de1ed57463cb490674d86d75e5bd886aa459448050446118b7767506",
      "43bcad7f99a01a4a3952b8289459956913a047c910fd23c713ef584807c0aa06",
      "4e792e6f8aecd6c1717557e89cfe6249420f0cc696694e7b784ac482cb802901",
      "d49444797c7c751691f2643aa1edb6d06a13eee5df40b258833c87a6a15f0900",
      "4a8490ae934047290bdd913db315a9c1e4ae48f9c3f6ecbd73e27dd7ee7c120c",
      "ba3ee96485b1a0cb9d8d652091fa8bae83f05a0743ea03bf1a5f5e47d394cb0d",
      "47bed3f726eee72b752526818ebd6a1e6849a98de6d060ab6a0e74988d18d709",
      "596dfe2c170a82fc482d3f6e2ef943abaeee9154a924668be75349b557a5c102",
      "9411d53b700f01b0ce022a4eb9ef0af69cded359157fff9a6e1c1c30b5210d06",
      "bd055801b456684a9917e03bbb95e4ce0f638a0bee7feb07be5e9a4581e4fb05",
      "a02cdb4057b15b59522f8618268aa2147b410fa7afe26f509f734336a3635b06",
      "3b5d7e007b1fc3f6581210e339614d8e3d0ec75ecea19155ff9ff865aed4050e",
      "3a20818e5b927b9ac857a7fc6aa586550e5de1b82f56a61a3d20acdb4c6bbb03",
      "8318baa47d5d1e79199a9e5f126ba4e35a46f3fa494331c603104ea890aa2400",
      "b89abd0ddf46ec74df06854139152c183b7a0b8e0919010a37c0de4b950c6e07",
      "b976a253493d0bcd6b260e35e55d0209808964cec58ba7d40ccc2a8f90c39b02",
      "833960d32589bc3de1e9309950573e7d69948c270e85c656f33375db4a7e7500",
      "bcebd0cbeb2f1755fa44c675d9f6140a86cfe432efe2075503fae2f8f5dd6d01",
      "ae60d4f44a270e238843751fd477ee065a35e3e6b8269ec6496ea113d87f840f",
      "3d7e90f84fe0b028830e49c6ed754103a10a81226c8865ae5349b96fcc23e60e",
      "0d84e41598fcb736cbe6b40c11c7c7ad42c284b344931cdfb64e8977964a2b07",
      "cd61ce1017db9b27ef5b2e12433ecd1d67c57ab3ccf2540493e026bc3dbc390e",
      "d43c3d999147be24a938a02b45e16e1c50fd8de07cbe5477cddb722fb3b60d06",
      "19e93075b002d241e163d5a4d17fe587eee98222dd8f7f376f108ab3fa8bc407",
      "d60d3cef75565c24ef9c71bf51e33b8c915d83cccaa6267473b1836508a35d02",
      "b0c98d9059617ba8ae3cb2a183428c417a0361cc2dabe81e59daf12e5dcb520d",
      "18b4c74a5d02c7bcd9fd947bfaf83a8d5e6ae30e3f49ff2e570efc6b1e815d00",
      "2c2b1c359b26fe12e6e27cfe583bcdff12b7c774e0b2b50364e04e9812118b08",
      "c3f7928c60cdb4fec21f97456c9d9e7fc384951ae7b6e32aa0894b62dcf21c09",
      "730af0c0e0e6066e64727a8b44d4c8881479e613d639c12117af9d0a95b88f04",
      "ce5116ebf09528f2226984be551f52b11da3a0108f94f64d8db3348bf5c12e04",
      "8f06f5547cfeb2abaf47505de9cf325f191fb680143a3d2ceb5aba28b289600d",
      "42012cdc37ef76f53e3697b02cf7615bb9e65f4abc8e493a392c519eda140b00",
      "ab627860422be78c8083346e19c2cf196f5a9feaa5c6258ad3545eb4b15dac04",
      "bdfd4216a3776c6a07c7b291a2b2d837af1c406cc6e59664770b7e2a1863bd0f",
      "67d924b20c59302fd6ebf2c06d453b58af6d967e7aa7407ce61c48f2177f6201",
      "92e5825cdd78b9bb4e8d636dd9f627ce9542a970a0a12ab89574a254e608250d",
      "4f0399fa5642194ff37ff20c81437c7e1e19d7c38880d40e0506aca3cb85020e",
      "2ea49f30719f705f8c0f3a8a85732302d91bccffddc15de37c7ef4fafafc5105",
      "86a04e7ea1d77bc9b63eeaa9162f10c9a28c3abb0dfa8da9c65b9a72a0d73a0d",
      "561a37bf83348ec7a6fe1cefb08609cc1e3dc5d4cd24907b9f14e806de86d30b",
      "e5212bd33b2b3c864da7aa1a1a30f0236fb85f5d119de9d2715d924ea7d07e05",
      "5bbe9a5d015395d579258466767a04fe31e07f76e8d344d6e9191574a481e402",
      "6aafe292afbd8e2d5568a4aab1cb822632bacd346de4a41be4c140bb9f9f3f03",
      "6b89eaa6b28c225158d38cc3fe14a1d0b07c3e5a25f0957537d0ccff35a76d01",
      "0093a1f7327dedda4149a89aa5ec64a7eee765c3433c59dcffb0c8b8825fae09",
      "3343229dd5acfc4fe009ab594db7699f9c09883b52aa9d3ad3c0818cf37be109",
      "a9b64dd25e7e2daff9cf7efa5159f5daf3dc54d1d8479401de4f30106a6f9200",
      "68dc28a9ff15dfa96dbba37c4e70e48b18be070124ff17f824565168fa106008",
      "bdf5b110bf279d1d0dcfd52b8a8b71e182a723a3b9e3125c06492748d7a05a0a",
      "b2806ac8cd5a40a10cf0f931d24a76c66c9a3a6a123ae1530b52345f7ae48703",
      "dc8e1d27eb6ac5c058ba75de4b830cd26da902386deb1b447b8682965c26f208",
      "d915bda59c88c900b59bf181d8405dd66f05c8379017222885b55e7aded51505",
      "433439268472c42d6ebf5d320e677ae16df82c8545fc17bd572836717cbd4a0d",
      "42bab1c034b556eb48e8e5eb1a3325a294ad01ffbe5b3f45969345a4dbe76406",
      "b667c2bbb4065457c3a6cba33d3a66a5c08cb7d0ae7ee6a22576dd1a4b533d0f",
      "d34fdf176020ce0ff62e679738836a1c3c23e3f39061d200bbfcfcc9e6f3d706",
      "8f19b03afe47dd3f43f8330f5d4a81af5516d7a792a057effcf73e17610ca601",
      "818c64b855051bc2be885cada88c31740fc0afbc7d9802b303d9bae16dab040a",
      "0febd27e515684bae27261aa04210517302fe00409464329a367d863af8aa403",
      "ff1c1d215611f0b4f644de72eadfa52dfedc690845be53064c9a3312fe273605",
      "51d0ae6f411e0e8b96cb503ed8e8bafac223053713a0f40f283bbac9e9293009",
      "7ac893e834122f5ce2047323b2afc9136918fb205836cbfef8b50176e07e310a",
      "039e231ad0d0a7cf72abc7d90b3d6f10a3ce095d07f59c2d7865cefd1d666109"
    ];
    int index = 0;

    QuickCrypto.setupRandom(
      (length) {
        if (index >= rands.length) {
          index = 0;
          assert(false, "should not be here!");
        }

        return BytesUtils.fromHexString(rands[index++]);
      },
    );
    final List<BigInt> inamounts = [];
    final CtKeyV sc = [], pc = [];
    // CtKey sctmp, pctmp;
    inamounts.add(BigInt.from(4000));
    Tuple<CtKey, CtKey> f = RCT.ctskpkGen(inamounts.last);
    sc.add(f.item1);
    pc.add(f.item2);
    inamounts.add(BigInt.from(10000));

    f = RCT.ctskpkGen(inamounts.last);
    sc.add(f.item1);
    pc.add(f.item2);
    final List<BigInt> amounts = [];
    final KeyV amountKeys = [];
    // add output 500
    amounts.add(BigInt.from(13500));
    amountKeys.add(RCT.hashToScalar_(RCT.zero()));
    final KeyV destinations = [];
    final RctKey sk = RCT.zero(), pk = RCT.zero();
    RCT.skpkGen(sk, pk);
    destinations.add(pk.clone());
    final RCTSignature<RCTBulletproof2, RctSigPrunableBulletproof2> sig =
        RCTGeneratorUtils.genRctSimple_(
            message: RCT.zero(),
            inSk: sc,
            inPk: pc,
            destinations: destinations,
            inamounts: inamounts,
            outamounts: amounts,
            amountKeys: amountKeys,
            txnFee: BigInt.from(500),
            mixin: 3,
            rangeProofType: RangeProofType.rangeProofBulletproof,
            bpVersion: RCTType.rctTypeBulletproof2);

    final verify = RCTGeneratorUtils.verRctSimple(sig);
    expect(verify, true);
    expect(sig.signature.message, RCT.zero(clone: false));
    expect(sig.signature.mixRing?.length, 2);
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].first.mask),
        "e5dc8444ea1af2b9a12280ed62c0fc629e187bc575ce5a35a6e5c35967597699");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].first.dest),
        "bfcc2450bd77fc7e035b2ce760d2f448d3a5dee74b2b5e57957c49670b9f08f8");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].last.mask),
        "3c00440f012868cefa2e3bb4d3d28c5db8fb19387e3171c77a0bb3f37d98d617");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].last.dest),
        "e387bd0613db02c7ba12641a4d44508842623d81b6e25eaac11557100c08c83d");

    ///
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].first.mask),
        "759df6332e1b1e6c6d9a20392315181d837016bcf60a54c3cd91f6e8cbd7c5f6");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].first.dest),
        "22934ce441d8dd1df27324a6435a0c5d9e862270a46c4de9553005b92dfcc79d");

    expect(BytesUtils.toHexString(sig.signature.mixRing![1].last.mask),
        "85f7801780232a88638f4f06b55fc6f56e235f0d43117795b9663e7a131be9fe");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].last.dest),
        "3c68d4efd68765247bb582d63a186544b273a080cf663ed325e5a5a2353deb9f");

    expect(sig.signature.outPk.length, 1);
    expect(BytesUtils.toHexString(sig.signature.outPk[0].mask),
        "d8697a3858fbb639c3ca692c4cc81c72c0f45d99fabe46f2ca34067147cc98b1");
    expect(BytesUtils.toHexString(sig.signature.outPk[0].dest),
        "3a3593b9c91c88bfe1f848e573308b8d715082ab06c23bb6f15091e7317fdebc");
    final ecdh = sig.signature.ecdhInfo.cast<EcdhInfoV2>();
    expect(ecdh.length, 1);
    expect(
        BytesUtils.toHexString(ecdh[0].amount),
        "7b986ebab7c67708000000000000000000000000000000000000000000000000"
            .substring(0, 16));

    expect(sig.rctSigPrunable!.pseudoOuts.length, 2);
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.pseudoOuts[0]),
        "6d166e74afa6575646f0f92bfbcb5400958fcc9666c4a053aaae1d3df8bb462a");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.pseudoOuts[1]),
        "41f03278cefe5ed1aea77ddc87f87ce1db6e7049a8b0bcedfdf933a37c2adc0d");

    expect(sig.rctSigPrunable!.mgs.length, 2);
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].cc),
        "76ed48455d205d4a6da9da6958f7f0c3da542af7a278e74ff45d3eceb57dbc0f");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].cc),
        "2df9080dc9c79057f0bc1302c543adad64b0858a16bcde0e55eb3fa0ce0b1401");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ii[0]),
        "20dc6fe36265905aa54e9b720f803c81ee5db939ed7fdb986dc27c863eb5b0c7");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ii[0]),
        "9e6a9f4a18754b83633a9cfc5b32f2e5bfc0bce4fa8c085b6a87a77cfd9ba22a");
    for (final i in sig.rctSigPrunable!.mgs) {
      expect(i.ss.length, 4);
    }
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ss[0][0]),
        "d915bda59c88c900b59bf181d8405dd66f05c8379017222885b55e7aded51505");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ss[0][1]),
        "433439268472c42d6ebf5d320e677ae16df82c8545fc17bd572836717cbd4a0d");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ss[1][0]),
        "06b63af41fce0bd3a481544f0cecb91f10e64849e08f2ba93da6c51dce10d602");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ss[1][1]),
        "dd443dce1dd4e4c55ed65764a3a5e1bc18bd85ef4243df8571f4b5585b814b0c");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ss[2][0]),
        "68dc28a9ff15dfa96dbba37c4e70e48b18be070124ff17f824565168fa106008");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ss[2][1]),
        "bdf5b110bf279d1d0dcfd52b8a8b71e182a723a3b9e3125c06492748d7a05a0a");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ss[3][0]),
        "b2806ac8cd5a40a10cf0f931d24a76c66c9a3a6a123ae1530b52345f7ae48703");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[0].ss[3][1]),
        "dc8e1d27eb6ac5c058ba75de4b830cd26da902386deb1b447b8682965c26f208");

    //
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ss[0][0]),
        "818c64b855051bc2be885cada88c31740fc0afbc7d9802b303d9bae16dab040a");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ss[0][1]),
        "0febd27e515684bae27261aa04210517302fe00409464329a367d863af8aa403");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ss[1][0]),
        "ff1c1d215611f0b4f644de72eadfa52dfedc690845be53064c9a3312fe273605");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ss[1][1]),
        "51d0ae6f411e0e8b96cb503ed8e8bafac223053713a0f40f283bbac9e9293009");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ss[2][0]),
        "148efd675f90e58e98496b2c9660bccbee8d0125bce5a237ebcaf806c2b4cf0a");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ss[2][1]),
        "75ab49ff77ef76140a39b0422b523a20711a8ba42cf291c35384c7808c97180e");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ss[3][0]),
        "d34fdf176020ce0ff62e679738836a1c3c23e3f39061d200bbfcfcc9e6f3d706");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.mgs[1].ss[3][1]),
        "8f19b03afe47dd3f43f8330f5d4a81af5516d7a792a057effcf73e17610ca601");

    //
    expect(sig.rctSigPrunable!.bulletproof.length, 1);

    final Bulletproof bulletProof = sig.rctSigPrunable!.bulletproof[0];
    expect(bulletProof.v.length, 1);
    expect(BytesUtils.toHexString(bulletProof.v[0]),
        "10f44612272545f0a17c3e00cb6659806743a9c6321befec72f0db7dd372d1f9");

    expect(BytesUtils.toHexString(bulletProof.a),
        "44df3a63fc64c94c57b17598c23e73d6042e35efe540e4e83ce70f999b683058");
    expect(BytesUtils.toHexString(bulletProof.s),
        "508e8ec6b4d28863ef339352438a6b1e384cf93605908484016788d745f72995");
    expect(BytesUtils.toHexString(bulletProof.t1),
        "66bb4dbbea1109e010995860de82da2566bf0b13e46b7cf5c017040dfed22141");
    expect(BytesUtils.toHexString(bulletProof.t2),
        "9bc885062803fbe0e6eb0a8972ec0a6b9fdd37f2bf48f3e2e678c0a87e84d258");
    expect(BytesUtils.toHexString(bulletProof.taux),
        "01439babbc9f37de55237600781164c8d5bf0eadaf6a61d8c1f9c9aa9d28df00");
    expect(BytesUtils.toHexString(bulletProof.mu),
        "8bbc11b630c12c6cd2394a5fe36fc63b155525a7f7203adc2b88c85e173cc10b");
    expect(bulletProof.l.length, 6);
    expect(BytesUtils.toHexString(bulletProof.l.first),
        "fc18207c78a0d22b7440d55018a34270bf0992536c752d13efa4ff8750242c32");
    expect(BytesUtils.toHexString(bulletProof.l.last),
        "455a01bf1dc41d89550d301a0c3ad2a1b8286810878c462184a5dd92faf972d9");
    expect(bulletProof.r.length, 6);
    expect(BytesUtils.toHexString(bulletProof.r.first),
        "f7e8afd91c19fa46960fc36552414a1a198ab11bc294be723c17ff6543b78f6e");
    expect(BytesUtils.toHexString(bulletProof.r.last),
        "b2e7f2685f84918800ed606d1e3c6c6be1e4526c09b4e6a7af30f866d2d72f08");

    expect(BytesUtils.toHexString(bulletProof.a_),
        "511c058280bbeb83bedbad98f74cf3e8b360fe8b5088f8136bad7007c321550f");
    expect(BytesUtils.toHexString(bulletProof.b),
        "b4194de8b0c2bdab669fc5d74d1f451027339d091514d7f1487e2f8cbe2d800e");
    expect(BytesUtils.toHexString(bulletProof.t),
        "c62028a9f077e4f8fdddd140e40c8d61cfaa4f12abfe91a9484719a34f005f0e");
  });
}
