// ignore_for_file: unused_element

import 'package:blockchain_utils/crypto/quick_crypto.dart';
import 'package:blockchain_utils/helper/helper.dart';
import 'package:blockchain_utils/utils/binary/utils.dart';
import 'package:blockchain_utils/utils/tuple/tuple.dart';
import 'package:monero_dart/src/crypto/models/ct_key.dart';
import 'package:monero_dart/src/crypto/ringct/bulletproofs_plus/bulletproofs_plus.dart';
import 'package:monero_dart/src/crypto/ringct/utils/generator.dart';
import 'package:monero_dart/src/crypto/ringct/utils/rct_crypto.dart';
import 'package:monero_dart/src/crypto/types/types.dart';
import 'package:monero_dart/src/models/transaction/signature/rct_prunable.dart';
import 'package:monero_dart/src/models/transaction/signature/signature.dart';
import 'package:test/test.dart';

void main() {
  BulletproofsPlusGenerator.init();
  _testOne();
}

void _testFour() {
  test("BulletproofsPlus RangeProofMultiOutputBulletproof", () {
    const rands = [
      "42bd8bd386af6f7e9714795c7affee103bff6121eb0b3c8a3539918e3a080f0b",
      "22c7eeb9c7146abb3032751b52ed4a26ae59b661938158bfacadb0125e371205",
      "450e4e28a358d983bbad8bfa8349fe550d216981dc69a49d437d0eb61359f70c",
      "2a3436db529a55f8e5e4852c31d6f96cfa4c796d5842fe963a738ee03142ad07",
      "8e18a3f873129cf0d00ec49a42862685039ef559dd0bb767b2ff4a4ec668ea0b",
      "c83fe786187560ec99e99f12bbaed1a5362e5fc5c98b07eada6ae75f6354cb02",
      "847376e8ad9748248ab40495ed2e5bc44c3e5bc87eeebdf949eb2b4458de420f",
      "ad83ef4eae9398b035910a48370ce2796f0e392106a9887262a74378369acd0b",
      "3af1d5a7e8596de27ed914cd7efc6ba87da8857825e79aec6c9dcb3ea97f3202",
      "0b56af30d076bf292b605e0909d12ce9b7f7935dfd3172ef084a49fd3dd6cd0a",
      "ebf3ccf5799309f5b0eaf2b9ea649ef87c9bfb24fe34c87ce3b6e5133d48e60c",
      "36c047bb9967ab6a41fc9405ded7b422f94518d1c01c9bd25748384909acbb08",
      "61ca8e46ef536e07cad4bb90dbf8345df1c697294410e507400988734b614406",
      "9ee3799e41933ae7a95b7da47a8d2608cba163ee7cbd91cd3ff2c141770e850c",
      "6e3640fb1026df7343db00e301df3b5b97d8ea953269d74a245e6a0642818907",
      "5ea950eb58df7d78970ad9290dcc42e1085cf991728e76b5e58fcd89d46f3109",
      "b3c459989fdf6ff0eb430f15d564169f2224027935234476b0dc20b9f044ec07",
      "dc96600b5a8e88885eecaeb38c32eea895dcdfceeb1120ae84d74f4b7ff8eb03",
      "3319990e5241b3cb13d7900b15273033f475a33b8bdc661b0e136279dcfd9c0d",
      "7b58f73098046927848116f6be4f123dd1adcbc529af009836a58487fd4c0b0c",
      "f7a84da3dd81b65ec33f941387487455a2d17a66b0bdb9c2d47611024eb8550d",
      "51339e86867bfb7865620c6ce9ad2a500c3ac2400a50431003be37189b92e108",
      "c56877919daca489821f8a3fafba99c117da9e48b343b463defdf8deabffba01",
      "4636b85c16f1faade2d7e0e12644f1cfa86c1043ca0e74062fcced03717b5a0e",
      "8569c120de6d4e995b470ab2d5b1f51908cbb2cb39693011b7505cba67117708",
      "4b308a58b60b214645940f1917b8d81c50fa93ae143490b4e5c1cb26f5a47206",
      "15412f620975f3dbb758a51517c76c66e93dee45aab0f6c174b4ae7ebef09606",
      "237497157cc61f5415f32542965815561092fffe4de2d507602ce44c9689960b",
      "6f003d50be89e0b99a9bdeefd3f93aa378842c0d38e491774905cd1f811d8c0f",
      "a9fe400c297c912cc61249e92b29640ba16266e159da1a7a2d5fd6b545eed003",
      "f46100f851d89720041a19a0d372a74d169ec7741e3342880b76e3241ac44202",
      "bf21edecc2e06692d3d0e5d45dabc375bb8a19b74a0e782505f2f13aa7b74a0f",
      "92317288011e4c1aa5f5e247fbb53cc1c7701e996b439a535f2a71accb825607",
      "54ee02a3c0326f38961efa507edb17eb26849ce31638a216e8c0d9e66f93420a",
      "7356392f229b31dc27ce6baf16eb701d414b1f112d48b10c84922f96d50bf602",
      "b6c18782eedcd7349d0a21b0c7b7207247cce2cf2bd17a2eaa9e4006066e590c",
      "e09d4a1e396e0d8840d13d3ca81c6e228c2034ffed7a9a90a23713a9b023330d",
      "003911af520f5f7688e76389ee31a7eb6d9255cac1eb3c6a15cca11429ebe001",
      "a74f3af0ac421c8c500a9b0b553bf7789a8e88bd4b45d1884aa1692c2d91be08",
      "9dbc3b0ca636fa58add8e58f7374ce060d569d67345c7075466c9a5f7f503d0a",
      "e3d20cd0d2bdd801f4a16fdbb5d54c37729b0269fd9a3d736733842a2a9b910c",
      "a68e4167d68a7a60e86a899186852ddc1f4af96c771332008e2665574c76b403",
      "7a2f656962bdf339da246961443614ef9cfcff8b4f32b4b5d5ce44612c775006",
      "ae94ab1c00861cc2ae79ffaa4f2c179681ca6db54fb268b9c3f8df9cb197490f",
      "9e63968d72bad9883c02a4044f4020f4af08b718e0d326dc0fa24dc5e5e77707",
      "353e08ca1f76ecc8d85ea2cffb32d6540e873d1cafd1b738d6933f0ce2913004",
      "caa2f91c55b8cf68acd903d734cbfc04775c32d9947bb8735ee29a8bee5fc70e",
      "14507c1276e91e17f64b4078845dbfa129b7cf7b1ca34c908fd8aa4f9c5f5e00",
      "9837965d4e7a5accc628315458e3cc46fbd6a34051b82e9746681acef6122804",
      "5e69ffbb046099ce4346a93e4c609e8f42a5e94cb49221e5aa70dc15536aaf02",
      "b01578028b63235bd17005f87791a9757e89b270924cc5d6c8ae5a2e32426601",
      "4b2fca97886e32d57c78b60c2f71a83ddcf604d2fd002d26da694ed536e46a00",
      "c708049845486e4f99f7b35f706f7ab5e7a2e4d89cbe48ece4f0784b7e430c0b",
      "ef47413e1e0e5e62fa8130df612eb4366162b79a84d18f26857afc7ad6bdcc03",
      "b7509e22c48751c36e1feab61404961f3372b9841973a84ab1fea72885d64c02",
      "08ddba5b1ba322f156eacc8dd94aa66dd931f7e2a882e15c4a02ab675b042001",
      "1ec052a8b0b94fea267e20a49ccf12934fdc9fbe5340c113b11af80113f5560a",
      "d435f58121cb71c4f46d10084b7417ab6684a15c3ce7deb7fc9256504336540b",
      "579ce5fcc86d7daeb06c4d1874617dc4dd27d7e887e91cd0a60246d8a1f5eb03",
      "b771508dfd57da6160035f4030b04621c9656a2c408951f1745c6520e8cfea07",
      "a7ce326978764135538bc209065559d439bab876159f374987f9cb7f7dd8f10b",
      "6db5e7ee8f066db592d49f6b065478814eb17122ea9acfd0f63e0fd79ff8b206",
      "b9190cb361d1e0f803acdad967bc23fa03893d3c1b095979de85bfa7fafc0d09",
      "386ba2d2870e6a8abeedbed97f2ba7f1e41f2a149698e93657453e37faf0240e",
      "8a5a893206df0911b186c2d9d7ade378e007f6550848bd50f18d9aebde5d980f",
      "236e6223fcad887b5ccd7ca293f212fd46e093c3ed5433caaf7a45ded4bc0905",
      "5c568440c3eca26c7275c6d238fbaa7a07ae8d6295e1720c70be2bd1c36a120a",
      "c5b6179bb5a3c27b2380cc3b46f78781b2372ea31c1b1a0d4f3cf6a4ff8b840e"
    ];
    int index = 0;

    QuickCrypto.setupRandom(
      (length) {
        if (index >= rands.length) {
          index = 0;
          // assert(false, "should not be here!");
        }

        return BytesUtils.fromHexString(rands[index++]);
      },
    );
    final List<BigInt> inamounts = [];
    final CtKeyV sc = [], pc = [];
    // CtKey sctmp, pctmp;
    inamounts.add(BigInt.from(6500));
    Tuple<CtKey, CtKey> f = RCT.ctskpkGen(inamounts.last);
    sc.add(f.item1);
    pc.add(f.item2);
    inamounts.add(BigInt.from(9000));

    f = RCT.ctskpkGen(inamounts.last);
    sc.add(f.item1);
    pc.add(f.item2);
    final List<BigInt> amounts = [];
    final KeyV amountKeys = [];
    // add output 500
    amounts.add(BigInt.from(500));
    amountKeys.add(RCT.hashToScalar_(RCT.zero()));
    final KeyV destinations = [];
    final RctKey sk = RCT.zero(), pk = RCT.zero();
    RCT.skpkGen(sk, pk);
    destinations.add(pk.clone());
    amounts.add(BigInt.from(13500));
    amountKeys.add(RCT.hashToScalar_(RCT.zero()));
    RCT.skpkGen(sk, pk);
    destinations.add(pk.clone());

    amounts.add(BigInt.from(1000));
    amountKeys.add(RCT.hashToScalar_(RCT.zero()));
    RCT.skpkGen(sk, pk);
    destinations.add(pk.clone());
    final RCTSignature<RCTBulletproofPlus, RctSigPrunableBulletproofPlus> sig =
        RCTGeneratorUtils.genRctSimple_(
            message: RCT.zero(),
            inSk: sc,
            inPk: pc,
            destinations: destinations,
            inamounts: inamounts,
            outamounts: amounts,
            amountKeys: amountKeys,
            txnFee: BigInt.from(500),
            mixin: 3,
            rangeProofType: RangeProofType.rangeProofMultiOutputBulletproof,
            bpVersion: RCTType.rctTypeBulletproofPlus);
    final verify = RCTGeneratorUtils.verRctSimple(sig);
    expect(verify, true);
    expect(sig.signature.message, RCT.zero(clone: false));
    expect(sig.signature.mixRing?.length, 2);
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].first.mask),
        "a6eb2716b42636395c18f8c863dd1352f7ef9396db23a7bf123652f08b49da6e");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].first.dest),
        "2cdf76ac4f9f6fa028a927bdb8c8c5b191e021cae583d8bda54c6e43d0419ad9");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].last.mask),
        "91cc564395e7efd8356948fe761257df407e3ce0fc1b22d495d91aec1d4760f4");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].last.dest),
        "96e1e3a8b70f82964953f1e85dd74d2fb04ffcb9b93986063ad79af6a5dfe8bc");

    // // // ///
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].first.mask),
        "60a2e5ba4b9354202d295f70ae120afed4d234c6ea46dd637f33ee99b997ec73");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].first.dest),
        "20224cfb11621be31577683e73bca79693b2a21562631a48f196c1c7001134af");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].last.mask),
        "6fa228ec5dc4318805c498242e52c38cbf14a48e020542ebe9057bf12dc7f36a");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].last.dest),
        "61e9f8dc851c5b3ea5e5f6bb2d511347ee5f4347153c4d93b322ac99f98247aa");
    expect(sig.signature.txnFee, BigInt.from(500));
    expect(sig.rctSigPrunable!.pseudoOuts.length, 2);
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.pseudoOuts[0]),
        "895792e8d12aa40f09d13ab689cfd7964d231fc0f762be018b5072b419727950");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.pseudoOuts[1]),
        "a7ed460d3fffd252c3b2eed868b854ea4289c775eef4bebc5ad9b3ba2ec453cf");
    // return;
    expect(sig.signature.outPk.length, 3);
    expect(BytesUtils.toHexString(sig.signature.outPk[0].mask),
        "21843920f19aaf8fef33717b3e190f13d5c10029ecb94d8ecd89cd8e1a3dec25");
    expect(BytesUtils.toHexString(sig.signature.outPk[0].dest),
        "a4c0b7460d32bcebe7f8da0b562606d1a812507d005c58ad96e47580b0365d88");
    expect(BytesUtils.toHexString(sig.signature.outPk[1].mask),
        "d8697a3858fbb639c3ca692c4cc81c72c0f45d99fabe46f2ca34067147cc98b1");
    expect(BytesUtils.toHexString(sig.signature.outPk[1].dest),
        "77bce4215afbde1544ad4074ef5f79670578d467aca91b2e875eb2d482a8703a");
    expect(BytesUtils.toHexString(sig.signature.outPk[2].mask),
        "1d43fc74457b9664f48e425ce69d991479b371bd30c89fad9da28644137333ec");
    expect(BytesUtils.toHexString(sig.signature.outPk[2].dest),
        "3dc7e6851f2e8ed93a60a84f88b81d41ef47fd591bb9aabefb35ac26e4bf2ffe");
    expect(sig.signature.ecdhInfo.length, 3);
    final ecdhInfos = sig.signature.ecdhInfo.cast<EcdhInfoV2>();

    expect(
        BytesUtils.toHexString(ecdhInfos[0].amount),
        "33ad6ebab7c67708000000000000000000000000000000000000000000000000"
            .substring(0, 16));
    expect(
        BytesUtils.toHexString(ecdhInfos[1].amount),
        "7b986ebab7c67708000000000000000000000000000000000000000000000000"
            .substring(0, 16));
    expect(
        BytesUtils.toHexString(ecdhInfos[2].amount),
        "2faf6ebab7c67708000000000000000000000000000000000000000000000000"
            .substring(0, 16));
    expect(sig.rctSigPrunable!.bulletproofPlus.length, 2);
    final bulletProof1 = sig.rctSigPrunable!.bulletproofPlus[0];
    expect(bulletProof1.v.length, 2);
    expect(BytesUtils.toHexString(bulletProof1.v[0]),
        "7de665bfc6c98a0b4d8d69121646fa6e70d009455d67c6d98995a3fe0c72c8df");
    expect(BytesUtils.toHexString(bulletProof1.v[1]),
        "10f44612272545f0a17c3e00cb6659806743a9c6321befec72f0db7dd372d1f9");

    expect(BytesUtils.toHexString(bulletProof1.a),
        "33e4f28959a8b910efb9c7cc06d51589b0387c00e2061a066972ddc0d2f52fbe");
    expect(BytesUtils.toHexString(bulletProof1.a1),
        "f048bdf76b7d63278af10bde727db76c8e62183075e369673c084d2e35de995f");
    expect(BytesUtils.toHexString(bulletProof1.b),
        "58ade73b1f5b0ab9996222290e3c5fad56e9e98f7c77888eaff9d26da61d5a22");
    expect(BytesUtils.toHexString(bulletProof1.r1),
        "92c3f460bb9b146f9e7cf1bbb2630fa0d67a81538fc65c7f77d0a71b09703009");
    expect(BytesUtils.toHexString(bulletProof1.s1),
        "d23b959945f076854c3adc7245b4bd0ea34e3121d60927a30f51183215d2380c");
    expect(BytesUtils.toHexString(bulletProof1.d1),
        "82db5d5d32e21dfeec8d8e206e054e96fa4e667a18ad187c22421fd3d3f79304");

    expect(bulletProof1.l.length, 7);
    expect(BytesUtils.toHexString(bulletProof1.l.first),
        "13e50745eb25b040de2af3ff8281b7977393897aedc05bbf1be572763b8e24db");
    expect(BytesUtils.toHexString(bulletProof1.l.last),
        "2aea0438deceda462f501dc47c73666eda9ee2c4f1814201efb800c2339e5608");
    expect(bulletProof1.r.length, 7);
    expect(BytesUtils.toHexString(bulletProof1.r.first),
        "29e9c740d5ffbe81a191b25f9a4b0e22433d19229cda537348b0d406961811ce");
    expect(BytesUtils.toHexString(bulletProof1.r.last),
        "69b4a2732256a807f4fee46f8e03ed0432c77a07e7fb2621fef1d6686f7bd081");

    final bulletProof2 = sig.rctSigPrunable!.bulletproofPlus[1];
    expect(bulletProof2.v.length, 1);

    expect(BytesUtils.toHexString(bulletProof2.v[0]),
        "87afd52d1cadb5bba5e8417f8f024700b16b124b3d725e83e881f4399e82ecb4");

    expect(BytesUtils.toHexString(bulletProof2.a),
        "c25805e830962409517ec32cdc5ba3a2de226b7f7f2d58902e88d95d11d92874");
    expect(BytesUtils.toHexString(bulletProof2.a1),
        "aab2167b6ec0aecb5fce17d46b841cfd4922527314c17c6ae6fa7bf81511abf7");
    expect(BytesUtils.toHexString(bulletProof2.b),
        "0ac69c94dbedff862c3faa87c70b3dee70f027d1bbec7c7f0fa6500d7f8f7119");
    expect(BytesUtils.toHexString(bulletProof2.r1),
        "438c22674fb32271338037670f2ae6931d88e8d23f864bffee01a77c1ae49d04");
    expect(BytesUtils.toHexString(bulletProof2.s1),
        "2aa1408400ec3d042cba7b9e1a4a86e104fade1f1b34272b1b72442e0fee7a00");
    expect(BytesUtils.toHexString(bulletProof2.d1),
        "0fb9c0a3bc33afd5180859dd6b2dc7a926727f4c23e62b78b88902acbd7a6c0b");

    expect(bulletProof2.l.length, 6);
    expect(BytesUtils.toHexString(bulletProof2.l.first),
        "887afcfcbbce061e0bb231d129b917d8fff37bace862c3af4975e4f6170a99e6");
    expect(BytesUtils.toHexString(bulletProof2.l.last),
        "b53a77b63ffaa6afee0d39a88b29b4a80b320219cd2022bcaa4257ba78d1197a");
    expect(bulletProof2.r.length, 6);
    expect(BytesUtils.toHexString(bulletProof2.r.first),
        "9487456cc9c08754d023d9701aa2f07724f5a0b04f5e448c1a41a11caf0976b2");
    expect(BytesUtils.toHexString(bulletProof2.r.last),
        "8cf2fc7e79540eba18b6e1ae34dfa58c4254a98e308bfbb673ab97eb596bc5b6");
  });
}

void _testTh() {
  test("range proof padded bulletproof plus RangeProofPaddedBulletproof", () {
    const rands = [
      "f5b5fe0eec3f68fc8b7db94fc673d1b2eb5f6aafb8d70b10f4c9dde99366f20a",
      "85eab017da6d3045845ba7229c0dd71000e277a1ec1f37cbd8fa0f4898386d02",
      "966df994d4d80614a397944fea1d944629f821749ac58cf657b4f69bf058a306",
      "363ff7146d65ca3a3ce20130ed4969ca44aa7275d3e24443050f46abf086b102",
      "ac550e70fdf4a2e5588fac987529aafac90a39cf66ba0710f21256fb35f98006",
      "683c43adc59ccae70816b9cd36b6bb0cdbfc0dcec5f59b12406e98b35f333c04",
      "21ff4e2d24eed6eeee833d28632ba54d648800ff3c61606ae5fca2795109500e",
      "41e3534253828823bec13a59185ad616e28319c9f16d85acc52360e00d4f5d08",
      "a0d9507a5ac34d5f09e6ace14a49270d81e94ded0984ac8a3658c5b875210e09",
      "76593129c8c97e6a80fe0fccaba374554e7fbae6fac47de5cfe6766d8b43e808",
      "eb65737a45eb15033c0ba133138fc1893fd808db1948b2c7266788b299dc1d0d",
      "41e60bc485adb08085ace8aeacf679fa6d3b34a201b62b270992004b5d3e9000",
      "1a4c48b0be53c92d0d2166b595b84c3313ee26672b38b000d1755ff32b520604",
      "96dcf07ed490af15135cce82d720d416c5e1d85d49ba706b34de55d66592480c",
      "87eed8de246bc0d8895f1efcedb788f9c8a58e7183ae60a182780705e9ca7c05",
      "a966f6ba931551c47ad1071204c30998094d9f28649d0365f12d7cd215bebd02",
      "a7710981e73e830e4f37ea9a68d5f95a3216ba872cf7c8bcea4f493ba47bc201",
      "f2496d301f442738c8ea76ebb164401c241c26a8ce85bad5e462fe721389a202",
      "4c0c203994dd836c9617cfd1f0cc539cbd1188a62de65d426bc34a6a2eb9910b",
      "ec75dcec71d9a72e674995d7f4e9fe47943b935ab34960bb4f2aeec8b6e36a08",
      "fdec9428d042d65d974d7715c387ce8a8afee2daa3dd6a01ab3c753ded93210a",
      "a772a12c1c275ca2c3c41df9e2ec52f86f04f49cfb558a55cfd5fe2bc30de201",
      "25d7c24a30e5abbac23a2d3a3a9d8b8f92a441742ed0c522e976ce8ee262d206",
      "2f72bbacd353a9d27747886b408ade9c2f2bfe8357cf9989d95b0a7f8b2f0d0e",
      "1a23b4fde9b1dd6d1105dc0eeeae34e0c7ccf1afb3d9a7294aef0935ab840309",
      "9bf01b28149223f8e4f00a947a2f66cfa77d9167682c0067be06938a70751b02",
      "98b5d314bd45dd0d0f0c8e1750c7996baab7a2faea2828c3a24deff9ddff2e04",
      "a1eda28b7cf1db683835416ba5a186ba1640290811111c436a0dc0ec6c375801",
      "a16b85ea56a8718c573c17c707ba6154e188150a48cdac21a5dd968f98ca090c",
      "05b2b5ddf5d494f213a9406f8a9fb3facb4398997e9987380e07b5614083d705",
      "2481b2b935d1616165274e0e1a28f74760a540f2ef848891f61b2c16ca7f5705",
      "402fe5f0890d5448456fec43dfc945923579b25e6a74c8120af9da25f94a260c",
      "be835549767225c635a979075b9e872372e644eeaf3f28afb22c27e3e85eb900",
      "c7c87f504aeeb117ed717ba6353023ce91c02836dcf4778629a3cb46de4ef607",
      "54d4555bf75fbb6f62ba9c9b7e701b453e629c163b2a7a160a3e54e4a0722a0f",
      "454fc8af23c014638d85d5e41c51b4e519b1f23f693bf2e5a7a410346e444503",
      "bd82d253bcd29c2f753acd7b2e0299cdc4353a0ff0168f63b1a03ec5093c2408",
      "55448e41ce7339ec17d485655050d8245432ae91faec0a6e64574467aebab00a",
      "f8cc4f06fdad89787c1032512e666e8e306fc1f6403b9e5bb80340aed3c64203",
      "52edce422095c44493f69d8791a0764c29ddac8608f06416482e33d77fa6380c",
      "5a0d444c514b458b770b70aa97f0d3cb70b41ed82850d0399a40cbf3f5adde0a",
      "3423652704b54d71212c73b4bd0d257e3d93e420e97de039d49a6bcf1e5f8f0d",
      "e7c1a1ea80d000b311355da65ddf4f1e9e6e1fad67bd95d4db0e92eb4c64ee08",
      "3e2b95460f0799b6b1a0e9b3b1c45022b0a409fecb04761c4ab62402eae7f505",
      "785fa0e042aa7194bea73019c0b1e94b5a621cf728cfe72c745cbe39697e2607",
      "a474a265af7e95fefe70c58bff9dfba33070756c49f7707ae6abff010a64f30e",
      "0e4e2583b3b8f1eccd77d8eae34974aabd80092ce765c893b71b9a971bece606",
      "1ca4ff385853cba08c60753c8e3169f1ffff064a7ff430a61d9f9c3b95be3102",
      "2e009b6be60bf5e24c3399a0d3f108bd8a38cbf6bfaac13b6c2b0000f807fd01",
      "f390686a2bd28fe4bbb2a5ed2c56e949735ed70aabc32de559ddb91d0939050d",
      "4c67a275c56ac225c2a5045bdcf8075976f0eed2b98dfd786d076b1ebffa7303",
      "b30216b6926c98b60893e26957f5c225c296240474ef87d808704a648728e406"
    ];
    int index = 0;

    QuickCrypto.setupRandom(
      (length) {
        if (index >= rands.length) {
          index = 0;
          // assert(false, "should not be here!");
        }

        return BytesUtils.fromHexString(rands[index++]);
      },
    );
    final List<BigInt> inamounts = [];
    final CtKeyV sc = [], pc = [];
    // CtKey sctmp, pctmp;
    inamounts.add(BigInt.from(6500));
    Tuple<CtKey, CtKey> f = RCT.ctskpkGen(inamounts.last);
    sc.add(f.item1);
    pc.add(f.item2);
    inamounts.add(BigInt.from(9000));

    f = RCT.ctskpkGen(inamounts.last);
    sc.add(f.item1);
    pc.add(f.item2);
    final List<BigInt> amounts = [];
    final KeyV amountKeys = [];
    // add output 500
    amounts.add(BigInt.from(500));
    amountKeys.add(RCT.hashToScalar_(RCT.zero()));
    final KeyV destinations = [];
    final RctKey sk = RCT.zero(), pk = RCT.zero();
    RCT.skpkGen(sk, pk);
    destinations.add(pk.clone());
    amounts.add(BigInt.from(13500));
    amountKeys.add(RCT.hashToScalar_(RCT.zero()));
    RCT.skpkGen(sk, pk);
    destinations.add(pk.clone());

    amounts.add(BigInt.from(1000));
    amountKeys.add(RCT.hashToScalar_(RCT.zero()));
    RCT.skpkGen(sk, pk);
    destinations.add(pk.clone());
    final RCTSignature<RCTBulletproofPlus, RctSigPrunableBulletproofPlus> sig =
        RCTGeneratorUtils.genRctSimple_(
            message: RCT.zero(),
            inSk: sc,
            inPk: pc,
            destinations: destinations,
            inamounts: inamounts,
            outamounts: amounts,
            amountKeys: amountKeys,
            txnFee: BigInt.from(500),
            mixin: 3,
            rangeProofType: RangeProofType.rangeProofPaddedBulletproof,
            bpVersion: RCTType.rctTypeBulletproofPlus);

    final verify = RCTGeneratorUtils.verRctSimple(sig);
    expect(verify, true);
    expect(sig.signature.message, RCT.zero(clone: false));
    expect(sig.signature.mixRing?.length, 2);
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].first.mask),
        "106d6e7c85fefce476f59339556af1b2a883859d8046c5b90f13c3dc69b5a2c6");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].first.dest),
        "64622bdc0317b22dd5481e4c892ce0a7a39cfec6132432af3f8c64f260c0457c");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].last.mask),
        "fed5b893e7d16ef2140e14d09b056e06249129702cd11b76477c11c011edbc0e");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].last.dest),
        "3e7aadc2bd8d1d765654b8fbe383ccfca13c0fa2bd86d8ec7512f0482718c359");

    // // // ///
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].first.mask),
        "0fdbe32f6d2f95c5c5a8e61e644c9fd85e63c14f6d14d4e4ef09e9a58767ced6");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].first.dest),
        "78f61fd432f99e22b10a3b953c8e4886abcd6bdaf1d6fc410d76d51a02d908f1");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].last.mask),
        "cc7f240b7ba215f1a6b517f70c6084db9d81a317f8ce7eb7a2666880b2c3813c");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].last.dest),
        "4b5418d0e194d350d3704a3e1286af65bec50b849e0212267562bdaf6589cf56");
    expect(sig.signature.txnFee, BigInt.from(500));
    expect(sig.rctSigPrunable!.pseudoOuts.length, 2);
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.pseudoOuts[0]),
        "45710544f43e36ead0a5106af4a1e40e345935315d33358ed57f729502ccecbb");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.pseudoOuts[1]),
        "a8748b4bd8c5a52f209901d4d15f45a1d3ec99653edea2cc0e5efbe909a1265f");
    expect(sig.signature.outPk.length, 3);
    expect(BytesUtils.toHexString(sig.signature.outPk[0].mask),
        "21843920f19aaf8fef33717b3e190f13d5c10029ecb94d8ecd89cd8e1a3dec25");
    expect(BytesUtils.toHexString(sig.signature.outPk[0].dest),
        "60f0ad6ed79edbfbcb1aafe6a3ac582562aee7ec18a1685bde7082e578de6e28");
    expect(BytesUtils.toHexString(sig.signature.outPk[1].mask),
        "d8697a3858fbb639c3ca692c4cc81c72c0f45d99fabe46f2ca34067147cc98b1");
    expect(BytesUtils.toHexString(sig.signature.outPk[1].dest),
        "7633d9380ad8d1a8cec3e96c6776c35a299fe7785b3356913413499070d1b8ef");
    expect(BytesUtils.toHexString(sig.signature.outPk[2].mask),
        "1d43fc74457b9664f48e425ce69d991479b371bd30c89fad9da28644137333ec");
    expect(BytesUtils.toHexString(sig.signature.outPk[2].dest),
        "eaa3effc82f63f6c5b233cbca2f1f6ffa1fe937573829d66bda843b728fefec4");
    expect(sig.signature.ecdhInfo.length, 3);
    final ecdhInfos = sig.signature.ecdhInfo.cast<EcdhInfoV2>();

    expect(
        BytesUtils.toHexString(ecdhInfos[0].amount),
        "33ad6ebab7c67708000000000000000000000000000000000000000000000000"
            .substring(0, 16));
    expect(
        BytesUtils.toHexString(ecdhInfos[1].amount),
        "7b986ebab7c67708000000000000000000000000000000000000000000000000"
            .substring(0, 16));
    expect(
        BytesUtils.toHexString(ecdhInfos[2].amount),
        "2faf6ebab7c67708000000000000000000000000000000000000000000000000"
            .substring(0, 16));
    expect(sig.rctSigPrunable!.bulletproofPlus.length, 1);
    expect(sig.rctSigPrunable!.bulletproofPlus[0].v.length, 3);
    final bulletProof = sig.rctSigPrunable!.bulletproofPlus[0];
    expect(BytesUtils.toHexString(bulletProof.v[0]),
        "7de665bfc6c98a0b4d8d69121646fa6e70d009455d67c6d98995a3fe0c72c8df");
    expect(BytesUtils.toHexString(bulletProof.v[1]),
        "10f44612272545f0a17c3e00cb6659806743a9c6321befec72f0db7dd372d1f9");
    expect(BytesUtils.toHexString(bulletProof.v[2]),
        "87afd52d1cadb5bba5e8417f8f024700b16b124b3d725e83e881f4399e82ecb4");

    expect(BytesUtils.toHexString(bulletProof.a),
        "a09a9693fd3f9e94bcf78e082c6126d44da8ae892cb31dd3a79c71be7f1bb845");
    expect(BytesUtils.toHexString(bulletProof.a1),
        "defae0381982a980821838ead36d84500f225001912ad594be5104d67c0743e0");
    expect(BytesUtils.toHexString(bulletProof.b),
        "95720e96af6ee051b65a51de0630845a4b281dd186f93e92bd8a3d7ab400a616");
    expect(BytesUtils.toHexString(bulletProof.r1),
        "3afd885d0df9464ab42e199b451a0ab9f891b02b975c960089f50b9d0828a200");
    expect(BytesUtils.toHexString(bulletProof.s1),
        "a707d865411ff0455ae5d6fcbbdb7f5c55fa55f1c38a56773dbfbdba26251f0f");
    expect(BytesUtils.toHexString(bulletProof.d1),
        "150f347ac4c4efd9e4dbca255774a2ff79edf8b2e7537280e67f239350310509");

    expect(bulletProof.l.length, 8);
    expect(BytesUtils.toHexString(bulletProof.l.first),
        "4e48b5798082ccaafb5d1506d846a6dc909e6eab94811b59b3d31415f2703c35");
    expect(BytesUtils.toHexString(bulletProof.l.last),
        "b50def7c3b8018170cafa41832012464a1b7baa1545f329807e0ea9496f0f085");

    expect(bulletProof.r.length, 8);
    expect(BytesUtils.toHexString(bulletProof.r.first),
        "bf68b211af472ce847ae5ca605b9355b3110e851a99786d5713e82123f735cee");
    expect(BytesUtils.toHexString(bulletProof.r.last),
        "479704b117b6b3e2cec361faf75b896f9215d711d0584ce09dd3c36e9dd5e772");
  });
}

void _testTwo() {
  test("range proof padded bulletproof", () {
    const rands = [
      "39cc226af47412adc2c4e90c6602d03b7ecc9b40f90ed0a721bb91ccde289d0f",
      "f741abc99f88a745102205fedb6f74c1ee64d86a22a76eb0bf296b109b26e20b",
      "c41712d7d01e5f2817e38f1b3472da4bba4f2e342800d8f3d277f12ad996a30c",
      "bdf6171a1cb53971c8bf2a8ab5870032e388a9edd6caf19160f0b9c821c4b900",
      "221c136827a3ea2ba13f206248d1384912afaa6922195d002d28c3c13993a509",
      "c3f3c101944e854199d610999b3114617babf42cbb5b105390f86d891a76cf01",
      "86a05639da599882f8ca83a478ec480b635d28ad0581efc16de95f76c6763203",
      "2f53939457130fda57adbe63cf1ef42c19e93a3823a6c7f598685ef1253dd301",
      "16380b89d2da44ffbf3f96f3ecae0530d98b5ceac24fcb786be6feb96ed67f0b",
      "3b373ae827679f4f3cdc553539bc0a96900d91f6ecb989fe70775e0870905903",
      "dcfa4dcbc0740b0eae91fcaf646b4bc0a6a3b87fb1d882ce178eeb06901df908",
      "4cfe20e0d0e399a0057dc64d622e359ed9e4eba372573cb70cc5d93608d9c507",
      "c0f1b9acae9f346471a394a2f67b921ec0b329d6a50302df077b42b177e4c702",
      "28a66bfcc42baf075c3e86618b3734d90bfb6a63ed16fc694989edf477c6ce0b",
      "3264f38d82db548582ae8192d06474e9c0b8b273a71d13b1dc6d2c7327287d01",
      "974c7b1ac09acfcfe02e7536f546f4baa4f5e8ce80c51f200573d02c8698c103",
      "a5570d9e842ab2225734de2bc3860891752d90199cff7f8122c5e0adc6fdb00d",
      "be9aede30b9c49df74dd88f29aa60d935a62885aecb5887d8b0af47ca8b41806",
      "df64a7c789a0c4257c94dce59f08f7e5cfcd7ff038721e0a4bdd160d16905507",
      "2838f110edf7a3160ffff0dff0c3299fe3438390b71366bbfc1d6e2a015ff501",
      "9090cfbd8800d6f3fbc2aac1447471940f5443c0af2e7b51bf93c1ddd56c210b",
      "432ccf257c1070710b2efc76546964ce482f65856a883d7a87e414a593cef80e",
      "eb348f0e051e2adf061bc7ed28324b16a325537b60f1b9d2b79233121eb0ec05",
      "7e8afef275031d5a2af7fc1a09a9ec9259f2c2a94f5e1bcebb4d48a2cd796d00",
      "f8886892ec0a7f3821dbfd40561665773431418aadf8002a96f10e605fc85907",
      "fc1a1b307a9a3d4ac1551d08de2607677faea8cf7ebe6f75227ae65b81ab530f",
      "79aacbd2189606de28d6e4ee02700b113e1202f441f2266d6bb1b178e8f2800a",
      "2973a5b44fa9d9dbfd0b51114db2c20209defd3fb73aacaeaba360ef74dc900f",
      "9916bcd3ed0788ca9d5c2293ae08f5757372752a75a219968c9094b448f3ba00",
      "eed25df33f38a6a96f0d92e865ccab39395ef8a5135293adb94b0edae4ddab07",
      "4bcd3085fc5294c3560e819caf37cac2456e011cad6a0c9872e34ae268a1000e",
      "1682ef5f3a9de1286dc7b2efd6832f062deafe2801f58680b9b6d6ccd91b8602",
      "b3fdfc5883ec8e79dab43eaad99aed8fd1fbfef40d33e633194226090bad3d09",
      "6b0dd07be16308bbb20732cf37553f0d7c63d02fe9a2d8e8d004d469eabe3407",
      "16ac6b594b1a276b756ecab7df5126e9108d04b5f77fec90565ba23482c72d0d",
      "169632d916bbbcc247b15dd3c057e365c98c120eac11fcd97e0b37e02f6da607",
      "5cca49856cc049b3e894fe1e2981d51fa20bc6d60dc11a889cc8723cf895c70a",
      "89f4fb5c4d29a5deccfef89bc66f7d092fd2c3f59bafde60947d472fc3ab9009",
      "7496e1b36d7437003e7681efe611c789d44deb85ec38d3daf6ccb7bd29192108",
      "20b061dc0395b856c85b3af960c67fe42e5579ee4f60c4f93822ebf406098a00",
      "302336a4123e61abd65c01aca6e8d2ebcf1730a6eda5d4d7480f173b8b366c08",
      "090dddbc861a2b2316cd1d9cddd9feb6112835d30155736246e2df8af0c83c02",
      "7569b31c5a1f83a78b9de11345178380db4e7d622e950293f62833ec201ca602",
      "eaf6e15896e916bc8199cefb5a31386ac3ccdadfb4c38d67a7aa43d767178707",
      "37889c93be2228708bb0206e1618a7fb26c5d979231cae0ebab67d2a222b4c0d",
      "8edc17c4b9b905b01fe1925e0c44afda873dcfbb02b9cf54c8dac2bf51ebf509",
      "5b5d420f82910037a400535ee4d954ca52c1240eed7484de616374afddc91902",
      "c84bcaaae989dd0036f1d3804e8b5e9b846b8e586bfc3830d57491520444bf0a",
      "73e5ee8e07c67f1b737b037c0ac32bcc3588b06a10ad7f134ab2965874b32706",
      "1c0b74d015fa62eb842be560a3d8f907866e2b685fa9dec2c07cce0415726408",
      "28c9c7e36a6e515e4fdc3b1494eece49a9667cea8f5dd22dd833b1eee36faa03"
    ];
    int index = 0;

    QuickCrypto.setupRandom(
      (length) {
        if (index >= rands.length) {
          index = 0;
          assert(false, "should not be here!");
        }

        return BytesUtils.fromHexString(rands[index++]);
      },
    );
    final List<BigInt> inamounts = [];
    final CtKeyV sc = [], pc = [];
    // CtKey sctmp, pctmp;
    inamounts.add(BigInt.from(6000));
    Tuple<CtKey, CtKey> f = RCT.ctskpkGen(inamounts.last);
    sc.add(f.item1);
    pc.add(f.item2);
    inamounts.add(BigInt.from(8000));

    f = RCT.ctskpkGen(inamounts.last);
    sc.add(f.item1);
    pc.add(f.item2);
    final List<BigInt> amounts = [];
    final KeyV amountKeys = [];
    // add output 500
    amounts.add(BigInt.from(500));
    amountKeys.add(RCT.hashToScalar_(RCT.zero()));
    final KeyV destinations = [];
    final RctKey sk = RCT.zero(), pk = RCT.zero();
    RCT.skpkGen(sk, pk);
    destinations.add(pk.clone());
    amounts.add(BigInt.from(12500));
    amountKeys.add(RCT.hashToScalar_(RCT.zero()));
    RCT.skpkGen(sk, pk);
    destinations.add(pk.clone());

    ///
    amounts.add(BigInt.from(1000));
    amountKeys.add(RCT.hashToScalar_(RCT.zero()));
    RCT.skpkGen(sk, pk);
    destinations.add(pk.clone());
    final RCTSignature<RCTBulletproofPlus, RctSigPrunableBulletproofPlus> sig =
        RCTGeneratorUtils.genRctSimple_(
            message: RCT.zero(),
            inSk: sc,
            inPk: pc,
            destinations: destinations,
            inamounts: inamounts,
            outamounts: amounts,
            amountKeys: amountKeys,
            txnFee: BigInt.from(500),
            mixin: 3,
            rangeProofType: RangeProofType.rangeProofPaddedBulletproof,
            bpVersion: RCTType.rctTypeBulletproofPlus);

    final verify = RCTGeneratorUtils.verRctSimple(sig);
    expect(verify, false);
    expect(sig.signature.message, RCT.zero(clone: false));
    expect(sig.signature.mixRing?.length, 2);
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].first.mask),
        "72f4a110fcb45c3bfcb3f0411d1cfc4543e38aa3c665d9275a6ffdfb8cf55b9b");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].first.dest),
        "12d8bb509e8dc7442326d689f9c5afd5dc25412173eb683bf3004c2bfe171c0a");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].last.mask),
        "744db2e45a414030ab6d78c74775cae4f61bf4e0ffbb775c02bf48df705a7848");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].last.dest),
        "92217754975c4168ce6250122bd7be74d08f0344b7e2c3701b21851989ec0395");

    // // ///
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].first.mask),
        "fe71981b99b1cfcf55c919199179ca19a5755d449fd73c7ace4282b69a004ed4");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].first.dest),
        "b2b0d78d6f0b7cc7c99a6240d47898e6a3294bbc0f1bf4bcc0fce24fd7faea36");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].last.mask),
        "c12ecde2af4f91eb2081873f60331b71d5f8d0ed118bd097c9e2d21092851bad");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].last.dest),
        "20d483866b1b467c6090ea466d16ba7c6c7164ef106ecfa3940158fbe2ada2d4");
    expect(sig.signature.txnFee, BigInt.from(500));
    expect(sig.rctSigPrunable!.pseudoOuts.length, 2);
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.pseudoOuts[0]),
        "3cb80bebcb6faf5d048dd297cbd1877de16bda6c863ebcadb1a904047448ad79");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.pseudoOuts[1]),
        "9a8fa542a16c7d3ae00a03a451180960f7c32fa8b52bf1e501748fcc7f031ba5");
    expect(sig.signature.outPk.length, 3);
    expect(BytesUtils.toHexString(sig.signature.outPk[0].mask),
        "21843920f19aaf8fef33717b3e190f13d5c10029ecb94d8ecd89cd8e1a3dec25");
    expect(BytesUtils.toHexString(sig.signature.outPk[0].dest),
        "568bc5d958e1b2f3d85ed4db62716c9386a5b48d8d5a5197ebde4308db7843ef");
    expect(BytesUtils.toHexString(sig.signature.outPk[1].mask),
        "28504fe8e30934fa2c401bf84ffc80b1f9738fdf833043e40d8c1a9dce45eedb");
    expect(BytesUtils.toHexString(sig.signature.outPk[1].dest),
        "98ff2eac3f11046cfc965f3365d0d978bcc4eead364b96bd59c0b2eb55716847");
    expect(BytesUtils.toHexString(sig.signature.outPk[2].mask),
        "1d43fc74457b9664f48e425ce69d991479b371bd30c89fad9da28644137333ec");
    expect(BytesUtils.toHexString(sig.signature.outPk[2].dest),
        "20e281bd9969f1674f383505633b3d934808d71a35fa733eba11a697ab84f4f9");
    expect(sig.signature.ecdhInfo.length, 3);
    final ecdhInfos = sig.signature.ecdhInfo.cast<EcdhInfoV2>();

    expect(
        BytesUtils.toHexString(ecdhInfos[0].amount),
        "33ad6ebab7c67708000000000000000000000000000000000000000000000000"
            .substring(0, 16));
    expect(
        BytesUtils.toHexString(ecdhInfos[1].amount),
        "139c6ebab7c67708000000000000000000000000000000000000000000000000"
            .substring(0, 16));
    expect(
        BytesUtils.toHexString(ecdhInfos[2].amount),
        "2faf6ebab7c67708000000000000000000000000000000000000000000000000"
            .substring(0, 16));
    expect(sig.rctSigPrunable!.bulletproofPlus.length, 1);
    expect(sig.rctSigPrunable!.bulletproofPlus[0].v.length, 3);
    final bulletProof = sig.rctSigPrunable!.bulletproofPlus[0];
    expect(BytesUtils.toHexString(bulletProof.v[0]),
        "7de665bfc6c98a0b4d8d69121646fa6e70d009455d67c6d98995a3fe0c72c8df");
    expect(BytesUtils.toHexString(bulletProof.v[1]),
        "f69799725178d91b2ece233b7ccf19d8f558c5970ec39427a1022098ae6e5ef5");
    expect(BytesUtils.toHexString(bulletProof.v[2]),
        "87afd52d1cadb5bba5e8417f8f024700b16b124b3d725e83e881f4399e82ecb4");

    expect(BytesUtils.toHexString(bulletProof.a),
        "9c7a477dfa758ac0c42de5afc6fae3e2a71e5bd098f05409a3f8bebf45a62e2c");
    expect(BytesUtils.toHexString(bulletProof.a1),
        "3b5a0302f8e1a15ff0f97de42466b1de59e0823bdf2909d09673b7f9fb594599");
    expect(BytesUtils.toHexString(bulletProof.b),
        "b54c03fbc95b38770c5550db2d35b88c27189fd346be7d33ebe39c293657786a");
    expect(BytesUtils.toHexString(bulletProof.r1),
        "d7f73374e70880494b3454161ebcf00b07af3cbb6b37f603ca5a4e21ed56b30f");
    expect(BytesUtils.toHexString(bulletProof.s1),
        "83a809e4b8aec34d264fc5cd1dc192569de3394980d98cac2dff8b7be669f70d");
    expect(BytesUtils.toHexString(bulletProof.d1),
        "003d3688dd86f3e8ce3fbf939af09b7209ab971a811565f8eeca556d50967601");

    expect(bulletProof.l.length, 8);
    expect(BytesUtils.toHexString(bulletProof.l.first),
        "944432498e7de94e3c9ab9d425fac26467e61cf3be0534fe5fd811227c85b608");
    expect(BytesUtils.toHexString(bulletProof.l.last),
        "2a74bb49d27425ddcccb996082277a18fa30f4fd532e240b7265757df4eef95e");

    expect(bulletProof.r.length, 8);
    expect(BytesUtils.toHexString(bulletProof.r.first),
        "b9cf2c3d829d1ea575f2ee6b379276ae8c3359af2d25d81c6ae1c410bd3a803a");
    expect(BytesUtils.toHexString(bulletProof.r.last),
        "600c05603931ee1c92f75fe2f76ac1b797eac78c6da742717349332caade24ab");
  });
}

void _testOne() {
  test("range proof padded bulletproof", () {
    const rands = [
      "6d11a86d45f515d1083986429301e40b42210acb7790857f15e7affef1cfdc0d",
      "3fd38246f2d90fe582db8094a4f837fcefb78ddbde1bae8b303123718d049b06",
      "b49a57619c362fa10ea5ce899d7b84f88a2024f19bfd487f43b636f6eed22004",
      "b8729f6b0d827face9221d023e02d69c8be17dd81d203fd4f62f18de1f43cb00",
      "1cd6e683c2f9c55a29ff8dfebfa9a0f42e625acf2777bdb3938175e54ad68b06",
      "baf93f66c9446d0a580fb062d6bcdda648c9a50961d690fb43abe2825adb9304",
      "1bec0d5ee729307cc360370679588778827081c89b73f85893b17dfcecc64a06",
      "bbb387e03a3145f70db63a030aae0aca2a10964d5dea5c82b6c8bfc275bf790d",
      "37cf36aeecb601b2459653e98e953da644aedd718a26bcdb0f6580d437961505",
      "bc26183ea9a85e27a92338b9bd1ef24fb7afd89ac7b3acf214e7219365350d09",
      "f69f9722631996a8f5e9a12fed9e8fcc610f75fd44a24e7c3e9b03252b3dd30e",
      "6c651e49cacdbf05487beae5007e2d2e04a18dc4126698dc637b8563056fab0a",
      "11a15bcc2f96534c403f74393a64a02c48264b48e8d25eba30bdeea0e5d8580a",
      "b7ee019dbde3f1393b26f4e7abee147884120abf5576abfc124deb36f1158b0c",
      "b85473c085df757877fa8509d0868b243800008c9f7a01b5824b296f72f2fd05",
      "8c1b22dcdf05169f6d85db07c4af8e4661abe52185c62b653033a8c8c4e11504",
      "442e77d315b38402acc6527c92b2950470945dd08646d56a881fa3a75f25a601",
      "e4a8e30fbb37810a7518cd6f34cfeb27811af252c1646c2bfbf97bce0288aa0b",
      "c1887acc67e034ce4f8b1511382475373288e7c830b33e28b77175c8ce727e07",
      "698fb19e1138be6dbd50592227097d14bd942956b6bed5eb71135930d8d99809",
      "ef205f16f6d92537164b61aa4f6b9db3d033780b5900f44e9aab60cdb3ceda09",
      "e2601447905f7842925edf8f1b947f81920a88482363898f170566c2d055d30e",
      "a692a271ef23f63bffd18a6e3feb15856eb314be98291d2a9e0ad0b4b7179706",
      "1a18339ceebd2eba3a9ebeb845c1de64c238b6cdb2eef7a122b655068cda830a",
      "8afb29f178def62773036223943ae2dd282e28706c9426155eb9256c88565b08",
      "825fbadca58d956a03a8d87eebb6092ec0fc8727acb200b824c95ed313d9420d",
      "4b75b488f6777382a8525d5cef3895c076b7543e2160d26a34aa846d8a4d140c",
      "bcc99f6362af71f89a02aabbbfae649be18a444193188b15f5d01dc48935f902",
      "ee999496ad8de8f4896c368d9d89586d2e14ea8e3883d920e03e5675fb94a109",
      "d79ac8eb3d70f563fd9888224346f904367e78db8eafa8b7032a24494460780e",
      "552127f50ed94d35c4b016b68c00d7cd350e19a19858468c4986dc152d8d2c03",
      "a7557833d456606fcf3bbf06fc5fbf6f47d696b81ef4ea74f77e4ba1e3990603",
      "fe5bab378ab78b04d1886e2dc25d287a04b3a8eb1467e46ff075f27f0fe48705",
      "61666797aef58bbe43ca481af044dd447098495cea23d8d63d056da32603d70b",
      "2a5b67a832fde3f36e1817e38aeea69ca55289f86235f1507ef09a60eb49e700",
      "3f84cb53c0404f6eef18f58d85aa9a0d0caf0e99b4e6b9062dd8775c52a2c301",
      "a84eeac3584c52de0d2dd2063faffc6b54cab0ec4f72018bf725f55f8254aa0e",
      "55be476db2cff166f027e0a95278ce501fdbd4271c38b36fc5361530f758510e",
      "70437a8ca3625f8f0e11686ca41575892a1345d5c506a0c7ec40e37313216508",
      "3bae7f7df2848e0a29868908c5c7522421e064341ca5dc648f35926378ab2a04",
      "7437cf385bf11bee53ad0bb3996e08f6816d0836325c4da4de5df47a5b224c00",
      "eaae6940c54faf90816b88d9887a1038fc46a168afa2405c0f9f4c2796db8a00",
      "60cf19dda104371a6412d6c30087ff2c899d32df522c8903a3fd2ee484adbd00",
      "8e46a8c4bda13475b5aa002da8f08b63ec978eca85daba746b3480b2621cde0a",
      "381cbd6c671e13836df62628366b8c6e331d160da0695d495db842f3b16a4f0b",
      "dd0a438d652e7ab936c1155accfc8774fef439b647022c3ddb3350e70395f50d",
      "e1a74194f751ab154859ee1952d9a1b4972c382fe0ae68edb02b7acbbd81f805",
      "b8844bebc2d1e0fa25bab53e0ea0e03216eadcaa4a4317006d6103790a878e04",
      "65977e1881ff254d0c017525984f12b7ce60daebba58bed1ed907a2eb1da870a"
    ];
    int index = 0;

    QuickCrypto.setupRandom(
      (length) {
        if (index >= rands.length) {
          index = 0;
          assert(false, "should not be here!");
        }

        return BytesUtils.fromHexString(rands[index++]);
      },
    );
    final List<BigInt> inamounts = [];
    final CtKeyV sc = [], pc = [];
    // CtKey sctmp, pctmp;
    inamounts.add(BigInt.from(6000));
    Tuple<CtKey, CtKey> f = RCT.ctskpkGen(inamounts.last);
    sc.add(f.item1);
    pc.add(f.item2);
    inamounts.add(BigInt.from(7000));

    f = RCT.ctskpkGen(inamounts.last);
    sc.add(f.item1);
    pc.add(f.item2);
    final List<BigInt> amounts = [];
    final KeyV amountKeys = [];
    // add output 500
    amounts.add(BigInt.from(500));
    amountKeys.add(RCT.hashToScalar_(RCT.zero()));
    final KeyV destinations = [];
    final RctKey sk = RCT.zero(), pk = RCT.zero();
    RCT.skpkGen(sk, pk);
    destinations.add(pk.clone());
    amounts.add(BigInt.from(12500));
    amountKeys.add(RCT.hashToScalar_(RCT.zero()));
    RCT.skpkGen(sk, pk);
    destinations.add(pk.clone());
    final RCTSignature<RCTBulletproofPlus, RctSigPrunableBulletproofPlus> sig =
        RCTGeneratorUtils.genRctSimple_(
            message: RCT.zero(),
            inSk: sc,
            inPk: pc,
            destinations: destinations,
            inamounts: inamounts,
            outamounts: amounts,
            amountKeys: amountKeys,
            txnFee: BigInt.zero,
            mixin: 3,
            rangeProofType: RangeProofType.rangeProofPaddedBulletproof,
            bpVersion: RCTType.rctTypeBulletproofPlus);

    final verify = RCTGeneratorUtils.verRctSimple(sig);
    expect(verify, true);
    expect(sig.signature.message, RCT.zero(clone: false));
    expect(sig.signature.mixRing?.length, 2);
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].first.mask),
        "4ef28b572bf778530c02988864f1b547a28b29aeb4f2c986e0e32f5ea7ccc0f9");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].first.dest),
        "540e6fc0cab0e3a610f1da976ddea9998cfc9d2dd8e1361668b7705c19f790ec");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].last.mask),
        "a820b048c58d33970389f3df5cd184c75f37bc058b793b6fcc76ae2b140bd167");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].last.dest),
        "86f05e82dc687ace15de4f6ab64d43ded9197fa2e90fd99cc117f2199c34ca3e");

    // // ///
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].first.mask),
        "7ff437613e0cc229e50796c7acb254707133dd998db1f427bdc855621b7eb2fd");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].first.dest),
        "198414ea61cdb7cf1321fbf4584797690352143064a461202432ff6be28d0451");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].last.mask),
        "77c568ea2bbea116952ce3999bbd99b31ab4564826e1df40c52458429f9f7086");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].last.dest),
        "dea511a7d7d3605d7b02ff6049038f81f108440623756c71615664fe2c23b5d5");
    expect(sig.signature.txnFee, BigInt.zero);
    expect(sig.rctSigPrunable!.pseudoOuts.length, 2);
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.pseudoOuts[0]),
        "ff6a3868318415d80d58481108a0698338654cf40c3b65b62bc2ecdb7db253e5");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.pseudoOuts[1]),
        "40e612af2893861d24f5812eba8454e9f0658fd9e068d7a1746a7e057de063c7");
    expect(sig.signature.outPk.length, 2);
    expect(BytesUtils.toHexString(sig.signature.outPk[0].mask),
        "21843920f19aaf8fef33717b3e190f13d5c10029ecb94d8ecd89cd8e1a3dec25");
    expect(BytesUtils.toHexString(sig.signature.outPk[0].dest),
        "7574564e93668dd3df187abcd1607c02d0e80358f3fb4837a7a3cdef884fae6d");
    expect(BytesUtils.toHexString(sig.signature.outPk[1].mask),
        "28504fe8e30934fa2c401bf84ffc80b1f9738fdf833043e40d8c1a9dce45eedb");
    expect(BytesUtils.toHexString(sig.signature.outPk[1].dest),
        "81642659730ef8d10f4fa9b18c9dbf45c99ede6ef20f8d3b40ca1305006ca550");
    expect(sig.signature.ecdhInfo.length, 2);
    final ecdhInfos = sig.signature.ecdhInfo.cast<EcdhInfoV2>();

    expect(
        BytesUtils.toHexString(ecdhInfos[0].amount),
        "33ad6ebab7c67708000000000000000000000000000000000000000000000000"
            .substring(0, 16));
    expect(
        BytesUtils.toHexString(ecdhInfos[1].amount),
        "139c6ebab7c67708000000000000000000000000000000000000000000000000"
            .substring(0, 16));
    expect(sig.rctSigPrunable!.bulletproofPlus.length, 1);
    expect(sig.rctSigPrunable!.bulletproofPlus[0].v.length, 2);
    final bulletProof = sig.rctSigPrunable!.bulletproofPlus[0];
    expect(BytesUtils.toHexString(bulletProof.v[0]),
        "7de665bfc6c98a0b4d8d69121646fa6e70d009455d67c6d98995a3fe0c72c8df");
    expect(BytesUtils.toHexString(bulletProof.v[1]),
        "f69799725178d91b2ece233b7ccf19d8f558c5970ec39427a1022098ae6e5ef5");
    expect(BytesUtils.toHexString(bulletProof.a),
        "d7e4baef566673ef08e10f8889a5da7d2c795339019cc61fd2725995435b6b9c");
    expect(BytesUtils.toHexString(bulletProof.a1),
        "8e9c182924bec61d1b0f9a34925266550f0e5d3cae306389daf88cbb7dfbf59a");
    expect(BytesUtils.toHexString(bulletProof.b),
        "03e3350db94d7295f3e35aa96b080341464cc20bc872f217b641997826935bb0");
    expect(BytesUtils.toHexString(bulletProof.r1),
        "3815596d0707a3f92dfc38ae68b3de68bf8dda965e6e78084f356e4afee9f80b");
    expect(BytesUtils.toHexString(bulletProof.s1),
        "75efd30cf2b147633969cfc3d9ab4bb72dc819aa25a417ea0f14da156325b702");
    expect(BytesUtils.toHexString(bulletProof.d1),
        "1019556a696ab738948157bf5cbda5f23155fbf79d86ff41619a3e786370360e");

    expect(bulletProof.l.length, 7);
    expect(BytesUtils.toHexString(bulletProof.l.first),
        "bc3ae0b1f7f767baf928ac4205511cfd579a2b1dd129d1719d59f91f522bbcf9");
    expect(BytesUtils.toHexString(bulletProof.l.last),
        "1a5feff4ee83825426c758a6242363bc39fa3fda20ee5376304f04959e1984ae");
  });
}
