import 'package:blockchain_utils/crypto/quick_crypto.dart';
import 'package:blockchain_utils/helper/helper.dart';
import 'package:blockchain_utils/utils/binary/utils.dart';
import 'package:blockchain_utils/utils/tuple/tuple.dart';
import 'package:monero_dart/src/crypto/models/ct_key.dart';
import 'package:monero_dart/src/crypto/ringct/bulletproofs_plus/bulletproofs_plus.dart';
import 'package:monero_dart/src/crypto/ringct/utils/generator.dart';
import 'package:monero_dart/src/crypto/ringct/utils/rct_crypto.dart';
import 'package:monero_dart/src/crypto/types/types.dart';
import 'package:monero_dart/src/models/transaction/signature/rct_prunable.dart';
import 'package:monero_dart/src/models/transaction/signature/signature.dart';
import 'package:test/test.dart';

void main() {
  BulletproofsPlusGenerator.init();
  _test();
}

void _test() {
  test("BulletproofsPlus RangeProofBulletproof", () {
    const rands = [
      "eeeb324b1f601ee22b0864a10f0f6d148fd2373c92eacce6e571a24aefb02b0a",
      "bb32ded76f5d0727ef91cdefa98321c232b3d28c8f5de8014043be552d83c90f",
      "a1d0c89e45c26af02dbf8b168f4829c6bf5ef0cee69ec98a3c11a8b99a067007",
      "c6a03f38c0a474113c6f90fdd082f0effe65e856cd4c924b51e95906ae3e4108",
      "f78aee0bd724b4ca6d4a94d3196bc6ebd56e268673546c0d4764e01e3d1bea06",
      "e7ac413d3a0b5bea99a6c28aded068f7fd078635ccb01f3327ee48fa58332302",
      "c2d5508f4820495bfca45d748def1da447310b15b791da1377968f58148d5b00",
      "455498a9c2e3aca7030e6d2e52f7d3fed0046adf8eafd014b6a8ab0f2a8d6a0c",
      "6f9ee6711a1d609f7ee7472f2c0644343ebd91ef05a4a8b281c8715dc595f900",
      "11d8899c09f6d2e365193ad6c72ce9ca2d579d4e17ca34347fb975663fd51d09",
      "5e668406894ccda0d26c2ba68d9886a479eafae9ef2dfc9b24600484f8eaee07",
      "1e95576e70fc98ddda634f22f68e907fb64ff4fa813a3ed014a42b26d6319d08",
      "309064cdf6294c2dc930065078ab996301920ed29e6cc0a2db46565570129302",
      "8629d976b705ea9be10486663645556b1e31d4a3322c4177f9a6f2295a8a2f03",
      "e28cf69d0d44e6176cfd24b4b8676994451b4718cc1fbfa0ad11588455a9e20c",
      "7e53080629741c262efe9ce3bcc9141e8bf390a8f1fff22fc54b047b18a67909",
      "89d287bc9df402725559cfb75fe5a408e43024e6671cd251d24098c1c33eaf03",
      "e3b9d2967b9183cc7bdfb9c8461bc140210316bad40eff84153c713efe70f30c",
      "137887d2ba2afc34a2089de16f946ac15cce531192c5010d2f35a60bd9022e0b",
      "4a09925095f5b4d08e006d621dc2ba410d24eacf3a52e8f0d58096d786f15209",
      "fb81861c79b9e2ba07b6a59406882468898b678dd7dce84612ca386a5fe68604",
      "14094975af8084e054b75dcfc14e34878f111e5acf558d19685a80542b57830a",
      "373c2a227106ba5e87c6eea46d1118a13abebf836947c8057d29fb1c54957005",
      "13c8c03af69a4ce9b95cf849a936ef19eb120500eecc7fdf29c5bc11d2ed7c00",
      "ceffc810de289c42aca0cf405715b2af58134f6ad44a92d6a5684cb2432c0804",
      "1837085737d2c60070465a5c4072c56d09f26dbe565cf7e8dcd915d73b6e4e0e",
      "6df786b6720aa9a2e0e065f8525407add4b7e3db1523ee1b957f6d592ace840b",
      "5c2aaa8742f4f3f8eca79a81576845525ce4b47280d9828164b47d3addc85c06",
      "d5a824935df6f72bc6c8bbb56ab78b27d4a0c314167b78983d7682ce79dc070e",
      "8514ffb2875cf63eb93af36a254a9cc13dbf7c4e0138774dbb5865e8587ceb08",
      "ffe505482d0b722fa0be3aee320800daa71d1f18d215a106dc8096c6ab2c0903",
      "3d417f4a5813ed5672752d09bc3f1a073f5ff4eec5dd778ee4fd8f305a1eab04",
      "1c3801517ec25d246bc9aa269400d6578e3687466ef6983bbb1902fb9888560b",
      "8243b382b23d84b7e733c6aa35a65898fa942d167293a558f587ba840b1e5d09",
      "f48a32fe5eb0ba574420f5236e8cf22647e1a4917e384a4e81b9f3631f84140f",
      "0c0ca038df99de692118fd04a61310f2833a3036511e10f550b97826e425c20e",
      "40755e06152e4ef5f7761f16e5b583002cea850b58e28febd3702d9c07620a08",
      "ba5bba1f44ba53e5d09222177f9431db9c2d536156b21a2c436baea93de9910a",
      "26485c0005288e916020839f38b383ff5088d4a810e249eb1685158c32dd760d",
      "0ca4a63b58e8c17ed9e47bdc1fcfcaf47e4d2c2acaa2099c0babc2dff166500a",
      "14828519589bb1251b19cfcdbc3fb9cdca44525c8b1dee9ef01a6f5af5403a00",
      "759b004431402bc12e99955a0cd44e268d7eaddf997d7f9e7a7fde0e32ce170f",
      "ca7c6fab32e47eb6f5b047f6de4ed8c53f3d11fb9352954c8afd47e912adfb02",
      "1030167d0c69bcaee6788be751608c6087fc02f491b8214e6bc30bd8a1108307",
      "7ca98c2709afb29dedd2a46c8fef785c3ef9d596f135b3fb21fc06942d28b909",
      "3870deebb3aec6b3d582e63126ad9a35b96df20cebf1cd2a6615c658f24dea03"
    ];
    int index = 0;

    QuickCrypto.setupRandom(
      (length) {
        if (index >= rands.length) {
          index = 0;
          assert(false, "should not be here!");
        }

        return BytesUtils.fromHexString(rands[index++]);
      },
    );
    final List<BigInt> inamounts = [];
    final CtKeyV sc = [], pc = [];
    // CtKey sctmp, pctmp;
    inamounts.add(BigInt.from(4000));
    Tuple<CtKey, CtKey> f = RCT.ctskpkGen(inamounts.last);
    sc.add(f.item1);
    pc.add(f.item2);
    inamounts.add(BigInt.from(10000));

    f = RCT.ctskpkGen(inamounts.last);
    sc.add(f.item1);
    pc.add(f.item2);
    final List<BigInt> amounts = [];
    final KeyV amountKeys = [];
    // add output 500
    amounts.add(BigInt.from(13500));
    amountKeys.add(RCT.hashToScalar_(RCT.zero()));
    final KeyV destinations = [];
    final RctKey sk = RCT.zero(), pk = RCT.zero();
    RCT.skpkGen(sk, pk);
    destinations.add(pk.clone());
    final RCTSignature<RCTBulletproofPlus, RctSigPrunableBulletproofPlus> sig =
        RCTGeneratorUtils.genRctSimple_(
            message: RCT.zero(),
            inSk: sc,
            inPk: pc,
            destinations: destinations,
            inamounts: inamounts,
            outamounts: amounts,
            amountKeys: amountKeys,
            txnFee: BigInt.from(500),
            mixin: 3,
            rangeProofType: RangeProofType.rangeProofBulletproof,
            bpVersion: RCTType.rctTypeBulletproofPlus);
    final verify = RCTGeneratorUtils.verRctSimple(sig);
    expect(verify, true);
    expect(sig.signature.message, RCT.zero(clone: false));
    expect(sig.signature.mixRing?.length, 2);
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].first.mask),
        "2245a82e543d3f6e5d7819533d42d3d3aa88b64e7c0f31b7e113491be1e52437");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].first.dest),
        "31204fba57be2a6757493a410b382fb9e494b16ce795e06efb859a387364a649");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].last.mask),
        "aabd8488a6f646c9cce44ff465d65689e6ecd17fa63ad426f5c4090c6f930b8a");
    expect(BytesUtils.toHexString(sig.signature.mixRing![0].last.dest),
        "a5ef6df121a660124c4b14ea5d3eefb9a26f0a3d139008bb8fa869ea7ab8e3d7");

    ///
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].first.mask),
        "4a9267f881bb9ebf3b716b9720a95cb7b13e025448e465bb53b8b7e3b0ba445b");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].first.dest),
        "4404c5b95c24199d429256c77c536553b2d7409a38abb164af8fa1c5f838ff37");

    expect(BytesUtils.toHexString(sig.signature.mixRing![1].last.mask),
        "1e8e501041e22a72882f1abb2a9ccd64ff7d67b1723b657af4adf7c81ac3bf88");
    expect(BytesUtils.toHexString(sig.signature.mixRing![1].last.dest),
        "59a50b9858446775c27397342d534ed01d73edded5999ea4f04c38630542be27");

    expect(sig.signature.outPk.length, 1);
    expect(BytesUtils.toHexString(sig.signature.outPk[0].mask),
        "d8697a3858fbb639c3ca692c4cc81c72c0f45d99fabe46f2ca34067147cc98b1");
    expect(BytesUtils.toHexString(sig.signature.outPk[0].dest),
        "00deef169138b49da540d18c055bdde293a32cbce20ddc9f360c1264704bb5cf");
    final ecdh = sig.signature.ecdhInfo.cast<EcdhInfoV2>();
    expect(ecdh.length, 1);
    expect(
        BytesUtils.toHexString(ecdh[0].amount),
        "7b986ebab7c67708000000000000000000000000000000000000000000000000"
            .substring(0, 16));

    expect(sig.rctSigPrunable!.pseudoOuts.length, 2);
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.pseudoOuts[0]),
        "e30e371bc29c86acb8b6721abcbf2905367c64d83378bfbace5d337897b350e2");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.pseudoOuts[1]),
        "56e21f9477deb244bff7a03758863fc87a604092f00ff1ecbb6cac16a0367d7a");

    expect(sig.rctSigPrunable!.clsag.length, 2);
    expect(sig.rctSigPrunable!.clsag[0].s.length, 4);
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[0].s[0]),
        "0ca4a63b58e8c17ed9e47bdc1fcfcaf47e4d2c2acaa2099c0babc2dff166500a");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[0].s[1]),
        "14828519589bb1251b19cfcdbc3fb9cdca44525c8b1dee9ef01a6f5af5403a00");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[0].s[2]),
        "6958d0907e11720a629d1165d5e3899887d36a9d4a42b92767f393ec68989f05");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[0].s[3]),
        "26485c0005288e916020839f38b383ff5088d4a810e249eb1685158c32dd760d");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[0].c1),
        "5c41cbe74df964de649e98d8c23948fe184b45518e305ffdfd1a2e6925971708");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[0].i!),
        "dc2db556eeefc93b5bb1f100287ae31fa000635e15fc4b81d988522ac241815c");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[0].d),
        "0a98afe7f6b452b706deaf3a2242eadb1c811a166f2fb4218e40f6b3fb8bd755");
    //
    expect(sig.rctSigPrunable!.clsag[1].s.length, 4);
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[1].s[0]),
        "1030167d0c69bcaee6788be751608c6087fc02f491b8214e6bc30bd8a1108307");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[1].s[1]),
        "7ca98c2709afb29dedd2a46c8fef785c3ef9d596f135b3fb21fc06942d28b909");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[1].s[2]),
        "a7e9347ce3f7d0218174925791152789152a05989f391ca440501db3fd5d5701");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[1].s[3]),
        "ca7c6fab32e47eb6f5b047f6de4ed8c53f3d11fb9352954c8afd47e912adfb02");

    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[1].c1),
        "00f80ab10916ccd40ade3f38c510d1bed7fadbf6cc9a9749c6fd0f522afc3300");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[1].i!),
        "84435ef6719ad53def6e2ccd5b7c49d8c9f4c48d1b7ff571d6a48ea127af3189");
    expect(BytesUtils.toHexString(sig.rctSigPrunable!.clsag[1].d),
        "3567664ba415750c6be2e63ce57f3f24e6a4b3f0ba4fc54efadacaa9db56a3dc");
    //
    final bulletProof = sig.rctSigPrunable!.bulletproofPlus[0];
    expect(BytesUtils.toHexString(bulletProof.v[0]),
        "10f44612272545f0a17c3e00cb6659806743a9c6321befec72f0db7dd372d1f9");

    expect(BytesUtils.toHexString(bulletProof.a),
        "204ce910e0bea92db32dd6abaf14c7d6690210e3c588513861342985939eb4f3");
    expect(BytesUtils.toHexString(bulletProof.a1),
        "7227d72307fe71ffa040474f0dee23e9a4239da70daef78c01ac2d82438b3726");
    expect(BytesUtils.toHexString(bulletProof.b),
        "ba7f45cb3bd712bfd05b6f120714658cf403524af3d7b628f00ac977fa0fce31");
    expect(BytesUtils.toHexString(bulletProof.r1),
        "fba6669d3dbe3452e53cd665230627aec329433d9e2bc0ec87cec352e81bcf07");
    expect(BytesUtils.toHexString(bulletProof.s1),
        "9a1c40f32391a574c9f4ddb93321853b6d4f02f21d7c787c7b4c29e8c6d63e03");
    expect(BytesUtils.toHexString(bulletProof.d1),
        "f58f308372edd37a1a499a5b18033461ef629f4bc8950e98fca665d54cc98b0a");

    expect(bulletProof.l.length, 6);
    expect(BytesUtils.toHexString(bulletProof.l.first),
        "9e17e3ee3d90d6f17e62b88cb9ed961ba5e3f9e634666e3873568ca5578fe0f0");
    expect(BytesUtils.toHexString(bulletProof.l.last),
        "89365d60dba6090c52d062a628202eb062b2c9fb03c1f7519a89bab64fad6e0c");
    expect(bulletProof.r.length, 6);
    expect(BytesUtils.toHexString(bulletProof.r.first),
        "0dc8e10b46e6fb8a53958534de32ca7c281e8896e6b41d88310b524e06c8fd37");
    expect(BytesUtils.toHexString(bulletProof.r.last),
        "e881e1f276f37a6af63972687540218a079d868d6b456c89d5adad09e7db21ab");
  });
}
