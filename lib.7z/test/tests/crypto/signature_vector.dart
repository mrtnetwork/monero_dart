const List<Map<String, dynamic>> signatureVector = [
  {
    "hash": "62eb41777076bd1a90450e80e77cb1aca6a5f08e2320128b704b663402759d01",
    "public_key":
        "8e83ce60900fabed38fb560505d26420775f10ad6729b209992816101c1c4cae",
    "secret_key":
        "14fcd95cd127e1218c11fa267c46f8c2d5c1c736e53f8bd2bf084693d1114404",
    "random_scalar":
        "6cf2e94a33a801b7f0822fb93a0bbeda3b1ae2b869bc48d1a4fbee82e1d85b09",
    "excepted":
        "e026462d3e607f1d481a090768560f9ed2bc1632222cd65769d33b2442f776060de49f213a6bd4d4642bc5f2b7000cb7fc4c06a21f2e4ed8083b823a5687e806"
  },
  {
    "hash": "b862759c98652ca2b1522a556729103de96cfe831b3ce615547ba70c5f622c0f",
    "public_key":
        "b7827c8b2edc9b4014cf4421f1c9792c012ac3264b15204596652d5854bc7673",
    "secret_key":
        "1e62f5b7eb5d2bf88032c98edc74a9c138969cfee15f4cb69990feabc0f8840c",
    "random_scalar":
        "b380e50df296578856654800f5b9d67d49aa9558546a670420732287b4c75e00",
    "excepted":
        "3cd058dd47196e9c6f9f0175dd7e53786b9806c9dd12e16b5156f95b46ca940ab24b72938b6b23769528453571f82c8127fd42288cc1c3261fb1aefb1ce1160e"
  },
  {
    "hash": "5dee08dd0f483aa67e0b2539c362eca5c4529961935d56f661ba641e5efa7e30",
    "public_key":
        "be75e0ce86b68a72f7487fec4857a7a6a188176ebcb9192123ff98c49bd2b4b1",
    "secret_key":
        "b13ba6bfe9c23671e7bbc4a6380c1ab6c61b09db58220d28781d8ecb1b37e609",
    "random_scalar":
        "921c21906cac3499d38f8ee5eb5bdc943a0f19358524d97ca9ad694ba3780707",
    "excepted":
        "205844496f9d38acb429627439c174716b5450b441f265ddab1cb3783d046d0bcf0856035e8745b61a9ed3ed6f36de752d2c37cab25b59db89c472720583d903"
  },
  {
    "hash": "e88cf519e819375fc59bc8de8ba403278999311c7490290f2f5438306bdaf339",
    "public_key":
        "ce99f73115a02e03f42a1b583dc3cfd5fd1747c1400d1b6df73e1a3ddf616932",
    "secret_key":
        "0a33216348544ad80a652433253b6921c0599d3a80e4b2d4a0477cb121e08104",
    "random_scalar":
        "c6164059b6e29b4f34101c3116625c245a56b8353cf276aacb54f08318ff5e0d",
    "excepted":
        "7315e8ecc3a4eb0e77242eb20880a22d9ba9c4742d4f2ce53ca69ac9d819c90439903c244e7d98007c3bb6cda9d1315cbdf126774cb3b5e1262d6f27a09bd301"
  },
  {
    "hash": "82a2377ac1c6a103cc0b955ea1ed3fcc41bbfbf6416b31984f28aaacaf4e2a94",
    "public_key":
        "535ce02ef72e89bd86e0fbd9f8f0197a99b11f81128f5179044e4e6d0f5f1a93",
    "secret_key":
        "dcf1736d7a4306330ffd64315b2122c5b55bdf115dd52680d5ce798893b62a02",
    "random_scalar":
        "0d54c3c5d8046ad415e0bb9e99d359f60ddbaa07cf12cdb069ba80fa35021102",
    "excepted":
        "76b154ce9fcf5579bbd1c9c63c897fa508df5d97f63854437a7946db83400d063a6a1e3862d399d746d45042e49d0e079664ff8ef87954fe42a9d5ce5298440c"
  },
  {
    "hash": "b207af5749179b6f2b30f48f2e0c19d90b6655cdeeb3fc37f656321f50ab1508",
    "public_key":
        "b2b43995a5ad7f51c6c71d29e1991f431444b5e73019b3d36fca05bc566bcf41",
    "secret_key":
        "b1e043b1b9f4c280f798aa59c2f62e46c4abbc65ceb17349f4d11b867937ad0d",
    "random_scalar":
        "23b888c3387955b2950af690c5b9bab6ca3af8ed9a9ffb951789277d50332e0b",
    "excepted":
        "23bb444f59be1c0f4f8358d666d6ae68ae8c66c9db14b6856cdc1fd63e8635075840682e7402187da4e9ecc029bc56aafbd78375de5dd6b0f488f0d63fd91905"
  },
  {
    "hash": "63e53137888836ef30cd6a93d34a0fa749fcd9459bafcf143da29956a6f35060",
    "public_key":
        "4762dfaa39af96a85ae746326693ca87d82a008b96c84792ed1c570abaaa81b5",
    "secret_key":
        "723eaeaf84c9dae7476aabdc5fd409a0faa7c61ba8b424ff78d299b9480d5a02",
    "random_scalar":
        "42e4b4d13ed6f9302b0a050f7fac7fb7022d79976b9795c93946c433e2665d06",
    "excepted":
        "724547df2ab484ef491cfa091b995c8c2032e21594537758e55419aec3032404904640e1697b644c00e3f34d24e549e9a978b31c5cfd9a3c10c1b41d85a0e904"
  },
  {
    "hash": "4cd5f4b8cbbe735336d469aa8f2f7c7e5195d60f897b9a81b599b2e045850705",
    "public_key":
        "4a6dea121c196f56360e8c17273f1b94827efe1f24cbcdb9d3ed61b9a207b73a",
    "secret_key":
        "a8e62911309f4d4fe0bb6284fc4e3cf4fc5b08e3812e27328f68c2a6c278440e",
    "random_scalar":
        "347065b13ad735ff9e1cd8b471aca4f97d7690b326173fecbbd78528a6d8990e",
    "excepted":
        "eecc9abe3dbba36b6aca1a2be66799c60abc0253d10538bc02bc6f8e1bf0740a5f2bdf4d0caff609208e391697991f58d7c96c6c54bde7be19aa035222d37a05"
  },
  {
    "hash": "7687ef751d6533aca6c911d70bbc4a8c5252fbd3112969a9a40b9e1dd041756d",
    "public_key":
        "d17a5002e137731bdad6600b5ea02b520efcd1005008c6f1244deb839ea041cc",
    "secret_key":
        "c848b5aec4dd76bd8e33c37ac65e884699fdd7b5c7a905801f2f46c56f783005",
    "random_scalar":
        "a843cbb2a416c655669cbf1a5f452beddba17c8f5c17711c9af6d2580b4b890a",
    "excepted":
        "6fbae7a16686add04df91baa0682bf7751d8752e76e106114ad7e76d1424090b3355dc0cc85f294d098221fb887b6c849d26f1224b1680db40ec31ee8ce2ca0d"
  },
  {
    "hash": "1772e5a77a57fd69d6ce9a68c81bd9c4f81579741103a177bf584819a656e1b2",
    "public_key":
        "2ed6932a62fa064c9c2e39c7ab0ddbb6786dc849286af8e35655a58cc9be79da",
    "secret_key":
        "b9446a654072103d6e331cea1425472e0782b532ba9e235d61ced65ad6ff3705",
    "random_scalar":
        "93dba1d862d13f16c84fb050117483e48d5821979a4bf468901cf954f6b86d0c",
    "excepted":
        "f67aeac9a7b7e4de9edab7720ce2daf13aa1e9e6a96b7859a07beb38aa7e770c337c98f5fd0356da6cccb9734cbfcf361ad19ba942a921d2bdf3f191874d5105"
  },
  {
    "hash": "fda1233d780d70dbc9580c2b80ef1806a8ea2df30c317f7891462d96fa4d66af",
    "public_key":
        "5f769cca4be9aeb809e9803160b179b1a7bb7cab0e2b0f6311c9e29a8db20de8",
    "secret_key":
        "076d27b6f85be7acbfbdb38d1b22e1d75c139072f7ae9d33bfb7590b474abf08",
    "random_scalar":
        "307e5c1c1643cba6aec9b1f7c67fde082ff1686c6a53376b2b4a8a84af2c3f0f",
    "excepted":
        "16f33ad4e4faa3da85e9eecf58d25c39351b325eedabd5989cf5dbe2a5aa9d01e26add3af3956724f93e6fd55d5d55784151bd3bc58da0b863845e153d0a0f05"
  },
  {
    "hash": "206fef6045a5e44f87bc7acd4bdcd271e1c55cc8e42f5943f1f0b1b3dc0fcc54",
    "public_key":
        "9d32cb01bec30e0d7dc921f1ce44b5a829fd84c37e4304e4f910cb9df501af4b",
    "secret_key":
        "8adec55623bd61bbf39d72e3f891419b5264af1bfaca43278dd86a944ec04c0d",
    "random_scalar":
        "6cf2e94a33a801b7f0822fb93a0bbeda3b1ae2b869bc48d1a4fbee82e1d85b09",
    "excepted":
        "16b0c72cda4893fdf9bf838798e2c3cb4b0b362e49d6c1aa269cdce6ef29c2090f1df9b447caec37302a7f854883ce4fb692ee962eb7298b4530c84c72cab708"
  },
  {
    "hash": "f63c961bb5086f07773645716d9013a5169590fd7033a3bc9be571c7442c4c98",
    "public_key":
        "b8970905fbeaa1d0fd89659bab506c2f503e60670b7afd1cb56a4dfe8383f38f",
    "secret_key":
        "7bb35441e077be8bb8d77d849c926bf1dd0e696c1c83017e648c20513d2d6907",
    "random_scalar":
        "6cf2e94a33a801b7f0822fb93a0bbeda3b1ae2b869bc48d1a4fbee82e1d85b09",
    "excepted":
        "63f0ac3964d00271788590e16f5a5c24f113a76207d4a364ed678251faa88e0f4f812373a8d44d9bac0d59c77a8d2917c1f296cce8a6bcc22a0a7ccdfa775507"
  }
];

const List<Map<String, dynamic>> checkSignatureVector = [
  {
    "public_key":
        "a5e61831eb296ad2b18e4b4b00ec0ff160e30b2834f8d1eda4f28d9656a2ec75",
    "hash": "57fd3427123988a99aae02ce20312b61a88a39692f3462769947467c6e4c3961",
    "c": "cd89c4cbb1697ebc641e77fdcd843ff9b2feaf37cfeee078045ef1bb8f0efe0b",
    "r": "b5fd0131fbc314121d9c19e046aea55140165441941906a757e574b8b775c008",
    "v": true
  },
  {
    "public_key":
        "9fa6c7fd338517c7d45b3693fbc91d4a28cd8cc226c4217f3e2694ae89a6f3dc",
    "hash": "92c1259cddde43602eeac1ab825dc12ffc915c9cfe57abcca04c8405df338359",
    "c": "b027582f0d05bacb3ebe4e5f12a8a9d65e987cc1e99b759dca3fee84289efa51",
    "r": "24ad37550b985ed4f2db0ab6f44d2ebbc195a7123fd39441d3a57e0f70ecf608",
    "v": false
  },
  {
    "public_key":
        "8a7d608934a96ae5f1f141f8aa45a2f0ba5819ad668b22d6a12ad6e366bbc467",
    "hash": "f8628174b471912e7b51aceecd9373d22824065cee93ff899968819213d338c3",
    "c": "d7e827fbc168a81b401be58c919b7bcf2d7934fe10da6082970a1eb9d98ca609",
    "r": "c660855ae5617aeed466c5fd832daa405ee83aef69f0c2661bfa7edf91ca6201",
    "v": true
  },
  {
    "public_key":
        "df7f028022cb1b960f2bd740d13c9e44d25c344e57f8978459ffa3c384cd541c",
    "hash": "ec9deeaca9ce8f248337213e1411276b9c41e8d4369fc60981b0385653c0f170",
    "c": "2c2c8e7c83b662b58e561871f4de4287576946f4e26545ba40e78354c6d0b36f",
    "r": "69ea44892f39a46cf3fd5c2813cbc1c525dac199ada6fd5ca8e1e04cff947700",
    "v": false
  },
  {
    "public_key":
        "d257f46216be34be5589e0b12094e643d1b31bc3c50e006d044d1ea885b5007d",
    "hash": "114e8fffb137c2ce87dd59eff7f4b8e6cc167fdd28c3ea77d345d2c8c00989a1",
    "c": "9579b6e8dc108633ac8b67004699921aef479b6e7ee9590073fbe1404ee4b3d5",
    "r": "33dec29fd35540f13ac531c3ae49abb62cbc11d36b0cc3353db77a294d8d3d92",
    "v": false
  },
  {
    "public_key":
        "a05a3a6776f85c5d04c42fa2c6a731831c3d3a4e3a12f967f9ba0b1ecd1aee98",
    "hash": "ce03e1fa5476167c3ebce1a400ca1d2d375176b5cb9ed180913efa1a688ddc97",
    "c": "4992de4fec265113710ec3a211e86784581f96241f0305d069a1e4629b504d03",
    "r": "b3a1561fd9e73597db89ba00beeb60d2107c1f835176949bd354e8a173d46705",
    "v": true
  },
  {
    "public_key":
        "306593abefdbe99beec4752ebb135131a93e8361fc35f60a1c56fc4501c6782f",
    "hash": "7db838c96a3e1fb14156986aef37b70f932ee79d3cbc8233cdd76997eaa0c0c2",
    "c": "5bd47b285d25ede033bc5c2049edf3feb06fe29091e2c90ba25128c6c1a05071",
    "r": "3f28db1b9106013d22d5e0ba05bbaca43c4d30b6f0bbad8768e6cb89b205c20c",
    "v": false
  },
  {
    "public_key":
        "c2257e5386cdef44b989ce395532b8e03dde166ba26c18759e1c440738242fe4",
    "hash": "2d96536cad13a409d5a46a6bde1f5cf1d9255e741d5a17309248dd910e02d1c3",
    "c": "2f5e7a5c690c0d3bb2974e47eaa159d0bb2205a636b8cd09736add9fe8d75bee",
    "r": "4249b30f8e1b99c1dea45999842f5709d2ee1d8e450807319723625074c69605",
    "v": false
  },
  {
    "public_key":
        "8d4c678d19b93fe24e90e1e78ba439e3ab8c3d6fc8c2eb89bd343b92040de1b3",
    "hash": "87625d63fcb5653575416de00c82ab4d893d6d5b64bb79eec564f61fe6cbe4de",
    "c": "02f424dc88a9fa42b262707cb874d1e480f74a366bca7ae96bade60cd0c9e551",
    "r": "5e993b892609b1d8dd2835177568911df548717b0396f9ecafa6d977dded2303",
    "v": false
  },
  {
    "public_key":
        "f5834a5bffe7f8fd69ae6626e2d95902f470b309968c65834cefae251c408425",
    "hash": "83824c2a42fd2d1f9f74106ce128ea3402261eb67a2cbcc74603b8fc52c694ed",
    "c": "0e652aa0db24b0346fb2923b9c16d94f7038687a66e491c2dba3aa62a5ce27a3",
    "r": "f15127deb15af6f02190486e65f4e48946a2dcaa85c54ba0273ddd84815e630f",
    "v": false
  },
  {
    "public_key":
        "13f4ba800ef35daefed6b8e54e865113b1d523a8719a5d22f596fc12203298a1",
    "hash": "bce37b33f7ee148282c3ccc12565da4f7c53af9646df616b17d95631ef209d14",
    "c": "40cd174bf8b7a7564ed09b8f5c15d1b2134e5b8a36ba907dcffa5d76eb201c84",
    "r": "2eb63d40eefa4fb71a7e6f7fdadb96229daf56a121e64484e12e2455a12760bb",
    "v": false
  },
  {
    "public_key":
        "42f746e23416bb1ca24b486424c3462291d9d6fa7436da6e66e59bae0ab43162",
    "hash": "1d7a83ae9338726c1b6776f5fafdd78a79df32b1f8bd2702727d9c17f8771caa",
    "c": "9417c063b682475fdc01a623b1a88043f176b1df0965b28b54de2712193a740e",
    "r": "66f56b22815a05bcecbbaccd5494d29f7bbce32456201a8a21f0cca1892187cb",
    "v": false
  },
  {
    "public_key":
        "53fd594636a7e10be480b78eb51a8188ea610be58fcf98b16202d2481dee3662",
    "hash": "b921adf724750c6305c33cf98dc866dab70ac24ac2c6aba47b9cfb621aa0b691",
    "c": "f624b6b8bda7df029d85e5c9a4a2a206fa84354ac703eeedc44a1f5c9d33e306",
    "r": "bca16faef19fb8af6f7ff8aba005092ffa1781592ea0c193f5edbe1ed2bcb11c",
    "v": false
  },
  {
    "public_key":
        "d4f328c185fa9ef3398acc0e62a47b738f9f799e6649dccc0ade5f6b0b5388bb",
    "hash": "06f6ea8e3a4cc5e6da4a5c300b8056eab7d9a260bdd8d445146a906a46377003",
    "c": "c26cc73e7891b1d1c4c7e8166c835198317fa6c024e245693ccb8a9a456c9b04",
    "r": "edf11f00b64eb317d1617be12d1d49606f25195017666db6242a58e98f839789",
    "v": false
  },
  {
    "public_key":
        "2c7814a245fc1a24ea25ce395415bfb715a9c84832d49f2e560d108afac578dd",
    "hash": "9409e7a481efcc779b8ee25b012ecb057cba3967296ff2e540c4c0f4dda0e82e",
    "c": "567acbabea38bfffae0a7c2b745c574197471e12b239aa410fa77f497a372ea9",
    "r": "41711917c6018502e340860930494c112cd107d0f6bf48dea68c18ed6b8bbce7",
    "v": false
  },
  {
    "public_key":
        "6ea89899209ea552694676dd68debaedae8188a6bf0ec95ef64ff8ccfbe79a68",
    "hash": "ef83026149b0a2f22f2e086c8d4b8b237b25b82acef3f90214fc0b2dd8434516",
    "c": "a00ac22a9ef1cd65832759ec6d5f868c38ec719ea6831090e8d93799929eaf72",
    "r": "fd476f9257eebde6bc449d942cf20ed71d14bdc1852521942f2ddc4690a21bd7",
    "v": false
  },
  {
    "public_key":
        "d7b213889dec8fbef903f80df2b7e96881eb8faf8267fe0df3041359230aef90",
    "hash": "1b246206e60db2d7d2f54356a2973ff6dfc8921229923f57ecd2096f087952d8",
    "c": "b81181559d0ec72984bb9fba9e1ef5eb3c3904add1d57197d19a04f0b3d5d557",
    "r": "8f4ad39becb2d1d12dfbb0a9294df4e0ff5eadcc29a7a9d6d52920c7cd5ac70c",
    "v": false
  },
  {
    "public_key":
        "6e3649ed3894b5423adecdab1d1782be4640a92ed310aa2199c5861cb3405e96",
    "hash": "6d18e81cf4dcd5dfea5b12c2287ef3317089aa5a5eeb813d4156ea08958db8a3",
    "c": "e99b6acc2c6169e1635adcfa55777c2c8b3023af17fb4fbcb2ed44435ac6da10",
    "r": "afa8743f402cea715f4b59323ca6a3d74df2dfd955194f8c1574e4234ac66700",
    "v": false
  },
  {
    "public_key":
        "55290789bf61a9d623dc8453275660fa69f753a8dd25836dfa1a55a836c08659",
    "hash": "9a42386a99a81416028a9fa66cc49d8aa66af6982bf709e8d5c46d60f5eb57f7",
    "c": "f67d12a33595183573e2708e02df73e301d988cb75bad371d59ea92a4304ea8e",
    "r": "a879a5bdfec3a68b9ce0d53bfd72808567ab897ff8758b18401ed3cd688459aa",
    "v": false
  },
  {
    "public_key":
        "aa248b65faf63026d2bd3e159c7273a69af4d1e2ed917d4cedd0f24eb0d61991",
    "hash": "b49f3b74d8da9917c016e5ac06f8437b671463b8a81b2671243df2b2b8052fb2",
    "c": "ef92065a1f1e51568ae40238a4be93f811fc06885193c60d85b76dd3fe68b6d6",
    "r": "3eead361ad0090e2e270d5d2f199c6b95d19f9942c21cfc20fdf313e43f39b03",
    "v": false
  },
  {
    "public_key":
        "416f5246a8a8a3402e137a8befc05d6f02db534e67461397023fbe0e29b77aa2",
    "hash": "fafbfe9233c1be9051ca8e2ac1b331b8341842d91de0f802817a5c30c234f391",
    "c": "542e9b73109b1febc0c9cfa6384e43cdc0f0c170c746849ffccc626232355860",
    "r": "c717f1c4d11ee6fe90a75b0294fae2dfe025462ba44704f193ef54092e9d5808",
    "v": false
  },
  {
    "public_key":
        "14c3d2ad74ba443296102139cf94b421a72ff62f2b8727e303e53d6a22ac7faa",
    "hash": "61154b91c6610d2d001a1e6f6f2652faecfdfffec237dfa844ac799b393de4f5",
    "c": "9e4bfd899e87b3b88b7d39f4546605ae892675315b0ed83176edf9947924ab06",
    "r": "9750696702856e7ecc1561cefa65d149540223b15578b378926f6196d8572f0d",
    "v": false
  },
  {
    "public_key":
        "f79812b95048683d47eb5435bdd97c5a39532c6693dc8b965af76d7f3ab88e92",
    "hash": "40e0758cd9c9f8f8f7d0fbf351084863973a3622c92dab501ffdee610278f86a",
    "c": "a9ba1cb8bf2898e21c12bfd23788994fe20d45ef6f775c197ab157d7c2721100",
    "r": "f2123c19395f13ff79941e4fc9ac33b2f70077a79c552b4ebc97a4321ae66e09",
    "v": true
  },
  {
    "public_key":
        "aaa6eebac75c052fdf2abbe18e4718c3b388ff919bf4a514ab61bcac661b4409",
    "hash": "3b49a4ba1b62db697c7826a66b3a24f5c00054ba8c212ddf6094654059ce973e",
    "c": "5d156005ee2588edcf470dc653a0635dbf3afc393eb2d89a75054a93b271ee02",
    "r": "e46d532ac2d65d7f661113093a68d2ce6516a5abf08231104d0fdcbe6649e80f",
    "v": true
  },
  {
    "public_key":
        "21e031f6f3d406f53e14e57741c9861ca785cc9bc6fe041aa8c2f0282e8db52f",
    "hash": "088144dfd67a5cd013db2318eadf14a2ec30f7b11f75e687c3e76aac5b0ea584",
    "c": "44c354bb8980cb86ff17758d9a834cd1f1c6b82b9de7a2d074f0ab8dd3507d22",
    "r": "1bbd53afe01180305555444a085d0b73b4353a26fa980d594ae33fa4600c120f",
    "v": false
  },
  {
    "public_key":
        "43e773d2046d30e002cc231c85057f834d508bae0ac5eae3ec581da291736efe",
    "hash": "b1930f6d59fe22b002a0a822e0ca2f3168f792e02f8be89e5d565de7a2eca4d4",
    "c": "e5c0205493e59f6a644ecd4ff30b2892b266a26f17ba9a00f604fc62f1c40d03",
    "r": "13ce08d0c303a8696bc638ee0bf6835562cfdff9086bd221c236f7441357470b",
    "v": false
  },
  {
    "public_key":
        "86fef19663f5fca7d6c425944140a2941c2f2c131cbe881868bebd1e733bc432",
    "hash": "916ceda80ef84b8538e06c5fec7f04810a960d878f31c390705c6bba01814a93",
    "c": "68fb16d0429f61bbd63ff328b4defbc7ff03b5d3d3b83618da159fe02a808f0a",
    "r": "22c86ea632e4b7b32a662e70bb7bbd8fb381fe10950c340d82ae5c0931b07a06",
    "v": true
  },
  {
    "public_key":
        "9078fa24f1b212816e0c9f483db8004d2a6f6d267b441292218392c5d033b01a",
    "hash": "9f2ca44de5b87bb7d90cf57dedf6c5e6a232372b28e9542be6cd6943e69984ca",
    "c": "6bd88d6d4b2a2e16e823241fea53e2d50625506b89b1067b9aa038f8d55f480f",
    "r": "f018813c937ad2a7a09162b7538e179785b9c40ed6f4367b30cf7d76d076960e",
    "v": false
  },
  {
    "public_key":
        "30c16767c8353a7e7dd0a3ca1449a0cd3756135970333f0c96e7e6b151e00f54",
    "hash": "c16ea334df0501f4fa8e6d31fc733cd9728128759d77a94ce662f343fd2b4b45",
    "c": "548167935d72bbd001a9d8ffb805d3ef661453e4d39fece6b131acbfa3c1bb0d",
    "r": "f10c0232da00ddbeb9181b55d174f3d38c423d17227e9b6265f23e33389a05b2",
    "v": false
  },
  {
    "public_key":
        "5fd4c73fd1f146f41e16276ea18919b7babecb5928a06acee7e24c006cc2417f",
    "hash": "7a94605c0d43ec0f35eac8963231dc1c08b972045007d3d6c3905e142b3e2829",
    "c": "1d6c46b9de850979c7a7bfb5304072c3c778027801a5dccf19d78bbd5741ff02",
    "r": "b743f1d88f7bc3e9b32a054f6e5c3334d456a69b5a943bb9e52f046748e1d0b5",
    "v": false
  },
  {
    "public_key":
        "b1e869915645764bd9a15ad6674cf11be4371903cb6a63c412c1379384938045",
    "hash": "9343ac2dd894b368e76537fb7fa61672b6f2d00d7393cd4ab725218f59dbebeb",
    "c": "c0d2b432ab43a41c03d923227f7e5fa6367cad41bb34c3408d42bfe2a6018407",
    "r": "c3bb22aff17b69dc4cbb95fc0743bd774ca7a889f72b911418c38e8a9d9bef0e",
    "v": true
  },
  {
    "public_key":
        "076daae7755177728b0e21499d3520b86777e53113547091ccda04528a4e8cc9",
    "hash": "70cbcab50667a8840352d1a38e9871a517d142da5174e84423e55e0dbc7ab634",
    "c": "9943b01dd217dcf746ceb09647807001de56542936169240d12700451e309e0f",
    "r": "f1193f04ce3848b92bbca3d306f9ca9c84a0bd4dd7342aa68bb94712a87c2b0a",
    "v": true
  },
  {
    "public_key":
        "f45f889e87b9cdd172424336880a16fc99e8a72e5a68b19d503416d276aedeac",
    "hash": "c620fdeda0c01518fbf903bfdab96296b6d68a6e54f77349de9dd0a89b8f2dab",
    "c": "973aa8034a1995ffa58819a4856dc851f4625bfe1b583c1e06fb6295f1d36001",
    "r": "ee5d974a06316274e3af8db48b79ad03adc6f822ffb695436fa7ac274c2c268d",
    "v": false
  },
  {
    "public_key":
        "1e5ddaa318b8f3bb6e1d3211f3fdf3844deb3433e7a58ca81c4c494dfde87745",
    "hash": "883f1ae53940841369bc477089d27c369b2771200c36afc80a1e862be23218c5",
    "c": "42be7f838c60b965abfc3ba5b5fa849d5a73fbc9d907d440431265a07ac00d74",
    "r": "c89b3d4dc3a5d1330f87a894df74a0bb084200ebe8fb78a5443938d7e3b0b70b",
    "v": false
  },
  {
    "public_key":
        "e331c38217bec0115ad936c96efb5228d0e26c8e2104b4695f6e566f81e5fec7",
    "hash": "086b76c066b5d34b4062a2058591a193680f8269a68b2f75611d9420002c0659",
    "c": "e073048df4f0eecff9a5c9219c1eb64557ca16bc0e45038d08b94e7fbc185a12",
    "r": "63842d2665209ec99fd948799d45e1ad569637a88a0bc0eed31829393ee73713",
    "v": false
  },
  {
    "public_key":
        "933b2ea675a4fc4cea830daad6b25053f2e766fb12bf4d16a22146405b0cf7c8",
    "hash": "32738c9f04e480f9a8f3d1a37c1733558cfa23c833247030b74f1a9126d6cbfa",
    "c": "3d47f7d43de5cda1b762ba108687885cc4c19510bc924aa6180a3d33d570e2ed",
    "r": "c430d9afda75fd07bd1a3325698a36b3cac3bf85b61ac5c3667b5c9e5ee8a708",
    "v": false
  },
  {
    "public_key":
        "7c67e16e80f007bc9723135cc3d0283920943a1faee59f84c19e10f82c799426",
    "hash": "afda9dd111f115f0358a17fbdadd526398ae14d845e3670db7537bd06e1b4f04",
    "c": "3df1783d5419fd49279a99128959a7490cada9403aab910a51d5e9deb4ede202",
    "r": "f04881770a6deb7e01ef223d9358ff0b4cd519f0b7ed2549643945c95af06cec",
    "v": false
  },
  {
    "public_key":
        "ea47eb53b525f087b830ba9a6f053f223f97cd914d711d1d8987592997db5dd9",
    "hash": "d247d2c85ed257022ec9b0c152d4c2c40e80f2637667ee93245b417fc3f65332",
    "c": "ea792a023be8c1884ef85aa47212cd92cd2aec696b910e039095a845a7941f0b",
    "r": "1f19c23ec412fb6b003578beb4a18560619bdfed401762fa4473a6fa61658503",
    "v": true
  },
  {
    "public_key":
        "110e566bbad531298eb9da49615a5ec08acaa5779f7ee71c39f04cc2ecedc7b7",
    "hash": "f4d765776aeae815d6f079033c69b1b7e65376471b8e530825295f6f1cbd4a32",
    "c": "65b3c6794184a3d826d3ac155a9d87d648a5de48b7a31246007dc226b04d210e",
    "r": "03c02d590af27d03975a796119ec87e9b9a9cb7128df16eff175816fed2ce030",
    "v": false
  },
  {
    "public_key":
        "d2fcd90cb246e55a86ef47a0bcc49ff902c0e45a2909cdb33065b4ba21e33014",
    "hash": "08f24fe3b0dab6cddf18ea6c763c5c667d57733f32081b7cce88933c6dbd90ac",
    "c": "2b76f7b81cc72fb56bf780002d48fb4a1a7005fe5b5ac26d2fd82a444b59fe05",
    "r": "b2d25d914550e6b9dbd0e4a5b57f54ffc22405907318f6f5f2f84a0f00b0ab0b",
    "v": false
  },
  {
    "public_key":
        "4e8f90cf5671b17d97b479c5ee29cd6f2f0fadbb22f8316b0d0064401bb7857e",
    "hash": "6826599e0ad3e2c795cbea6dd30114f909b7c6b417a609439f4e1c4805ca8720",
    "c": "c6e6d48948fc3c87847ce50b3a7686dcd73b76b12e854d38ea08bb87e2c7750d",
    "r": "2372837517b621559e0a687398f67e0943f53a1c35e3b085e27bbdb178369102",
    "v": false
  },
  {
    "public_key":
        "c55021f810e1de1627dc5cdd7163a464cba3d585af7b9d47da7a1fecc151a605",
    "hash": "40b6eae8a27a184186427fbfeed196c6db18a096343d1c9bcc11484b8f461e6d",
    "c": "40803be66914719aa8a39845d6d07d8df5c8fc437882ed9d5ac377e6d1ad9704",
    "r": "3163b642df0e0436e3ff547ef00f98235d60a93b667a3068c2b3af3b98428e03",
    "v": false
  },
  {
    "public_key":
        "858ce9107c427e7071b1dcf85cf2229f6ab0b91232d9e261628bf912c4c7f7d2",
    "hash": "56a9b87d7262a77a1da9d9c5ed82062aecc2811998058ae13f071e25cc228be4",
    "c": "1243c0509ab2992c4aed96e6d566fad176bb2214c072510c2ee3e4e019f811b5",
    "r": "b66384fba19f599d62b5a5e7c72ea49f4a179d693c4193f677e13ea901592d8f",
    "v": false
  },
  {
    "public_key":
        "cbcf7456ec1c2595711dc0d0bcfdd94959485c232e6d6ec7925d648a0275ac7e",
    "hash": "281a31e5a31c962cbe6d6d5a910f1235c52af09e6448fc80a835187aa57e2671",
    "c": "9856c1e6beda57d148745ed56ca15e0791666a440b0558756b0c7a92dd0d7c03",
    "r": "2613c49ecc4ad9c0046d75558140b79c5a1829085612ff352edabd44624ffd00",
    "v": true
  },
  {
    "public_key":
        "8a083a5dca2868f66d4bfceeb9f68c69bbaafd511239a145a7e2be22e0a6b586",
    "hash": "74bead005976d8eec2d56256dc4b3165b238864aaaf1ca72fab57ae423d2a503",
    "c": "7bbf3f55491463e3171d07ee48b25ccf41ba5d52da5edeb5bc523746ead49d51",
    "r": "705c734842f56050c61af47d8f7f7cc2eb1e4df0304968b819c7aaa1efad1ed7",
    "v": false
  },
  {
    "public_key":
        "36346e83b0a875eee90d74950db9a86300afbb60424167a43bdb68550f0fe42d",
    "hash": "3e2ff76a26b0a579ff026bb251579e3d584710ab0203186ae4ff1062387633a9",
    "c": "ce0f314c9b5d62d1fd8b695ef7e721037c10b7256de02fc140fbcb0509a1596e",
    "r": "dcdd83bd4cb1fa8361508f3da83e14e3c82bb5e149b831de3314c4e4eedc1c0d",
    "v": false
  },
  {
    "public_key":
        "57134229a89e7bf2d080bda2fb5ed6615a40c78bd7d3aac0ae3a9f1b58446518",
    "hash": "1ffd81dec35e40928ebde4b2142a823350d603247be751e64802ebcc2041c7d5",
    "c": "b5661d6b8b417d1340fb57fc264258745dcf3b21e592d16716cc85502dc1c360",
    "r": "c591c4e6a48eeb51eb11727b4f7fecb4facd113d4da844b4fea3de7602dbd60f",
    "v": false
  },
  {
    "public_key":
        "b7d6c18f7eaf34345597608af769bc49aad7e67ded62584a17b8ddda9029468d",
    "hash": "cf4ee342c3da26abff8c76ff01b4e429ae83c6bf32afdab122e651f8ec3c7989",
    "c": "1b40a6415c9f069fa8ad8ce0a2dd790a2e4fe4986be657e6ca3b3f1451dd1c0d",
    "r": "c1a671042979c0100e751af063287310ffbe725e69f208b10716efa0c285790e",
    "v": true
  },
  {
    "public_key":
        "0d5c80f00872a774812269660551b34b9a902ad8ec0c1a4a5cdcf439d8f19e9d",
    "hash": "4afea1bc4b6e1d40ab5f391d2faceec9c62578d4947389dfb38fb4c8d32f7709",
    "c": "4c4addd045170d9b2c56e8b91af8b83dc1d9438829d66247292e2d27cfbb9103",
    "r": "c3dc72755ed0c55bc332eb5c6204dfc1b6b7908405108113fa5bd7ef1cbfe90f",
    "v": false
  },
  {
    "public_key":
        "8ddfabb7d342d66afb185df46728ad6fa10a90b06560e4200aa73322be129900",
    "hash": "c23af8d9cd0e8629b726eb64c6b204c7b7346630f43eb73f2197eccf7d9ef999",
    "c": "1549701f964c5a52dda3231ea573141188608ed3f8b6ac0a8191dd3ea278e20e",
    "r": "63db6dedeccc7a9f1fb3c23265ff9b0982a0458dde7306ac30fb7ed09ef3ba06",
    "v": false
  },
  {
    "public_key":
        "a6144c6a5ea2687764724f774f4f92e9ddf77e39c90f9276e8b72524cd516fca",
    "hash": "5e95efd029ec296baca1eab533f39aefccb2ea052bfc93bbcaf3e14218f984f9",
    "c": "a7307bb846e2d499a7cdb9e87626ddbfd9f23299a4a3de5eb5e018e5ce8d0e95",
    "r": "0943b5c46b3a0e222a2789183d213b95e6d5eec0781f791d305e8b8d52ef2e8c",
    "v": false
  },
  {
    "public_key":
        "1c9f0a92744c32396d2eb0f63a5654910083a1adc1bc923c0d9a5242966702a2",
    "hash": "c1ab449ffbc78e51e40e44cc63622552c7b0f11e4a3b77c06e10769e012751c9",
    "c": "b8653e2e1ecd8ccf08c6c900160516e8e477dd8829a837bdd235899f9d64ee0f",
    "r": "c717394747b96df54015e8e6fc3b59cab28c5df93d892a8ec6e2b4cec5754605",
    "v": true
  },
  {
    "public_key":
        "e645637bb3b54b018a91c37c54b376237a2b082266d63013d9cd16bca7cbc6eb",
    "hash": "2cc3692f9efffaa6788f2b528d92ef42e975a6f38cc98a074d59aaa18a9198d4",
    "c": "38b6243e5b7a82cea8d8000931cc29a5822c567324aeb10942d0336ca1a4ba76",
    "r": "37a1077434c7ede24c382f3e8329d49a985fc402efca3ffaf92ced9defb90c00",
    "v": false
  },
  {
    "public_key":
        "b27e57d32cb84f7e0964e7d8ce96eda465260678e646d58ca533e6c06dd8865a",
    "hash": "43dd81e71e8c60dccd75f0ffeab0283d77d1ab410a638620511863ff62323922",
    "c": "db9e6c7883507239a712389f0658bf5bbbc4445e6c8b2628d2fd4d2fc70fa9af",
    "r": "1f1f100c2e21a4807282d54bcfab802cf95c7b6b7c63449f27715938df637d0f",
    "v": false
  },
  {
    "public_key":
        "50f3d002d7ce36b58133ec2a37bdc10fb76ad56c70a6d61341962145bb2c4cc9",
    "hash": "2f867226a4fe1f33e7d5214b5f218b261d1de56177e5a31c367a64cf517abbf8",
    "c": "83ba8733a67dc0e84aafe1b7238995e3aa4a2cbabe01f40c77721fed32895d08",
    "r": "86a04ea2f56ad012d287639b64b68d76ccf68928c75790b60106cc6850e7b4be",
    "v": false
  }
];
