import 'package:http/http.dart' as http;
import 'package:monero_dart/src/provider/core/core.dart';
import 'package:monero_dart/src/provider/service/service.dart';

class MoneroHTTPProvider implements MoneroServiceProvider {
  MoneroHTTPProvider(this.url,
      {http.Client? client,
      this.defaultRequestTimeout = const Duration(minutes: 1)})
      : client = client ?? http.Client();

  final String url;
  final http.Client client;
  final Duration defaultRequestTimeout;
  @override
  Future<MoneroServiceResponse> post(DemonRequestDetails params,
      [Duration? timeout]) async {
    final url = params.toUrl(this.url);
    final response = await client
        .post(url,
            headers: {'Content-Type': 'application/json', ...params.header},
            body: params.body)
        .timeout(timeout ?? defaultRequestTimeout);

    return MoneroServiceResponse(
        status: response.statusCode, responseBytes: response.bodyBytes);
  }
}
