import 'dart:io';

import 'package:blockchain_utils/blockchain_utils.dart';

void main() async {
  readLine("random32_unbiased: ");
  // pritOuts();
}

void pritOuts() async {
  final index = readLine("index: ");
  final dest = readLine("dest: ");
  final mask = readLine("mask: ");
  final List<Map<String, dynamic>> outEntery = [];
  for (int i = 0; i < dest.length; i++) {
    final Map<String, dynamic> out = {
      "index": BigintUtils.parse(index[i]).toInt(),
      "dest": BytesUtils.toHexString(BytesUtils.fromHexString(dest[i])),
      "mask": BytesUtils.toHexString(BytesUtils.fromHexString(mask[i]))
    };
    outEntery.add(out);
  }
 final List<List<Map<String, dynamic>>> s = [
    outEntery.sublist(0, 16),
    outEntery.sublist(16, 32),
    outEntery.sublist(32, 48),
    outEntery.sublist(48, 64),
    outEntery.sublist(64)
  ];
  print(StringUtils.fromJson(s));

  print("len ${outEntery.length}");
}

List<String> readLine(String prefix) {
  final f = File(r"C:\in_work\monero_dart\test\file\f.txt");
  final r = f.readAsLinesSync();
  final List<String> rands = [];

  /// "random32_unbiased:"
  for (final i in r) {
    if (!i.startsWith(prefix)) continue;
    final e = i.split(prefix)[1].trim();
    // BytesUtils.fromHexString(e);
    rands.add(e);
  }
  // print("========$prefix");
  print(StringUtils.fromJson(rands));
  // print("========$prefix");
  return rands;
}
