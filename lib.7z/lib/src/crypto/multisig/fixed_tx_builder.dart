// import 'package:blockchain_utils/bip/address/xmr_addr.dart';
// import 'package:blockchain_utils/blockchain_utils.dart';
// import 'package:monero_dart/src/address/address/address.dart';
// import 'package:monero_dart/src/api/models/out.dart';
// import 'package:monero_dart/src/crypto/models/ct_key.dart';
// import 'package:monero_dart/src/crypto/ringct/bulletproofs/bulletproofs.dart';
// import 'package:monero_dart/src/crypto/ringct/bulletproofs_plus/bulletproofs_plus.dart';
// import 'package:monero_dart/src/crypto/ringct/utils/generator.dart';
// import 'package:monero_dart/src/crypto/ringct/utils/rct_crypto.dart';
// import 'package:monero_dart/src/crypto/types/types.dart';
// import 'package:monero_dart/src/exception/exception.dart';
// import 'package:monero_dart/src/helper/transaction.dart';
// import 'package:monero_dart/src/models/rtc/rct_sig_prunable.dart';
// import 'package:monero_dart/src/models/rtc/signature.dart';
// import 'package:monero_dart/src/models/test/output_info.dart';
// import 'package:monero_dart/src/models/transaction/input/input.dart';
// import 'package:monero_dart/src/models/transaction/output/output.dart';
// import 'package:monero_dart/src/models/transaction/transaction/extra.dart';
// import 'package:monero_dart/src/models/transaction/transaction/prefix.dart';
// import 'package:monero_dart/src/models/transaction/transaction/transaction.dart';

// class ComputeDestinationKeys {
//   final List<RctKey> amountKeys;
//   final List<TxExtra> extras;
//   final RctKey txPubKey;
//   final List<RctKey> additionalTxPubKey;
//   final List<RctKey> allTxKeys;
//   final List<MoneroTxout> outs;
//   ComputeDestinationKeys(
//       {required this.amountKeys,
//       required this.extras,
//       required this.txPubKey,
//       required this.additionalTxPubKey,
//       required this.outs,
//       required this.allTxKeys});
//   List<int> toExtraBytes() {
//     return MoneroTransactionHelper.toTxExtra(extras);
//   }
// }

// class ComputeSourceKeys {
//   final KeyV inputSecretKeys;
//   final List<TxinToKey> inputs;
//   const ComputeSourceKeys(
//       {required this.inputSecretKeys, required this.inputs});
// }

// class RctConfig {
//   final RangeProofType rangeProofType;
//   final RCTType type;
//   const RctConfig({required this.rangeProofType, required this.type});
//   static const RctConfig defaultConfig = RctConfig(
//       rangeProofType: RangeProofType.rangeProofPaddedBulletproof,
//       type: RCTType.rctTypeBulletproofPlus);
//   bool get isSimpleRct => rangeProofType != RangeProofType.rangeProofBorromean;
// }

// abstract class MoneroTxBuilder {
//   final ComputeSourceKeys sourceKeys;
//   final ComputeDestinationKeys destinationKeys;
//   final MoneroTransaction transaction;
//   final RctKey txKey;
//   const MoneroTxBuilder(
//       {required this.sourceKeys,
//       required this.destinationKeys,
//       required this.transaction,
//       required this.txKey});
//   static RctKey createTxSecretKeySeed({
//     required RctKey entropy,
//     required List<SourceEntry> sources,
//     String domain = "multisig_tx_privkeys_seed",
//   }) {
//     List<int> data = [
//       ...domain.codeUnits,
//       ...entropy,
//       ...sources.map((e) => e.transferTx.keyImage).expand((e) => e)
//     ];
//     return QuickCrypto.keccack256Hash(data).asImmutableBytes;
//   }

//   static List<MSecretKey> makeTxSecretKeys(
//       {required RctKey seed,
//       required int length,
//       String domain = "multisig_tx_privkeys"}) {
//     final data = [seed, QuickCrypto.keccack256Hash(domain.codeUnits)];

//     KeyV secretKeys = [];
//     for (int i = 0; i < length; i++) {
//       final hash = RCT.hashToScalarKeys(data);
//       data[1] = hash;
//       secretKeys.add(hash.asImmutableBytes);
//     }
//     return secretKeys.immutable;
//   }

//   static List<BigInt> absoluteOutputOffsetsToRelative(List<BigInt> off) {
//     List<BigInt> res = List.from(off);
//     if (res.isEmpty) {
//       return res;
//     }
//     res.sort();
//     for (int i = res.length - 1; i > 0; i--) {
//       res[i] -= res[i - 1];
//     }

//     return res;
//   }

//   static ComputeSourceKeys computeSouceKeys(
//       {required List<SourceEntry> sources}) {
//     List<TxinToKey> inputs = [];
//     for (final i in sources) {
//       final txin = TxinToKey(
//           amount: i.transferTx.outInfo.amount,
//           keyOffsets: absoluteOutputOffsetsToRelative(
//               i.outs.map((e) => e.index).toList()),
//           keyImage: i.transferTx.multisigKeyImage ?? i.transferTx.keyImage);
//       inputs.add(txin);
//     }
//     final inputSecretKeys =
//         sources.map((e) => e.transferTx.outInfo.ephemeralSecretKey).toList();
//     return ComputeSourceKeys(inputSecretKeys: inputSecretKeys, inputs: inputs);
//   }

//   static ComputeDestinationKeys computeDestinationKeys(
//       {required MoneroAccountInfo account,
//       required List<TxDestination> destinations,
//       required List<SourceEntry> sources,
//       MoneroAddress? changeAddr,
//       required RctKey txSeed}) {
//     final cl = TransactionClassifyAddresses(
//         destinations: destinations, changeAddr: changeAddr);
//     final txKeys = makeTxSecretKeys(
//         seed: txSeed,
//         length: cl.needAdditionalTxkeys ? destinations.length + 1 : 1);
//     final txKey = txKeys[0];
//     List<RctKey> amountKeys = [];
//     List<TxExtra> extras = [];
//     final unknowDsts = destinations.where((e) => e.address != changeAddr);
//     if (unknowDsts.length == 1) {
//       final dst = unknowDsts.elementAt(0);
//       List<int> paymentId = List<int>.filled(8, 0);
//       if (dst.address.type == XmrAddressType.integrated) {
//         paymentId = dst.address.cast<MoneroIntegratedAddress>().paymentId;
//       }
//       paymentId = MoneroTransactionHelper.encryptPaymentId(
//           paymentId: paymentId,
//           pubKey: unknowDsts.first.address.pubViewKey.compressed,
//           secretKey: txKey);
//       final extra = TxExtraNonce.encryptedPaymentId(paymentId);
//       extras.add(extra);
//     } else if (destinations
//         .any((e) => e.address.type == XmrAddressType.integrated)) {
//       throw MoneroCryptoException(
//           "Integrated address detected in multi-transfer transaction.");
//     }
//     RctKey txPubKey;

//     if (cl.singleDestionation != null) {
//       txPubKey = RCT.scalarmultKey_(
//           cl.singleDestionation!.pubSpendKey.compressed, txKey);
//     } else {
//       txPubKey = RCT.scalarmultBase_(txKey);
//     }
//     List<MoneroTxout> vouts = [];
//     extras.add(TxExtraPublicKey(txPubKey));
//     List<RctKey>? additionalTxSecretKeys;
//     List<RctKey> additionalTxPubKey = [];
//     if (cl.needAdditionalTxkeys) {
//       additionalTxSecretKeys = txKeys.sublist(1);
//     }
//     for (int outIndex = 0; outIndex < destinations.length; outIndex++) {
//       final dest = destinations[outIndex];
//       final key = MoneroTransactionHelper.generateOutputEpemeralKeys(
//         txSecretKey: txKey,
//         address: dest.address,
//         outIndex: outIndex,
//         changeAddr: changeAddr,
//         useViewTag: true,
//         changeAddressViewSecretKey: account.account.privateViewKey.raw,
//         txPublicKey: txPubKey,
//         additionalSecretKey: additionalTxSecretKeys?[outIndex],
//       );
//       vouts.add(MoneroTxout(amount: dest.amount, target: key.txOut));
//       amountKeys.add(key.amountKey);
//       if (additionalTxSecretKeys != null) {
//         additionalTxPubKey.add(key.additionalTxPubKey!);
//       }
//     }
//     if (additionalTxPubKey.isNotEmpty) {
//       extras.add(TxExtraAdditionalPubKeys(additionalTxPubKey));
//     }
//     return ComputeDestinationKeys(
//         amountKeys: amountKeys,
//         extras: extras,
//         txPubKey: txPubKey,
//         additionalTxPubKey: additionalTxPubKey,
//         outs: vouts,
//         allTxKeys: txKeys);
//   }
// }

// class MoneroRctTxBuilder extends MoneroTxBuilder {
//   MoneroRctTxBuilder._(
//       {required ComputeSourceKeys sourceKeys,
//       required ComputeDestinationKeys destinationKeys,
//       required MoneroTransaction transaction,
//       required RctKey txKey})
//       : super(
//             sourceKeys: sourceKeys,
//             destinationKeys: destinationKeys,
//             transaction: transaction,
//             txKey: txKey);

//   factory MoneroRctTxBuilder({
//     required MoneroAccountInfo account,
//     required List<TxDestination> destinations,
//     required List<SourceEntry> sources,
//     MoneroAddress? changeAddr,
//     bool reconstruction = false,
//   }) {
//     // sort input
//     final entropy = RCT.skGen_();
//     final seed = MoneroTxBuilder.createTxSecretKeySeed(
//         entropy: entropy, sources: sources, domain: "wallet_tx_privkeys_seed");
//     final sourceKeys = MoneroTxBuilder.computeSouceKeys(sources: sources);
//     final destinationKeys = MoneroTxBuilder.computeDestinationKeys(
//         account: account,
//         destinations: destinations,
//         sources: sources,
//         txSeed: seed);
//     final transaction = buildTx(
//         destinationKeys: destinationKeys,
//         sourceKeys: sourceKeys,
//         sources: sources);
//     return MoneroRctTxBuilder._(
//         sourceKeys: sourceKeys,
//         destinationKeys: destinationKeys,
//         transaction: transaction,
//         txKey: destinationKeys.allTxKeys.first);
//   }

//   static MoneroTransaction buildTx(
//       {required ComputeDestinationKeys destinationKeys,
//       required ComputeSourceKeys sourceKeys,
//       required List<SourceEntry> sources,
//       RctConfig config = RctConfig.defaultConfig}) {
//     bool useSimpleRCT = sourceKeys.inputs.length > 1 || config.isSimpleRct;
//     int nTotalOuts = sources[0].outs.length;
//     if (!useSimpleRCT) {
//       for (final i in sources) {
//         if (i.realOutIndex != sources[0].realOutIndex) {
//           throw MoneroCryptoException(
//               "All inputs must have the same index for non-simple ringct");
//         }
//       }
//       for (int i = 1; i < sources.length; ++i) {
//         if (nTotalOuts != sources[i].outs.length) {
//           throw MoneroCryptoException(
//               "Non-simple ringct transaction has varying ring size");
//         }
//       }
//     }
//     BigInt amountIn = BigInt.zero;
//     BigInt amountOut = BigInt.zero;
//     List<BigInt> inamounts = [], outamounts = [];
//     List<int> index = [];
//     CtKeyV inSk = [];
//     KeyV destinationsKeys = [];
//     for (final i in sources) {
//       amountIn += i.transferTx.outInfo.amount;
//       inamounts.add(i.transferTx.outInfo.amount);
//       index.add(i.realOutIndex);
//       final ctkey = CtKey(
//           dest: i.transferTx.outInfo.ephemeralSecretKey,
//           mask: i.transferTx.outInfo.mask);
//       inSk.add(ctkey);
//     }
//     for (final i in destinationKeys.outs) {
//       final pk = i.target.getPublicKey();
//       destinationsKeys.add(pk!.clone());
//       outamounts.add(i.amount);
//       amountOut += i.amount;
//     }

//     CtKeyM mixRing =
//         List.generate(useSimpleRCT ? sources.length : nTotalOuts, (i) => []);
//     if (useSimpleRCT) {
//       for (int i = 0; i < sources.length; ++i) {
//         for (int n = 0; n < sources[i].outs.length; ++n) {
//           mixRing[i].add(sources[i].outs[n].key);
//         }
//       }
//     } else {
//       for (int i = 0; i < nTotalOuts; ++i) // same index assumption
//       {
//         for (int n = 0; n < sources.length; ++n) {
//           mixRing[i][n] = sources[n].outs[i].key;
//         }
//       }
//     }
//     final BigInt fee = amountIn - amountOut;
//     if (!useSimpleRCT && fee > BigInt.zero) {
//       outamounts.add(fee);
//     }
//     // List<int> T
//     for (int i = 0; i < sourceKeys.inputs.length; ++i) {
//       if (!sources[i].transferTx.isRCT) {
//         throw MoneroCryptoException(
//             "transaction builder only work with rct");
//       }
//     }
//     final inputs =
//         sourceKeys.inputs.map((e) => e.copyWith(amount: BigInt.zero)).toList();
//     final outs = destinationKeys.outs
//         .map((e) => e.copyWith(amount: BigInt.zero))
//         .toList();
//     final extra = destinationKeys.toExtraBytes();
//     final tx = MoneroTransactionPrefix(vin: inputs, vout: outs, extra: extra);
//     final txHash = tx.getTranactionPrefixHash();
//     CtKeyV outSk = List.generate(
//         outs.length, (_) => CtKey(dest: RCT.zero(), mask: RCT.zero()));
//     final signature = RCTGeneratorUtils.genRctSimple(
//         message: txHash,
//         inSk: inSk,
//         destinations: destinationsKeys,
//         inamounts: inamounts,
//         outamounts: outamounts,
//         txnFee: fee,
//         mixRing: mixRing,
//         amountKeys: destinationKeys.amountKeys,
//         index: index,
//         outSk: outSk,
//         rangeProofType: config.rangeProofType,
//         rctType: config.type);
//     return MoneroTransaction(
//         vin: inputs, vout: outs, extra: extra, signature: signature);
//   }
// }

// class MoneroMultisTxBuilder extends MoneroTxBuilder {
//   const MoneroMultisTxBuilder._(
//       {required ComputeSourceKeys sourceKeys,
//       required ComputeDestinationKeys destinationKeys,
//       required MoneroTransaction transaction,
//       required RctKey txKey})
//       : super(
//             sourceKeys: sourceKeys,
//             destinationKeys: destinationKeys,
//             transaction: transaction,
//             txKey: txKey);

//   factory MoneroMultisTxBuilder({
//     required MoneroAccountInfo account,
//     required List<TxDestination> destinations,
//     required List<SourceEntry> sources,
//     MoneroAddress? changeAddr,
//     bool reconstruction = false,
//   }) {
//     // sort input
//     final entropy = RCT.skGen_();
//     final seed = MoneroTxBuilder.createTxSecretKeySeed(
//         entropy: entropy,
//         sources: sources,
//         domain: "multisig_tx_privkeys_seed");
//     final sourceKeys = MoneroTxBuilder.computeSouceKeys(sources: sources);
//     final destinationKeys = MoneroTxBuilder.computeDestinationKeys(
//         account: account,
//         destinations: destinations,
//         sources: sources,
//         txSeed: seed);
//     throw UnimplementedError();

//   }

//   static void buildTx({
//     required ComputeSourceKeys sourceKeys,
//     required ComputeDestinationKeys destinationsKeys,
//   }) {
//     final inputs =
//         sourceKeys.inputs.map((e) => e.copyWith(amount: BigInt.zero)).toList();
//     final outs = destinationsKeys.outs
//         .map((e) => e.copyWith(amount: BigInt.zero))
//         .toList();
//     final extra = destinationsKeys.toExtraBytes();
//     final tx = MoneroTransactionPrefix(vin: inputs, vout: outs, extra: extra);
//     final txHash = tx.getTranactionPrefixHash();
//   }

//   static makeRangeProofs({
//     required RCTType rctType,
//     required List<BigInt> outAmounts,
//     required KeyV amountMasks,
//   }) {
//     // RctSigPrunable.fromStruct(json, type)
//     switch (rctType) {
//       case RCTType.rctTypeBulletproofPlus:
//         final proofs = BulletproofsPlusGenerator.bulletproofPlusPROVEAmouts(
//             outAmounts, amountMasks);
//         return proofs;
//       case RCTType.rctTypeCLSAG:
//         final proofs = BulletproofsGenerator.bulletproofProveAmounts(
//             outAmounts, amountMasks);
//         return proofs;
//       default:
//         throw MoneroCryptoException("Unsuported multisig rct type.",
//             details: {"type": rctType.name});
//     }
//   }
// }
