import 'package:blockchain_utils/exception/exception.dart';

class MoneroMultisigAccountException extends BlockchainUtilsException {
  const MoneroMultisigAccountException(String message,
      {Map<String, dynamic>? details})
      : super(message, details: details);
}
