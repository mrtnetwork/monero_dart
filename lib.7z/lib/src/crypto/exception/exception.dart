import 'package:blockchain_utils/blockchain_utils.dart';

class MoneroCryptoException extends BlockchainUtilsException {
  const MoneroCryptoException(String message, {Map<String, dynamic>? details})
      : super(message, details: details);
}
