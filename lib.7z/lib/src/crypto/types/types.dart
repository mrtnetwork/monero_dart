import 'package:monero_dart/src/crypto/models/ct_key.dart';

typedef RctKey = List<int>;
typedef Key64 = List<List<int>>;
typedef KeyV = List<RctKey>;
typedef KeyM = List<KeyV>;
typedef CtKeyV = List<CtKey>;
typedef CtKeyM = List<CtKeyV>;
typedef Bits = List<int>;
typedef KeyImage = List<int>;
typedef MPublicKey = List<int>;
typedef MSecretKey = List<int>;
