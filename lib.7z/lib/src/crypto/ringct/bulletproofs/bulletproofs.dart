import 'dart:math';
import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:monero_dart/src/crypto/exception/exception.dart';
import 'package:monero_dart/src/models/transaction/signature/rct_prunable.dart';
import 'package:monero_dart/src/crypto/ringct/bulletproofs_plus/bulletproofs_plus.dart';
import 'package:monero_dart/src/crypto/ringct/const/const.dart';
import 'package:monero_dart/src/crypto/ringct/multiexp_data/multiexp.dart';
import 'package:monero_dart/src/crypto/models/multiexp_data.dart';
import 'package:monero_dart/src/crypto/ringct/utils/rct_crypto.dart';
import 'package:monero_dart/src/serialization/layout/constant/const.dart';
import 'package:monero_dart/src/crypto/types/types.dart';

class BulletproofsGenerator {
  static const int maxN = 64; // Example value
  static const int maxM = 16; // Example value

  static GroupElementP3 getGiP3(int index) {
    // print("called!");
    return getExponent(base: RCTConst.h, idx: index * 2 + 1);
  }

  static GroupElementP3 getHiP3(int index) {
    return getExponent(base: RCTConst.h, idx: index * 2);
  }

  static GroupElementP3 getExponent({required RctKey base, required int idx}) {
    final indexBytes = MoneroLayoutConst.varintInt().serialize(idx);
    final hash = QuickCrypto.keccack256Hash(
        [...base, ...RCTConst.bulletproofHashKey, ...indexBytes]);

    final GroupElementP3 generator = RCT.hashToP3_(hash);
    final toBytes = CryptoOps.geP3Tobytes_(generator);
    if (BytesUtils.bytesEqual(toBytes, RCT.identity(clone: false))) {
      throw const MoneroCryptoException("Exponent is point at infinity");
    }
    return generator;
  }

  static RctKey multiexp({required List<MultiexpData> data, int higiSize = 0}) {
    if (higiSize > 0) {
      if (higiSize <= 232 && data.length == higiSize) {
        return Multiexp.straus(data: data, localCache: null, step: 0);
      }
      return Multiexp.pippenger(
          data: data,
          localCache: null,
          cacheSize: higiSize,
          c: Multiexp.getPippengerC(data.length));
    }
    if (data.length <= 95) {
      return Multiexp.straus(data: data);
    }
    return Multiexp.pippenger(
        data: data,
        localCache: null,
        cacheSize: 0,
        c: Multiexp.getPippengerC(data.length));
  }

  static List<int> vectorExponent({required KeyV a, required KeyV b}) {
    if (a.length != b.length) {
      throw const MoneroCryptoException("Incompatible sizes of a and b");
    }
    if (a.length > maxN * maxM) {
      throw const MoneroCryptoException("Incompatible sizes of a and maxN");
    }
    final List<MultiexpData> multiexpData = [];
    for (int i = 0; i < a.length; i++) {
      multiexpData.add(MultiexpData(
          scalar: a[i],
          point: getGiP3(i))); // Assuming MultiexpData has a constructor
      multiexpData.add(MultiexpData(scalar: b[i], point: getHiP3(i)));
    }
    return multiexp(data: multiexpData, higiSize: a.length * 2);
  }

  static void init() {
    // print(twoN);
    // print("ip12 ${BytesUtils.bytesEqual(ip12, RCTConst.twoSixtyFourMinusOne)}");
  }

  static RctKey innerProduct({
    required KeyV a,
    required KeyV b,
  }) {
    if (a.length != b.length) {
      throw const MoneroCryptoException("Incompatible sizes of a and b");
    }
    final res = RCT.zero();
    for (int i = 0; i < a.length; ++i) {
      CryptoOps.scMulAdd(res, a[i], b[i], res);
    }
    return res;
  }

  static KeyV vectorPowers(RctKey x, int n) {
    final KeyV res = List.generate(n, (_) => RCT.zero());
    if (n == 0) {
      return res;
    }
    res[0] = RCT.identity();
    if (n == 1) return res;
    res[1] = x;
    for (int i = 2; i < n; ++i) {
      CryptoOps.scMul(res[i], res[i - 1], x);
    }
    return res;
  }

  static KeyV hadamard(KeyV a, KeyV b) {
    if (a.length != b.length) {
      throw const MoneroCryptoException("Incompatible sizes of a and b");
    }
    // CHECK_AND_ASSERT_THROW_MES(a.size() == b.size(), "Incompatible sizes of a and b");
    final KeyV res = List.generate(a.length, (_) => RCT.zero());
    for (int i = 0; i < a.length; ++i) {
      CryptoOps.scMul(res[i], a[i], b[i]);
    }
    return res;
  }

/* Compute a custom vector-scalar commitment */
  static RctKey crossVectorExponent8(
      int size,
      List<GroupElementP3> A,
      int aO,
      List<GroupElementP3> B,
      int bO,
      KeyV a,
      int ao,
      KeyV b,
      int bo,
      KeyV? scale,
      GroupElementP3? extraPoint,
      RctKey extraScalar) {
    if (size + aO > A.length) {
      throw const MoneroCryptoException("Incompatible size for A");
    }

    if (size + bO > B.length) {
      throw const MoneroCryptoException("Incompatible size for B");
    }

    if (size + ao > a.length) {
      throw const MoneroCryptoException("Incompatible size for a");
    }

    if (size + bo > b.length) {
      throw const MoneroCryptoException("Incompatible size for b");
    }

    if (size > maxN * maxM) {
      throw const MoneroCryptoException("size is too large");
    }

    if (scale != null && scale.length ~/ 2 != size) {
      throw Exception("Incompatible size for scale");
    }
    final List<MultiexpData> data = [];
    final RctKey scalar = RCT.zero();
    for (int i = 0; i < size; ++i) {
      CryptoOps.scMul(scalar, a[ao + i], RCTConst.invEight);
      data.add(MultiexpData(scalar: scalar, point: A[aO + i]));
      CryptoOps.scMul(scalar, b[bo + i], RCTConst.invEight);
      if (scale != null) CryptoOps.scMul(scalar, scalar, scale[bO + i]);
      data.add(MultiexpData(scalar: scalar, point: B[bO + i]));
    }
    if (extraPoint != null) {
      CryptoOps.scMul(scalar, extraScalar, RCTConst.invEight);
      data.add(MultiexpData(scalar: scalar, point: extraPoint));
    }
    return multiexp(data: data, higiSize: 0);
  }

  static List<GroupElementP3> hadamardFold(
      List<GroupElementP3> v, KeyV? scale, RctKey a, RctKey b) {
    if (v.length.isOdd) {
      throw const MoneroCryptoException("Vector size should be even");
    }
    final int sz = v.length ~/ 2;
    for (int n = 0; n < sz; ++n) {
      final List<List<GroupElementCached>> c = [
        GroupElementCached.dsmp,
        GroupElementCached.dsmp
      ];
      CryptoOps.geDsmPrecomp(c[0], v[n]);
      CryptoOps.geDsmPrecomp(c[1], v[sz + n]);
      RctKey sa = RCT.zero(), sb = RCT.zero();
      if (scale != null) {
        CryptoOps.scMul(sa, a, scale[n]);
      } else {
        sa = a.clone();
      }
      if (scale != null) {
        CryptoOps.scMul(sb, b, scale[sz + n]);
      } else {
        sb = b.clone();
      }
      CryptoOps.geDoubleScalarMultPrecompVartime2P3(v[n], sa, c[0], sb, c[1]);
    }
    return v.sublist(0, sz);
  }

  static Bulletproof bulletproofProve({required KeyV sv, required KeyV gamma}) {
    if (sv.length != gamma.length) {
      throw const MoneroCryptoException(
          "Incompatible sizes of sv and gamma");
    }
    if (sv.isEmpty) {
      throw const MoneroCryptoException("sv is empty");
    }
    for (final sve in sv) {
      if (!BulletproofsPlusGenerator.isReduced(sve)) {
        throw const MoneroCryptoException("Invalid sv input");
      }
    }
    for (final g in gamma) {
      if (!BulletproofsPlusGenerator.isReduced(g)) {
        throw const MoneroCryptoException("Invalid gamma input");
      }
    }
    const int logN = 6; // log2(64)
    const int N = 1 << logN;
    int M, logM;
    for (logM = 0; (M = 1 << logM) <= maxM && M < sv.length; ++logM) {}
    if (M > maxM) {
      throw const MoneroCryptoException("sv/gamma are too large");
    }
    final int logMN = logM + logN;
    final int mn = M * N;
    final KeyV V = List<List<int>>.generate(sv.length, (_) => RCT.zero());
    final KeyV aL = List<List<int>>.filled(mn, RCT.zero(clone: false));
    final KeyV aR = List<List<int>>.filled(mn, RCT.zero(clone: false));
    final KeyV aL8 = List<List<int>>.filled(mn, RCT.zero(clone: false));
    final KeyV aR8 = List<List<int>>.filled(mn, RCT.zero(clone: false));
    final RctKey tmp = RCT.zero();
    final RctKey tmp2 = RCT.zero();
    for (int i = 0; i < sv.length; ++i) {
      final RctKey gamma8 = RCT.zero();
      final RctKey sv8 = RCT.zero();

      CryptoOps.scMul(gamma8, gamma[i], RCTConst.invEight);
      CryptoOps.scMul(sv8, sv[i], RCTConst.invEight);
      RCT.addKeys2(V[i], gamma8, sv8, RCTConst.h);
    }
    for (int j = 0; j < M; ++j) {
      for (int i = N; i-- > 0;) {
        if (j < sv.length && (sv[j][i ~/ 8] & ((1) << (i % 8))) != 0) {
          aL[j * N + i] = RCT.identity(clone: false);
          aL8[j * N + i] = RCTConst.invEight;
        } else {
          aR[j * N + i] = RCTConst.minusOne;
          aR8[j * N + i] = RCTConst.minusInvEight;
        }
      }
    }

    Bulletproof tryAgain() {
      RctKey hashCash = RCT.hashToScalarKeys(V);
      final RctKey alpha = RCT.skGen_();
      RctKey ve = vectorExponent(a: aL8, b: aR8);
      CryptoOps.scMul(tmp, alpha, RCTConst.invEight);
      final A = RCT.zero();
      RCT.addKeys(A, ve, RCT.scalarmultBase_(tmp));
      final KeyV sL = RCT.skvGen(mn);
      final KeyV sR = RCT.skvGen(mn);
      final RctKey rho = RCT.skGen_();
      ve = vectorExponent(a: sL, b: sR);
      RctKey S = RCT.zero();
      RCT.addKeys(S, ve, RCT.scalarmultBase_(rho));
      S = RCT.scalarmultKey_(S, RCTConst.invEight);
      final RctKey y =
          hashCash = RCT.hashToScalarBytes([...hashCash, ...A, ...S]);

      if (BytesUtils.bytesEqual(y, RCT.zero(clone: false))) {
        return tryAgain();
      }
      final RctKey z = hashCash = RCT.hashToScalar_(y);
      if (BytesUtils.bytesEqual(z, RCT.zero(clone: false))) {
        return tryAgain();
      }
      final KeyV l0 = BulletproofsPlusGenerator.vectorSubtract(aL, z);
      final KeyV zeroTwos = List.generate(mn, (_) => RCT.zero());
      final KeyV zpow = vectorPowers(z, M + 2);
      for (int j = 0; j < M; ++j) {
        for (int i = 0; i < N; ++i) {
          if (j + 2 >= zpow.length) {
            throw const MoneroCryptoException("invalid zpow index");
          }
          if (i >= RCTConst.twoN.length) {
            throw const MoneroCryptoException("invalid twoN index");
          }
          CryptoOps.scMul(zeroTwos[j * N + i], zpow[j + 2], RCTConst.twoN[i]);
        }
      }
      KeyV r0 = BulletproofsPlusGenerator.vectorAdd(aR, z);
      final KeyV yMN = vectorPowers(y, mn);
      r0 = hadamard(r0, yMN);
      r0 = BulletproofsPlusGenerator.vectorAddComponentwise(r0, zeroTwos);
      final KeyV r1 = hadamard(yMN, sR);

      // Polynomial construction before PAPER LINE 51
      final RctKey t1_1 = innerProduct(a: l0, b: r1);
      final RctKey t1_2 = innerProduct(a: sL, b: r0);
      final RctKey t1 = RCT.zero();
      CryptoOps.scAdd(t1, t1_1, t1_2);
      final RctKey t2 = innerProduct(a: sL, b: r1);
      // PAPER LINES 52-53
      final RctKey tau1 = RCT.skGen_(), tau2 = RCT.skGen_();

      final RctKey tt1 = RCT.zero(), tt2 = RCT.zero();
      final GroupElementP3 p3 = GroupElementP3();
      CryptoOps.scMul(tmp, t1, RCTConst.invEight);
      CryptoOps.scMul(tmp2, tau1, RCTConst.invEight);
      CryptoOps.geDoubleScalarMultBaseVartimeP3(p3, tmp, RCTConst.geP3H, tmp2);
      CryptoOps.geP3Tobytes(tt1, p3);
      CryptoOps.scMul(tmp, t2, RCTConst.invEight);
      CryptoOps.scMul(tmp2, tau2, RCTConst.invEight);
      CryptoOps.geDoubleScalarMultBaseVartimeP3(p3, tmp, RCTConst.geP3H, tmp2);
      CryptoOps.geP3Tobytes(tt2, p3);
      // PAPER LINES 54-56
      final RctKey x =
          hashCash = RCT.hashToScalarBytes([...hashCash, ...z, ...tt1, ...tt2]);
      if (BytesUtils.bytesEqual(x, RCT.zero(clone: false))) {
        return tryAgain();
      }
      final RctKey taux = RCT.zero();
      CryptoOps.scMul(taux, tau1, x);
      final RctKey xsq = RCT.zero();
      CryptoOps.scMul(xsq, x, x);
      CryptoOps.scMulAdd(taux, tau2, xsq, taux);
      for (int j = 1; j <= sv.length; ++j) {
        if (j + 1 >= zpow.length) {
          throw const MoneroCryptoException("invalid zpow index");
        }
        CryptoOps.scMulAdd(taux, zpow[j + 1], gamma[j - 1], taux);
      }
      final RctKey mu = RCT.zero();
      CryptoOps.scMulAdd(mu, x, rho, alpha);
      // PAPER LINES 58-60
      // KeyV l = l0.map((e) => e.clone()).toList();
      final KeyV l = BulletproofsPlusGenerator.vectorAddComponentwise(
          l0, BulletproofsPlusGenerator.vectorScalar(sL, x));
      // KeyV r = r0.map((e) => e.clone()).toList();

      final KeyV r = BulletproofsPlusGenerator.vectorAddComponentwise(
          r0, BulletproofsPlusGenerator.vectorScalar(r1, x));
      final RctKey t = innerProduct(a: l, b: r);
      // PAPER LINE 6

      final RctKey xIP = hashCash =
          RCT.hashToScalarBytes([...hashCash, ...x, ...taux, ...mu, ...t]);

      if (BytesUtils.bytesEqual(xIP, RCT.zero(clone: false))) {
        return tryAgain();
      }
      int nprime = mn;
      List<GroupElementP3> gPrime = List.generate(mn, (_) => GroupElementP3());
      List<GroupElementP3> hPrime = List.generate(mn, (_) => GroupElementP3());
      KeyV aprime = List.generate(mn, (_) => RCT.zero());
      KeyV bprime = List.generate(mn, (_) => RCT.zero());
      final RctKey yinv = BulletproofsPlusGenerator.invert(y);
      final KeyV yinvpow = List.generate(mn, (_) => RCT.zero());

      yinvpow[0] = RCT.identity();
      yinvpow[1] = yinv;
      for (int i = 0; i < mn; ++i) {
        gPrime[i] = getGiP3(i);
        hPrime[i] = getHiP3(i);
        if (i > 1) CryptoOps.scMul(yinvpow[i], yinvpow[i - 1], yinv);
        aprime[i] = l[i].clone();
        bprime[i] = r[i].clone();
      }
      final KeyV L = List.generate(logMN, (_) => RCT.zero());
      final KeyV R = List.generate(logMN, (_) => RCT.zero());
      int round = 0;
      final KeyV w = List.generate(logMN, (_) => RCT.zero());
      KeyV? scale = yinvpow;
      while (nprime > 1) {
        // PAPER LINE 20
        nprime ~/= 2;

        final RctKey cL = innerProduct(
            a: aprime.sublist(0, nprime), b: bprime.sublist(nprime));
        final RctKey cR = innerProduct(
            a: aprime.sublist(nprime), b: bprime.sublist(0, nprime));
        CryptoOps.scMul(tmp, cL, xIP);
        L[round] = crossVectorExponent8(nprime, gPrime, nprime, hPrime, 0,
            aprime, 0, bprime, nprime, scale, RCTConst.geP3H, tmp);
        CryptoOps.scMul(tmp, cR, xIP);
        R[round] = crossVectorExponent8(nprime, gPrime, 0, hPrime, nprime,
            aprime, nprime, bprime, 0, scale, RCTConst.geP3H, tmp);
        w[round] = hashCash =
            RCT.hashToScalarBytes([...hashCash, ...L[round], ...R[round]]);

        if (BytesUtils.bytesEqual(w[round], RCT.zero(clone: false))) {
          return tryAgain();
        }
        final RctKey winv = BulletproofsPlusGenerator.invert(w[round]);
        if (nprime > 1) {
          // PERF_TIMER_START_BP(PROVE_hadamard2);
          gPrime = hadamardFold(gPrime, null, winv, w[round]);
          hPrime = hadamardFold(hPrime, scale, w[round], winv);
        }
        aprime = BulletproofsPlusGenerator.vectorAddComponentwise(
            BulletproofsPlusGenerator.vectorScalar(
                aprime.sublist(0, nprime), w[round]),
            BulletproofsPlusGenerator.vectorScalar(
                aprime.sublist(nprime), winv));
        bprime = BulletproofsPlusGenerator.vectorAddComponentwise(
            BulletproofsPlusGenerator.vectorScalar(
                bprime.sublist(0, nprime), winv),
            BulletproofsPlusGenerator.vectorScalar(
                bprime.sublist(nprime), w[round]));
        scale = null;
        ++round;
      }
      return Bulletproof(
          a: A,
          s: S,
          v: V,
          t1: tt1,
          t2: tt2,
          taux: taux,
          mu: mu,
          l: L,
          r: R,
          a_: aprime[0],
          b: bprime[0],
          t: t);
    }

    return tryAgain();
  }

  static RctKey vectorPowerSum(RctKey x, int n) {
    if (n == 0) {
      return RCT.zero();
    }

    final RctKey res = RCT.identity();
    if (n == 1) {
      return res;
    }

    final bool isPowerOf2 = (n & (n - 1)) == 0;
    if (isPowerOf2) {
      CryptoOps.scAdd(res, res, x);
      while (n > 2) {
        CryptoOps.scMul(x, x, x);
        CryptoOps.scMulAdd(res, x, res, res);
        n ~/= 2;
      }
    } else {
      final RctKey prev = x.clone();
      for (int i = 1; i < n; ++i) {
        if (i > 1) CryptoOps.scMul(prev, prev, x);
        CryptoOps.scAdd(res, res, prev);
      }
    }
    return res;
  }

  static Bulletproof bulletproofProveAmounts(List<BigInt> v, KeyV gamma) {
    if (v.length != gamma.length) {
      throw const MoneroCryptoException(
          "Incompatible sizes of v and gamma");
    }

    final KeyV sv = List.generate(v.length, (i) => RCT.d2h(v[i]));
    return bulletproofProve(sv: sv, gamma: gamma);
  }

  static bool bulletproofVerify(List<Bulletproof> proofs) {
    const int logN = 6;
    const int N = 1 << logN;

    // sanity and figure out which proof is longest
    int maxLength = 0;
    final List<_BpProofData> proofData = [];
    int invOffset = 0;
    List<RctKey> toInvert = [];
    int maxLogM = 0;
    for (final proof in proofs) {
      if (!BulletproofsPlusGenerator.isReduced(proof.taux)) {
        throw const MoneroCryptoException(
            "Input scalar not in range for taux");
      }

      if (!BulletproofsPlusGenerator.isReduced(proof.mu)) {
        throw const MoneroCryptoException(
            "Input scalar not in range for mu");
      }
      if (!BulletproofsPlusGenerator.isReduced(proof.a_)) {
        throw const MoneroCryptoException(
            "Input scalar not in range for a");
      }

      if (!BulletproofsPlusGenerator.isReduced(proof.b)) {
        throw const MoneroCryptoException(
            "Input scalar not in range for b");
      }

      if (!BulletproofsPlusGenerator.isReduced(proof.t)) {
        throw const MoneroCryptoException(
            "Input scalar not in range for t");
      }

      if (proof.v.isEmpty) {
        throw const MoneroCryptoException(
            "V does not have at least one element");
      }

      if (proof.l.length != proof.r.length) {
        throw const MoneroCryptoException("Mismatched L and R sizes");
      }

      if (proof.l.isEmpty) {
        throw const MoneroCryptoException("Empty proof");
      }
      maxLength = max(maxLength, proof.l.length);

      RctKey hashCache = RCT.hashToScalarKeys(proof.v);

      final RctKey y = hashCache =
          RCT.hashToScalarBytes([...hashCache, ...proof.a, ...proof.s]);
      if (BytesUtils.bytesEqual(y, RCT.zero(clone: false))) {
        throw const MoneroCryptoException("y == 0");
      }
      final RctKey z = hashCache = RCT.hashToScalar_(y);
      if (BytesUtils.bytesEqual(z, RCT.zero(clone: false))) {
        throw const MoneroCryptoException("z == 0");
      }
      final RctKey x = hashCache =
          RCT.hashToScalarBytes([...hashCache, ...z, ...proof.t1, ...proof.t2]);
      if (BytesUtils.bytesEqual(x, RCT.zero(clone: false))) {
        throw const MoneroCryptoException("x == 0");
      }
      final RctKey xIp = hashCache = RCT.hashToScalarBytes(
          [...hashCache, ...x, ...proof.taux, ...proof.mu, ...proof.t]);

      if (BytesUtils.bytesEqual(x, RCT.zero(clone: false))) {
        throw const MoneroCryptoException("x == 0");
      }
      int M;
      int logM = 0;
      for (logM = 0; (M = 1 << logM) <= maxM && M < proof.v.length; ++logM) {}
      if (6 + logM != proof.l.length) {
        throw const MoneroCryptoException("Proof is not the expected size");
      }
      maxLogM = max(logM, maxLogM);
      final int rounds = logM + logN;
      final List<RctKey> w = List<RctKey>.generate(rounds, (_) => RCT.zero());
      for (int i = 0; i < rounds; ++i) {
        w[i] = hashCache =
            RCT.hashToScalarBytes([...hashCache, ...proof.l[i], ...proof.r[i]]);
        if (BytesUtils.bytesEqual(w[i], RCT.zero(clone: false))) {
          throw const MoneroCryptoException("w[i] == 0");
        }
      }
      for (int i = 0; i < rounds; ++i) {
        toInvert.add(w[i]);
      }
      toInvert.add(y);
      proofData.add(_BpProofData(
          x: x, y: y, z: z, xIp: xIp, w: w, logM: logM, invOffset: invOffset));
      invOffset += rounds + 1;
    }
    if (maxLength >= 32) {
      throw const MoneroCryptoException("At least one proof is too large");
    }
    final int maxMN = 1 << maxLength;

    final RctKey tmp = RCT.zero();
    List<MultiexpData> data = [];
    toInvert = BulletproofsPlusGenerator.invertBatch(toInvert);
    final RctKey z1 = RCT.zero();
    final RctKey z3 = RCT.zero();
    final KeyV m24 = List.generate(maxMN, (_) => RCT.zero());
    final KeyV mZ5 = List.generate(maxMN, (_) => RCT.zero());
    final RctKey mY0 = RCT.zero();
    final RctKey y1 = RCT.zero();
    KeyV wCache = [];
    List<GroupElementP3> proof8V = [];
    List<GroupElementP3> proof8L = [];
    List<GroupElementP3> proof8R = [];
    for (int j = 0; j < proofs.length; j++) {
      proof8V.clear();
      proof8L.clear();
      proof8R.clear();
      final proof = proofs[j];
      final pd = proofData[j];
      final int M = 1 << pd.logM;
      final int mn = M * N;
      final RctKey weightY = RCT.skGen_();
      final RctKey weightZ = RCT.skGen_();
      proof8V = List.generate(proof.v.length, (_) => GroupElementP3());
      proof8L = List.generate(proof.l.length, (_) => GroupElementP3());
      proof8R = List.generate(proof.r.length, (_) => GroupElementP3());
      for (int i = 0; i < proof.v.length; ++i) {
        RCT.scalarmult8(proof8V[i], proof.v[i]);
      }
      for (int i = 0; i < proof.l.length; ++i) {
        RCT.scalarmult8(proof8L[i], proof.l[i]);
      }
      for (int i = 0; i < proof.r.length; ++i) {
        RCT.scalarmult8(proof8R[i], proof.r[i]);
      }
      final GroupElementP3 proof8T1 = GroupElementP3();
      final GroupElementP3 proof8T2 = GroupElementP3();
      final GroupElementP3 proof8S = GroupElementP3();
      final GroupElementP3 proof8A = GroupElementP3();
      RCT.scalarmult8(proof8T1, proof.t1);
      RCT.scalarmult8(proof8T2, proof.t2);
      RCT.scalarmult8(proof8S, proof.s);
      RCT.scalarmult8(proof8A, proof.a);
      CryptoOps.scMulSub(mY0, proof.taux, weightY, mY0);
      final KeyV zpow = vectorPowers(pd.z, M + 3);
      final RctKey k = RCT.zero();
      final RctKey ip1y = vectorPowerSum(pd.y.clone(), mn);
      CryptoOps.scMulSub(k, zpow[2], ip1y, RCT.zero(clone: false));
      for (int j = 1; j <= M; ++j) {
        if (j + 2 >= zpow.length) {
          throw const MoneroCryptoException("invalid zpow index");
        }
        CryptoOps.scMulSub(k, zpow[j + 2], RCTConst.twoSixtyFourMinusOne, k);
      }
      CryptoOps.scMulAdd(tmp, pd.z, ip1y, k);
      CryptoOps.scSub(tmp, proof.t, tmp);
      CryptoOps.scMulAdd(y1, tmp, weightY, y1);
      for (int j = 0; j < proof8V.length; j++) {
        CryptoOps.scMul(tmp, zpow[j + 2], weightY);
        data.add(MultiexpData(scalar: tmp, point: proof8V[j]));
      }
      CryptoOps.scMul(tmp, pd.x, weightY);
      data.add(MultiexpData(scalar: tmp, point: proof8T1));
      final RctKey xsq = RCT.zero();
      CryptoOps.scMul(xsq, pd.x, pd.x);
      CryptoOps.scMul(tmp, xsq, weightY);
      data.add(MultiexpData(scalar: tmp, point: proof8T2));

      data.add(MultiexpData(scalar: weightZ, point: proof8A));
      CryptoOps.scMul(tmp, pd.x, weightZ);
      data.add(MultiexpData(scalar: tmp, point: proof8S));
      final int rounds = pd.logM + logN;
      RctKey yinvpow = RCT.identity();
      RctKey ypow = RCT.identity();

      final List<RctKey> winv = toInvert.sublist(pd.invOffset);
      final RctKey yinv = toInvert[pd.invOffset + rounds];
      wCache = List.generate(1 << rounds, (_) => RCT.zero());
      wCache[0] = winv[0].clone();
      wCache[1] = pd.w[0].clone();
      for (int j = 1; j < rounds; ++j) {
        final int slots = 1 << (j + 1);
        for (int s = slots; s-- > 0; --s) {
          CryptoOps.scMul(wCache[s], wCache[s ~/ 2], pd.w[j]);
          CryptoOps.scMul(wCache[s - 1], wCache[s ~/ 2], winv[j]);
        }
      }
      for (int i = 0; i < mn; ++i) {
        final RctKey gSc = proof.a_.clone();
        RctKey hSc = RCT.zero();
        if (i == 0) {
          hSc = proof.b.clone();
        } else {
          CryptoOps.scMul(hSc, proof.b, yinvpow);
        }

        // Convert the index to binary IN REVERSE and construct the scalar exponent
        CryptoOps.scMul(gSc, gSc, wCache[i]);
        CryptoOps.scMul(hSc, hSc, wCache[(~i) & (mn - 1)]);

        CryptoOps.scAdd(gSc, gSc, pd.z);
        if (2 + i ~/ N >= zpow.length) {
          throw const MoneroCryptoException("invalid zpow index");
        }
        if (i ~/ N >= RCTConst.twoN.length) {
          throw const MoneroCryptoException("invalid twoN index");
        }
        CryptoOps.scMul(tmp, zpow[2 + i ~/ N], RCTConst.twoN[i % N]);
        if (i == 0) {
          CryptoOps.scAdd(tmp, tmp, pd.z);
          CryptoOps.scSub(hSc, hSc, tmp);
        } else {
          CryptoOps.scMulAdd(tmp, pd.z, ypow, tmp);
          CryptoOps.scMulSub(hSc, tmp, yinvpow, hSc);
        }

        CryptoOps.scMulSub(m24[i], gSc, weightZ, m24[i]);
        CryptoOps.scMulSub(mZ5[i], hSc, weightZ, mZ5[i]);
        if (i == 0) {
          yinvpow = yinv.clone();
          ypow = pd.y.clone();
        } else if (i != mn - 1) {
          CryptoOps.scMul(yinvpow, yinvpow, yinv);
          CryptoOps.scMul(ypow, ypow, pd.y);
        }
      }

      CryptoOps.scMulAdd(z1, proof.mu, weightZ, z1);
      for (int i = 0; i < rounds; ++i) {
        CryptoOps.scMul(tmp, pd.w[i], pd.w[i]);
        CryptoOps.scMul(tmp, tmp, weightZ);
        data.add(MultiexpData(scalar: tmp, point: proof8L[i]));
        CryptoOps.scMul(tmp, winv[i], winv[i]);
        CryptoOps.scMul(tmp, tmp, weightZ);
        data.add(MultiexpData(scalar: tmp, point: proof8R[i]));
      }
      CryptoOps.scMulSub(tmp, proof.a_, proof.b, proof.t);
      CryptoOps.scMul(tmp, tmp, pd.xIp);
      CryptoOps.scMulAdd(z3, tmp, weightZ, z3);
    }
    CryptoOps.scSub(tmp, mY0, z1);
    data.add(MultiexpData(
        scalar: tmp, point: CryptoOps.geFromBytesVartime(RCTConst.g)));
    CryptoOps.scSub(tmp, z3, y1);
    data.add(MultiexpData(
        scalar: tmp, point: CryptoOps.geFromBytesVartime(RCTConst.h)));
    final List<MultiexpData?> nd = List.filled(2 * maxMN, null);
    for (int i = 0; i < maxMN; ++i) {
      nd[i * 2] = MultiexpData(scalar: m24[i], point: getGiP3(i));
      nd[i * 2 + 1] = MultiexpData(scalar: mZ5[i], point: getHiP3(i));
    }
    data = [...nd.cast(), ...data];
    final mp = multiexp(data: data, higiSize: 2 * maxMN);
    if (BytesUtils.bytesEqual(mp, RCT.identity(clone: false))) {
      return true;
    }
    return false;
  }
}

class _BpProofData {
  final RctKey x;
  final RctKey y;
  final RctKey z;
  final RctKey xIp;
  final List<RctKey> w;
  final int logM;
  final int invOffset;
  _BpProofData(
      {required RctKey x,
      required RctKey y,
      required RctKey z,
      required RctKey xIp,
      required List<RctKey> w,
      required this.logM,
      required this.invOffset})
      : x = x.asImmutableBytes,
        y = y.asImmutableBytes,
        z = z.asImmutableBytes,
        xIp = xIp.asImmutableBytes,
        w = w.map((e) => e.asImmutableBytes).toList().immutable;
}
