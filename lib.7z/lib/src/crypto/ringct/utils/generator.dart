import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:monero_dart/src/crypto/exception/exception.dart';
import 'package:monero_dart/src/crypto/ringct/clsag/clsag.dart';
import 'package:monero_dart/src/crypto/ringct/const/const.dart';
import 'package:monero_dart/src/exception/exception.dart';
import 'package:monero_dart/src/models/transaction/signature/rct_prunable.dart';
import 'package:monero_dart/src/models/transaction/signature/signature.dart';
import 'package:monero_dart/src/crypto/ringct/borosig/borosig.dart';
import 'package:monero_dart/src/crypto/ringct/bulletproofs/bulletproofs.dart';
import 'package:monero_dart/src/crypto/ringct/bulletproofs_plus/bulletproofs_plus.dart';
import 'package:monero_dart/src/crypto/ringct/mlsag/mlsag.dart';
import 'package:monero_dart/src/crypto/models/ct_key.dart';
import 'package:monero_dart/src/crypto/ringct/utils/rct_crypto.dart';
import 'package:monero_dart/src/crypto/types/types.dart';
import 'package:monero_dart/src/network/config.dart';

enum RangeProofType {
  rangeProofBorromean,
  rangeProofBulletproof,
  rangeProofMultiOutputBulletproof,
  rangeProofPaddedBulletproof
}

class RCTGeneratorUtils {
  static const int maxOuts = 16;
  static CtKey _generateRandomKey() {
    final mask = RCT.pkGen();
    final dest = RCT.pkGen();
    return CtKey(mask: mask, dest: dest);
  }

  static Tuple<CtKeyM, int> _generateKey(CtKeyV inPk, int mixin) {
    final int rows = inPk.length;
    final CtKeyM rv = List.generate(mixin + 1, (_) => inPk.clone());
    final int index = RCT.randXmrAmount(BigInt.from(mixin)).toInt();
    int i = 0, j = 0;
    for (i = 0; i <= mixin; i++) {
      if (i != index) {
        for (j = 0; j < rows; j++) {
          rv[i][j] = _generateRandomKey();
        }
      }
    }

    return Tuple(rv, index);
  }

  static bool verRct(RCTSignature signature, {bool? semantics}) {
    if (signature.signature.type != RCTType.rctTypeFull) {
      throw const MoneroCryptoException(
          "verRct only verified RCTFull signature.");
    }
    if (signature.rctSigPrunable == null) {
      throw const MoneroCryptoException(
          "SigPrunable required for verification.");
    }
    final sig = signature.signature.cast<RCTFull>();
    final prunableFull =
        signature.rctSigPrunable!.cast<RctSigPrunableRangeSigs>();
    if (semantics == true) {
      if (sig.outPk.length != prunableFull.rangeSig.length) {
        throw Exception("Mismatched sizes of outPk and rv.p.rangeSigs");
      }
      if (sig.outPk.length != sig.ecdhInfo.length) {
        throw Exception("Mismatched sizes of outPk and rv.ecdhInfo");
      }
      if (prunableFull.mgs.length != 1) {
        throw Exception("full rctSig has not one MG");
      }
    }

    bool vrifySemantics() {
      for (int i = 0; i < sig.outPk.length; i++) {
        final verify = BoroSigUtils.verifyRange(
            sig.outPk[i].mask, prunableFull.rangeSig[i]);
        if (!verify) return false;
      }
      return true;
    }

    bool verify() {
      if ((sig.mixRing?.isEmpty ?? true) || sig.message == null) {
        throw const MoneroCryptoException(
            "mixRing and message required for verification.");
      }
      final txnFeeKey = RCT.scalarmultH(RCT.d2h(sig.txnFee));
      final m = MLSAGUtils.getPreMlsagHash(signature);
      return MLSAGUtils.verRctMG(
          prunableFull.mgs[0], sig.mixRing!, sig.outPk, txnFeeKey, m);
    }

    if (semantics == true) return vrifySemantics();
    if (semantics == false) return verify();
    return vrifySemantics() && verify();
  }

  static RCTSignature genRct(
      RctKey message,
      CtKeyV inSk,
      KeyV destinations,
      List<BigInt> amounts,
      CtKeyM mixRing,
      KeyV amountKeys,
      int index,
      KeyV outSk) {
    if (!(amounts.length == destinations.length ||
        amounts.length == destinations.length + 1)) {
      throw const MoneroCryptoException(
          "Different number of amounts/destinations");
    }

    if (amountKeys.length != destinations.length) {
      throw const MoneroCryptoException(
          "Different number of amountKeys/destinations");
    }

    if (index >= mixRing.length) {
      throw const MoneroCryptoException("Bad index into mixRing");
    }

    for (int n = 0; n < mixRing.length; n++) {
      if (mixRing[n].length != inSk.length) {
        throw const MoneroCryptoException("Bad mixRing size");
      }
    }

    if (inSk.length >= 2) {
      throw const MoneroCryptoException("genRct is not suitable for 2+ rings");
    }
    int i = 0;
    final List<RangeSig> rangeSig = [];
    final List<CtKey> outPk = [];
    final List<EcdhInfoV1> ecdh = [];
    for (i = 0; i < destinations.length; i++) {
      final mask = RCT.zero();
      final rS = BoroSigUtils.proveRange(mask, outSk[i], amounts[i]);
      outPk.add(CtKey(dest: destinations[i].clone(), mask: mask));
      rangeSig.add(rS);
      final ecdhInfo = RCT.ecdhEncode(
          EcdhTuple(
              mask: outSk[i],
              amount: RCT.d2h(amounts[i]),
              version: EcdhInfoVersion.v1),
          amountKeys[i]);
      ecdh.add(ecdhInfo.cast());
    }
    BigInt txnFee = BigInt.zero;
    if (amounts.length > destinations.length) {
      txnFee = amounts[destinations.length];
    }
    final RctKey txnFeeKey = RCT.scalarmultH(RCT.d2h(txnFee));
    final sig = RCTFull(
        ecdhInfo: ecdh,
        txnFee: txnFee,
        outPk: outPk,
        message: message,
        mixRing: mixRing);

    final prunable = RctSigPrunableRangeSigs(rangeSig: rangeSig, mgs: []);
    final signature = RCTSignature(signature: sig, rctSigPrunable: prunable);
    final mlsagHash = MLSAGUtils.getPreMlsagHash(signature);
    final mgs = MLSAGUtils.prove(
        mlsagHash, mixRing, inSk, outSk, outPk, index, txnFeeKey);
    return RCTSignature(
        signature: sig,
        rctSigPrunable:
            RctSigPrunableRangeSigs(rangeSig: rangeSig, mgs: [mgs]));
  }

  static RCTSignature genRct_(RctKey message, CtKeyV inSk, CtKeyV inPk,
      KeyV destinations, List<BigInt> amounts, KeyV amountKeys, int mixin) {
    final mix = _generateKey(inPk, mixin);
    final KeyV outSk = List.generate(destinations.length, (_) => RCT.zero());
    return genRct(message, inSk, destinations, amounts, mix.item1, amountKeys,
        mix.item2, outSk);
  }

  static BulletproofPlus _proveRangeBulletproofPlus(
      KeyV C, KeyV masks, List<BigInt> amounts, List<RctKey> sk) {
    if (amounts.length != sk.length) {
      throw const MoneroCryptoException("Invalid amounts/sk sizes");
    }
    final proof =
        BulletproofsPlusGenerator.bulletproofPlusPROVEAmouts(amounts, masks);
    if (proof.v.length != amounts.length) {
      throw const MoneroCryptoException("V does not have the expected size");
    }
    for (int i = 0; i < proof.v.length; i++) {
      C[i] = proof.v[i].clone();
    }
    return proof;
  }

  static BulletproofPlus _fakeProveRangeBulletproofPlus(
      KeyV C, KeyV masks, List<BigInt> amounts) {
    int lR = 0;
    while ((1 << lR) < amounts.length) {
      ++lR;
    }
    lR += 6;
    for (int i = 0; i < amounts.length; ++i) {
      masks[i] = RCT.identity(clone: false);
      final RctKey sv8 = RCT.zero();
      final RctKey sv = RCT.d2h(amounts[i]);
      CryptoOps.scMul(sv8, sv, RCTConst.invEight);
      RCT.addKeys2(C[i], RCTConst.invEight, sv8, RCTConst.h);
    }
    return BulletproofPlus(
        a: RCT.identity(clone: false),
        a1: RCT.identity(clone: false),
        b: RCT.identity(clone: false),
        r1: RCT.identity(clone: false),
        s1: RCT.identity(clone: false),
        d1: RCT.identity(clone: false),
        l: List.filled(lR, RCT.identity(clone: false)),
        r: List.filled(lR, RCT.identity(clone: false)),
        v: List.filled(amounts.length, RCT.identity(clone: false)));
  }

  static Bulletproof _fakeProveRangeBulletproof(
      KeyV C, KeyV masks, List<BigInt> amounts) {
    int lR = 0;
    while ((1 << lR) < amounts.length) {
      ++lR;
    }
    lR += 6;
    for (int i = 0; i < amounts.length; ++i) {
      masks[i] = RCT.identity();
      final RctKey sv8 = RCT.zero();
      final RctKey sv = RCT.d2h(amounts[i]);
      CryptoOps.scMul(sv8, sv, RCTConst.invEight);
      RCT.addKeys2(C[i], RCTConst.invEight, sv8, RCTConst.h);
    }
    return Bulletproof(
        a: RCT.identity(clone: false),
        a_: RCT.identity(clone: false),
        b: RCT.identity(clone: false),
        mu: RCT.identity(clone: false),
        s: RCT.identity(clone: false),
        t: RCT.identity(clone: false),
        t1: RCT.identity(clone: false),
        t2: RCT.identity(clone: false),
        taux: RCT.identity(clone: false),
        l: List.filled(lR, RCT.identity(clone: false)),
        r: List.filled(lR, RCT.identity(clone: false)),
        v: List.filled(amounts.length, RCT.identity(clone: false)));
  }

  static Bulletproof _proveRangeBulletproof(
      KeyV C, KeyV masks, List<BigInt> amounts, List<RctKey> sk) {
    if (amounts.length != sk.length) {
      throw const MoneroCryptoException("Invalid amounts/sk sizes");
    }
    final Bulletproof proof =
        BulletproofsGenerator.bulletproofProveAmounts(amounts, masks);
    if (proof.v.length != amounts.length) {
      throw const MoneroCryptoException("V does not have the expected size");
    }
    for (int i = 0; i < proof.v.length; i++) {
      C[i] = proof.v[i].clone();
    }
    return proof;
  }

  static RCTSignature<S, P>
      genRctSimple<S extends RCTSignatureBase, P extends RctSigPrunable>(
          {required RctKey message,
          required CtKeyV inSk,
          required KeyV destinations,
          required List<BigInt> inamounts,
          required List<BigInt> outamounts,
          required BigInt txnFee,
          required CtKeyM mixRing,
          required KeyV amountKeys,
          required List<int> index,
          required CtKeyV outSk,
          required RangeProofType rangeProofType,
          required RCTType? rctType,
          KeyV? aResult,
          bool createLinkable = true}) {
    final bool bpOrBpp = rangeProofType != RangeProofType.rangeProofBorromean;
    if (rctType == null || rctType == RCTType.rctTypeNull) {
      if (bpOrBpp) {
        rctType = RCTType.rctTypeBulletproofPlus;
      } else {
        rctType = RCTType.rctTypeSimple;
      }
    }
    if (bpOrBpp && rctType == RCTType.rctTypeSimple) {
      throw MoneroCryptoException(
          "cannot chose `rctTypeSimple` when using ${rangeProofType.name}");
    } else if (!bpOrBpp && rctType != RCTType.rctTypeSimple) {
      throw const MoneroCryptoException(
          "rangeProofBorromean only work with `rctTypeSimple`");
    }
    if (rctType == RCTType.rctTypeFull) {
      throw const MoneroCryptoException(
          "Use `genRct` instead `genRctSimple` for RCTFULL");
    }

    if (inamounts.isEmpty) {
      throw const MoneroCryptoException("Empty inamounts");
    }

    if (inamounts.length != inSk.length) {
      throw const MoneroCryptoException("Different number of inamounts/inSk");
    }

    if (outamounts.length != destinations.length) {
      throw const MoneroCryptoException(
          "Different number of amounts/destinations");
    }

    if (amountKeys.length != destinations.length) {
      throw const MoneroCryptoException(
          "Different number of amountKeys/destinations");
    }

    if (index.length != inSk.length) {
      throw const MoneroCryptoException("Different number of index/inSk");
    }

    if (mixRing.length != inSk.length) {
      throw const MoneroCryptoException("Different number of mixRing/inSk");
    }

    for (int n = 0; n < mixRing.length; n++) {
      if (index[n] >= mixRing[n].length) {
        throw const MoneroCryptoException("Bad index into mixRing");
      }
    }
    final CtKeyV outPk = [];
    int i;
    final List<RangeSig> rangeSig = [];
    final List<BulletproofPlus> bulletProofPlus = [];
    final List<Bulletproof> bulletProof = [];
    final List<EcdhInfo> ecdh = [];
    for (i = 0; i < destinations.length; i++) {
      final mask = RCT.zero();
      final outSkMask = outSk[i].mask.clone();
      if (!bpOrBpp) {
        final s = BoroSigUtils.proveRange(mask, outSkMask, outamounts[i]);
        rangeSig.add(s);
      }
      outSk[i] = outSk[i].copyWith(mask: outSkMask);
      final CtKey pk = CtKey(dest: destinations[i].clone(), mask: mask);
      outPk.add(pk);
    }

    if (bpOrBpp) {
      final bool plus = rctType.isBulletproofPlus;
      final int nAmounts = outamounts.length;
      int amountsProved = 0;
      if (rangeProofType == RangeProofType.rangeProofPaddedBulletproof) {
        final keys = amountKeys.map((e) => e.clone()).toList();
        final KeyV masks = List.generate(
            outamounts.length, (i) => RCT.genCommitmentMask(keys[i]));
        final KeyV C = List.generate(outamounts.length, (_) => RCT.zero());
        if (plus) {
          final prove = _proveRangeBulletproofPlus(C, masks, outamounts, keys);
          bulletProofPlus.add(prove);
        } else {
          final prove = _proveRangeBulletproof(C, masks, outamounts, keys);
          bulletProof.add(prove);
        }
        for (i = 0; i < outamounts.length; ++i) {
          final mask = RCT.scalarmult8_(C[i]);
          outPk[i] = outPk[i].copyWith(mask: mask);
          outSk[i] = outSk[i].copyWith(mask: masks[i]);
        }
      } else {
        while (amountsProved < nAmounts) {
          int batchSize = 1;
          if (rangeProofType ==
              RangeProofType.rangeProofMultiOutputBulletproof) {
            while (batchSize * 2 + amountsProved <= nAmounts &&
                batchSize * 2 <= maxOuts) {
              batchSize *= 2;
            }
          }
          final List<BigInt> batchAmounts =
              List.generate(batchSize, (i) => outamounts[i + amountsProved]);
          final keys = amountKeys
              .sublist(amountsProved, amountsProved + batchSize)
              .map((e) => e.clone())
              .toList();
          final KeyV masks = List.generate(
              batchAmounts.length, (i) => RCT.genCommitmentMask(keys[i]));
          final KeyV C = List.generate(batchAmounts.length, (_) => RCT.zero());
          if (plus) {
            final prove =
                _proveRangeBulletproofPlus(C, masks, batchAmounts, keys);
            bulletProofPlus.add(prove);
          } else {
            final prove = _proveRangeBulletproof(C, masks, batchAmounts, keys);
            bulletProof.add(prove);
          }
          for (i = 0; i < batchSize; ++i) {
            outPk[i + amountsProved] =
                outPk[i + amountsProved].copyWith(mask: RCT.scalarmult8_(C[i]));
            outSk[i + amountsProved] =
                outSk[i + amountsProved].copyWith(mask: masks[i]);
          }
          amountsProved += batchSize;
        }
      }
    }
    final RctKey sumout = RCT.zero();
    for (i = 0; i < outSk.length; ++i) {
      CryptoOps.scAdd(sumout, outSk[i].mask, sumout);
      final ecdhT = EcdhTuple(
          mask: outSk[i].mask,
          amount: RCT.d2h(outamounts[i]),
          version: rctType.ecdhVersion);
      final EcdhInfo info = RCT.ecdhEncode(ecdhT, amountKeys[i]);
      ecdh.add(info);
    }
    // BigInt txFee = txnFee;
    final KeyV pseudoOuts = List.generate(inamounts.length, (_) => RCT.zero());
    final List<MgSig> mgs = [];
    final List<Clsag> clsag = [];
    final RctKey sumpouts = RCT.zero();
    final KeyV a =
        aResult ?? List.generate(inamounts.length, (_) => RCT.zero());
    if (a.length != inamounts.length) {
      throw const MoneroCryptoException("Invalid a provided.");
    }
    for (i = 0; i < inamounts.length - 1; i++) {
      RCT.skGen(a[i]);
      CryptoOps.scAdd(sumpouts, a[i], sumpouts);
      RCT.genC(pseudoOuts[i], a[i], inamounts[i]);
    }
    CryptoOps.scSub(a[i], sumout, sumpouts);
    RCT.genC(pseudoOuts[i], a[i], inamounts[i]);
    final RCTSignature<S, P> signature = buildSignature(
        type: rctType,
        ecdh: ecdh,
        txnFee: txnFee,
        outPk: outPk,
        message: message,
        mixRing: mixRing,
        rangeSig: rangeSig,
        mgs: mgs,
        bulletProofPlus: bulletProofPlus,
        bulletProof: bulletProof,
        clsag: clsag,
        pseudoOuts: pseudoOuts);
    if (!createLinkable) return signature;
    final RctKey fullMessage = MLSAGUtils.getPreMlsagHash(signature);
    for (i = 0; i < inamounts.length; i++) {
      if (rctType.isClsag) {
        final prove = CLSAGUtins.prove(
            fullMessage,
            signature.signature.mixRing![i],
            inSk[i],
            a[i],
            pseudoOuts[i],
            index[i]);
        clsag.add(prove);
      } else {
        final prove = MLSAGUtils.proveSimple(
            fullMessage,
            signature.signature.mixRing![i],
            inSk[i],
            a[i],
            pseudoOuts[i],
            index[i]);
        mgs.add(prove);
      }
    }
    return buildSignature<S, P>(
        type: rctType,
        ecdh: ecdh,
        txnFee: txnFee,
        outPk: outPk,
        message: message,
        mixRing: mixRing,
        rangeSig: rangeSig,
        mgs: mgs,
        bulletProofPlus: bulletProofPlus,
        bulletProof: bulletProof,
        clsag: clsag,
        pseudoOuts: pseudoOuts);
  }

  static RCTSignature<S, P>
      genFakeRctSimple<S extends RCTSignatureBase, P extends RctSigPrunable>(
          {required RctKey message,
          required CtKeyV inSk,
          required KeyV destinations,
          required List<BigInt> inamounts,
          required List<BigInt> outamounts,
          required BigInt txnFee,
          required CtKeyM mixRing,
          required KeyV amountKeys,
          required List<int> index,
          required CtKeyV outSk,
          required RangeProofType rangeProofType,
          required RCTType? rctType,
          KeyV? aResult,
          bool createLinkable = true}) {
    final bool bpOrBpp = rangeProofType != RangeProofType.rangeProofBorromean;
    if (rctType == null || rctType == RCTType.rctTypeNull) {
      if (bpOrBpp) {
        rctType = RCTType.rctTypeBulletproofPlus;
      } else {
        rctType = RCTType.rctTypeSimple;
      }
    }
    if (bpOrBpp && rctType == RCTType.rctTypeSimple) {
      throw MoneroCryptoException(
          "cannot chose `rctTypeSimple` when using ${rangeProofType.name}");
    } else if (!bpOrBpp && rctType != RCTType.rctTypeSimple) {
      throw const MoneroCryptoException(
          "rangeProofBorromean only work with `rctTypeSimple`");
    }
    if (rctType == RCTType.rctTypeFull) {
      throw const MoneroCryptoException(
          "Use `genRct` instead `genRctSimple` for RCTFULL");
    }

    if (inamounts.isEmpty) {
      throw const MoneroCryptoException("Empty inamounts");
    }

    if (inamounts.length != inSk.length) {
      throw const MoneroCryptoException("Different number of inamounts/inSk");
    }

    if (outamounts.length != destinations.length) {
      throw const MoneroCryptoException(
          "Different number of amounts/destinations");
    }

    if (amountKeys.length != destinations.length) {
      throw const MoneroCryptoException(
          "Different number of amountKeys/destinations");
    }

    if (index.length != inSk.length) {
      throw const MoneroCryptoException("Different number of index/inSk");
    }

    if (mixRing.length != inSk.length) {
      throw const MoneroCryptoException("Different number of mixRing/inSk");
    }

    for (int n = 0; n < mixRing.length; n++) {
      if (index[n] >= mixRing[n].length) {
        throw const MoneroCryptoException("Bad index into mixRing");
      }
    }
    final CtKeyV outPk = [];
    int i;
    final List<RangeSig> rangeSig = [];
    final List<BulletproofPlus> bulletProofPlus = [];
    final List<Bulletproof> bulletProof = [];
    final List<EcdhInfo> ecdh = [];
    for (i = 0; i < destinations.length; i++) {
      final mask = RCT.zero();
      final outSkMask = outSk[i].mask.clone();
      if (!bpOrBpp) {
        final s = BoroSigUtils.fakeProveRange();
        rangeSig.add(s);
      }
      outSk[i] = outSk[i].copyWith(mask: outSkMask);
      final CtKey pk = CtKey(dest: destinations[i].clone(), mask: mask);
      outPk.add(pk);
    }

    if (bpOrBpp) {
      final bool plus = rctType.isBulletproofPlus;
      final int nAmounts = outamounts.length;
      int amountsProved = 0;
      if (rangeProofType == RangeProofType.rangeProofPaddedBulletproof) {
        final KeyV masks = List.filled(outamounts.length, RCT.identity());
        final KeyV C = List.generate(outamounts.length, (_) => RCT.identity());
        if (plus) {
          final prove = _fakeProveRangeBulletproofPlus(C, masks, outamounts);
          bulletProofPlus.add(prove);
        } else {
          final prove = _fakeProveRangeBulletproof(C, masks, outamounts);
          bulletProof.add(prove);
        }
      } else {
        while (amountsProved < nAmounts) {
          int batchSize = 1;
          if (rangeProofType ==
              RangeProofType.rangeProofMultiOutputBulletproof) {
            while (batchSize * 2 + amountsProved <= nAmounts &&
                batchSize * 2 <= maxOuts) {
              batchSize *= 2;
            }
          }
          final List<BigInt> batchAmounts =
              List.generate(batchSize, (i) => outamounts[i + amountsProved]);
          final KeyV masks = List.filled(batchAmounts.length, RCT.identity());
          final KeyV C = List.filled(batchAmounts.length, RCT.identity());
          if (plus) {
            final prove =
                _fakeProveRangeBulletproofPlus(C, masks, batchAmounts);
            bulletProofPlus.add(prove);
          } else {
            final prove = _fakeProveRangeBulletproof(C, masks, batchAmounts);
            bulletProof.add(prove);
          }
          for (i = 0; i < batchSize; ++i) {
            outPk[i + amountsProved] =
                outPk[i + amountsProved].copyWith(mask: RCT.scalarmult8_(C[i]));
            outSk[i + amountsProved] =
                outSk[i + amountsProved].copyWith(mask: masks[i]);
          }
          amountsProved += batchSize;
        }
      }
    }
    final RctKey sumout = RCT.zero();
    for (i = 0; i < outSk.length; ++i) {
      CryptoOps.scAdd(sumout, outSk[i].mask, sumout);
      final ecdhT = EcdhTuple(
          mask: outSk[i].mask,
          amount: RCT.d2h(outamounts[i]),
          version: rctType.ecdhVersion);
      final EcdhInfo info = RCT.ecdhEncode(ecdhT, amountKeys[i]);
      ecdh.add(info);
    }
    // BigInt txFee = txnFee;
    final KeyV pseudoOuts = List.generate(inamounts.length, (_) => RCT.zero());
    final List<MgSig> mgs = [];
    final List<Clsag> clsag = [];
    final RctKey sumpouts = RCT.zero();
    final KeyV a =
        aResult ?? List.generate(inamounts.length, (_) => RCT.zero());
    if (a.length != inamounts.length) {
      throw const MoneroCryptoException("Invalid a provided.");
    }
    for (i = 0; i < inamounts.length - 1; i++) {
      RCT.skGen(a[i]);
      CryptoOps.scAdd(sumpouts, a[i], sumpouts);
      RCT.genC(pseudoOuts[i], a[i], inamounts[i]);
    }
    CryptoOps.scSub(a[i], sumout, sumpouts);
    RCT.genC(pseudoOuts[i], a[i], inamounts[i]);
    final RCTSignature<S, P> signature = buildSignature(
        type: rctType,
        ecdh: ecdh,
        txnFee: txnFee,
        outPk: outPk,
        message: message,
        mixRing: mixRing,
        rangeSig: rangeSig,
        mgs: mgs,
        bulletProofPlus: bulletProofPlus,
        bulletProof: bulletProof,
        clsag: clsag,
        pseudoOuts: pseudoOuts);
    for (i = 0; i < inamounts.length; i++) {
      if (rctType.isClsag) {
        final prove =
            CLSAGUtins.fakeProve(signature.signature.mixRing![i].length);
        clsag.add(prove);
      } else {
        final prove = MLSAGUtils.fakeProve(signature.signature.mixRing![i]);
        mgs.add(prove);
      }
    }
    return buildSignature<S, P>(
        type: rctType,
        ecdh: ecdh,
        txnFee: txnFee,
        outPk: outPk,
        message: message,
        mixRing: mixRing,
        rangeSig: rangeSig,
        mgs: mgs,
        bulletProofPlus: bulletProofPlus,
        bulletProof: bulletProof,
        clsag: clsag,
        pseudoOuts: pseudoOuts);
  }

  static bool verRctSemanticsSimple(List<RCTSignature> rvv) {
    final List<Bulletproof> bpProofs = [];
    final List<BulletproofPlus> bppProofs = [];
    for (final rv in rvv) {
      if (!rv.signature.type.isSimple) {
        throw const MoneroCryptoException("called on non simple rctSig");
      }
      final bool bulletproof = rv.signature.type.isBulletproof;
      final bool bulletproofPlus = rv.signature.type.isBulletproofPlus;
      if (bulletproof || bulletproofPlus) {
        if (bulletproofPlus) {
          if (rv.signature.outPk.length !=
              nBulletproofPlusAmounts(rv.rctSigPrunable!
                  .cast<RctSigPrunableBulletproofPlus>()
                  .bulletproofPlus)) {
            throw Exception("Mismatched sizes of outPk and bulletproofs_plus");
          }
        } else {
          if (rv.signature.outPk.length !=
              nBulletproofAmounts(
                  rv.rctSigPrunable!.cast<BulletproofPrunable>().bulletproof)) {
            throw Exception("Mismatched sizes of outPk and bulletproofs");
          }
        }

        if (rv.signature.type.isClsag) {
          final clsag = rv.rctSigPrunable!.cast<ClsagPrunable>();
          if (clsag.pseudoOuts.length != clsag.clsag.length) {
            throw Exception("Mismatched sizes of pseudoOuts and CLSAGs");
          }
        }

        if (rv.signature.pseudoOuts?.isNotEmpty ?? false) {
          throw Exception("pseudoOuts is not empty");
        }
      }

      if (rv.signature.outPk.length != rv.signature.ecdhInfo.length) {
        throw Exception("Mismatched sizes of outPk and rv.ecdhInfo");
      }
    }

    for (final rv in rvv) {
      final bool bulletproof = rv.signature.type.isBulletproof;
      final bool bulletproofPlus = rv.signature.type.isBulletproofPlus;
      KeyV pseudoOuts = rv.signature.pseudoOuts ?? [];
      if (bulletproof || bulletproofPlus) {
        pseudoOuts =
            rv.rctSigPrunable!.pseudoOuts.map((e) => e.clone()).toList();
      }
      final KeyV masks =
          List.generate(rv.signature.outPk.length, (_) => RCT.zero());
      for (int i = 0; i < rv.signature.outPk.length; i++) {
        masks[i] = rv.signature.outPk[i].mask.clone();
      }
      final RctKey sumOutpks = RCT.addKeysBatch(masks);
      final RctKey txnFeeKey = RCT.scalarmultH(RCT.d2h(rv.signature.txnFee));
      RCT.addKeys(sumOutpks, txnFeeKey, sumOutpks);
      final RctKey sumPseudoOuts = RCT.addKeysBatch(pseudoOuts);
      if (!BytesUtils.bytesEqual(sumPseudoOuts, sumOutpks)) {
        return false;
      }
      if (bulletproofPlus) {
        final bpp = rv.rctSigPrunable!.cast<RctSigPrunableBulletproofPlus>();
        bppProofs.addAll(bpp.bulletproofPlus);
      } else if (bulletproof) {
        final bpp = rv.rctSigPrunable!.cast<BulletproofPrunable>();
        bpProofs.addAll(bpp.bulletproof);
      } else {
        final s = rv.rctSigPrunable!.cast<RctSigPrunableRangeSigs>();
        for (int i = 0; i < s.rangeSig.length; i++) {
          final verify = BoroSigUtils.verifyRange(
              rv.signature.outPk[i].mask, s.rangeSig[i]);
          if (!verify) return false;
        }
      }
    }
    if (bpProofs.isNotEmpty) {
      final ver = BulletproofsGenerator.bulletproofVerify(bpProofs);
      if (!ver) return false;
    }
    if (bppProofs.isNotEmpty) {
      final ver = BulletproofsPlusGenerator.bulletproofPlusVerify(bppProofs);
      if (!ver) return false;
    }
    return true;
  }

  static bool verRctNonSemanticsSimple(RCTSignature rv) {
    if (!rv.signature.type.isSimple) {
      throw const MoneroCryptoException("called on non simple rctSig");
    }
    if (rv.signature.mixRing == null || rv.signature.message == null) {
      throw const MoneroCryptoException(
          "mixRing and message required for verification.");
    }
    if (rv.rctSigPrunable == null) {
      throw const MoneroCryptoException(
          "Prunable signature is required for verification.");
    }
    final bool bulletproof = rv.signature.type.isBulletproof;
    final bool bulletproofPlus = rv.signature.type.isBulletproofPlus;
    if (bulletproof || bulletproofPlus) {
      if (rv.signature.mixRing!.length !=
          rv.rctSigPrunable!.pseudoOuts.length) {
        throw const MoneroCryptoException(
            "Mismatched sizes of pseudoOuts and mixRing");
      }
    } else {
      if (rv.signature.pseudoOuts == null) {
        throw const MoneroCryptoException(
            "Signature pseudoOuts is required for verification.");
      }
      if (rv.signature.mixRing!.length != rv.signature.pseudoOuts?.length) {
        throw const MoneroCryptoException(
            "Mismatched sizes of pseudoOuts and mixRing");
      }
    }
    final KeyV pseudoOuts = bulletproof || bulletproofPlus
        ? rv.rctSigPrunable!.pseudoOuts
        : rv.signature.pseudoOuts!;
    final message = MLSAGUtils.getPreMlsagHash(rv);
    for (int i = 0; i < rv.signature.mixRing!.length; i++) {
      if (rv.signature.type.isClsag) {
        final cslag = rv.rctSigPrunable!.cast<ClsagPrunable>();
        final verify = CLSAGUtins.verify(
            message, cslag.clsag[i], rv.signature.mixRing![i], pseudoOuts[i]);
        if (!verify) return false;
      } else {
        final mgs = rv.rctSigPrunable!.cast<MgSigPrunable>();
        final verify = MLSAGUtils.verifySimple(
            message, mgs.mgs[i], rv.signature.mixRing![i], pseudoOuts[i]);
        if (!verify) return false;
      }
    }
    return true;
  }

  static bool verRctSimple(RCTSignature rv) {
    final bool verRctNonSemantics = verRctNonSemanticsSimple(rv);
    bool verRctSemantics = false;
    if (verRctNonSemantics) {
      verRctSemantics = verRctSemanticsSimple([rv]);
    }
    return verRctSemantics && verRctNonSemantics;
  }

  static int nBulletproofAmountsBase(
      int lSize, int rSize, int vSize, int maxOutputs) {
    if (lSize < 6) {
      throw Exception("Invalid bulletproof L size");
    }
    if (lSize != rSize) {
      throw Exception("Mismatched bulletproof L/R size");
    }

    const int extraBits = 4;
    if ((1 << extraBits) != maxOutputs) {
      throw Exception("log2(max_outputs) is out of date");
    }
    if (lSize > 6 + extraBits) {
      throw Exception("Invalid bulletproof L size");
    }
    if (vSize > (1 << (lSize - 6))) {
      throw Exception("Invalid bulletproof V/L");
    }
    if (vSize * 2 <= (1 << (lSize - 6))) {
      throw Exception("Invalid bulletproof V/L");
    }
    if (vSize <= 0) {
      throw Exception("Empty bulletproof");
    }

    return vSize;
  }

  static int nBulletproofAmount(Bulletproof proof) {
    return nBulletproofAmountsBase(
        proof.l.length, proof.r.length, proof.v.length, maxOuts);
  }

  static int nBulletproofPlusAmount(BulletproofPlus proof) {
    return nBulletproofAmountsBase(
        proof.l.length, proof.r.length, proof.v.length, maxOuts);
  }

  static int nBulletproofAmounts(List<Bulletproof> proofs) {
    int n = 0;

    for (final Bulletproof proof in proofs) {
      final int n2 = nBulletproofAmount(proof);
      if (n2 >= mask32 - n) {
        throw Exception("Invalid number of bulletproofs");
      }

      if (n2 == 0) {
        return 0;
      }

      n += n2;
    }

    return n;
  }

  static int nBulletproofMaxAmountBase(
      {required int lSize, required int rSize, required int maxOuts}) {
    const int extraBits = 4;

    if (lSize < 6) {
      throw ArgumentError(
          "Invalid bulletproof L size: L size must be at least 6.");
    }
    if (lSize != rSize) {
      throw ArgumentError(
          "Mismatched bulletproof L/R size: L size and R_size must be equal.");
    }
    if ((1 << extraBits) != maxOuts) {
      throw ArgumentError(
          "log2(max_outputs) is out of date: max_outputs must be 2^extraBits.");
    }
    if (lSize > 6 + extraBits) {
      throw ArgumentError(
          "Invalid bulletproof L size: L_size must not exceed 6 + extraBits.");
    }
    return 1 << (lSize - 6);
  }

  static int _nBulletproofMaxAmounts(Bulletproof proof) {
    return nBulletproofMaxAmountBase(
        lSize: proof.l.length,
        rSize: proof.r.length,
        maxOuts: MoneroConst.bulletproofMaxOutputs);
  }

  static int _nBulletproofPlusMaxAmounts(BulletproofPlus proof) {
    return nBulletproofMaxAmountBase(
        lSize: proof.l.length,
        rSize: proof.r.length,
        maxOuts: MoneroConst.bulletproofPlussMaxOutputs);
  }

  static int nBulletproofMaxAmounts(List<Bulletproof> proofs) {
    int n = 0;
    for (final proof in proofs) {
      final int n2 = _nBulletproofMaxAmounts(proof);
      if (n2 >= (1 << 32) - 1 - n) {
        throw ArgumentError(
            "Invalid number of bulletproofs: sum of amounts exceeds uint32 max value.");
      }
      if (n2 == 0) {
        return 0;
      }
      n += n2;
    }
    return n;
  }

  static int nBulletproofPlusMaxAmounts(List<BulletproofPlus> proofs) {
    int n = 0;
    for (final proof in proofs) {
      final int n2 = _nBulletproofPlusMaxAmounts(proof);
      if (n2 >= (1 << 32) - 1 - n) {
        throw ArgumentError(
            "Invalid number of bulletproofs: sum of amounts exceeds uint32 max value.");
      }
      if (n2 == 0) {
        return 0;
      }
      n += n2;
    }
    return n;
  }

  static RCTSignature<S, P>
      buildSignature<S extends RCTSignatureBase, P extends RctSigPrunable>({
    required RCTType type,
    required List<EcdhInfo> ecdh,
    required BigInt txnFee,
    required List<CtKey> outPk,
    required RctKey message,
    required List<List<CtKey>> mixRing,
    required List<RangeSig> rangeSig,
    required List<MgSig> mgs,
    required List<BulletproofPlus> bulletProofPlus,
    required List<Bulletproof> bulletProof,
    required List<Clsag> clsag,
    required KeyV pseudoOuts,
  }) {
    RCTSignatureBase base;
    RctSigPrunable prunable;
    switch (type) {
      case RCTType.rctTypeFull:
        base = RCTFull(
            ecdhInfo: ecdh.cast<EcdhInfoV1>(),
            txnFee: txnFee,
            outPk: outPk,
            message: message,
            mixRing: mixRing);
        prunable = RctSigPrunableRangeSigs(rangeSig: rangeSig, mgs: mgs);
        break;
      case RCTType.rctTypeBulletproofPlus:
        base = RCTBulletproofPlus(
            ecdhInfo: ecdh.cast<EcdhInfoV2>(),
            txnFee: txnFee,
            outPk: outPk,
            message: message,
            mixRing: mixRing);
        prunable = RctSigPrunableBulletproofPlus(
            bulletproofPlus: bulletProofPlus,
            clsag: clsag,
            pseudoOuts: pseudoOuts);
        break;
      case RCTType.rctTypeBulletproof2:
        base = RCTBulletproof2(
            ecdhInfo: ecdh.cast<EcdhInfoV2>(),
            txnFee: txnFee,
            outPk: outPk,
            message: message,
            mixRing: mixRing);
        prunable = RctSigPrunableBulletproof2(
            bulletproof: bulletProof, mgs: mgs, pseudoOuts: pseudoOuts);
        break;
      case RCTType.rctTypeBulletproof:
        base = RCTBulletproof(
            ecdhInfo: ecdh.cast<EcdhInfoV1>(),
            txnFee: txnFee,
            outPk: outPk,
            message: message,
            mixRing: mixRing);
        prunable = RctSigPrunableBulletproof(
            bulletproof: bulletProof, mgs: mgs, pseudoOuts: pseudoOuts);
        break;
      case RCTType.rctTypeCLSAG:
        base = RCTCLSAG(
            ecdhInfo: ecdh.cast<EcdhInfoV2>(),
            txnFee: txnFee,
            outPk: outPk,
            message: message,
            mixRing: mixRing);
        prunable = RctSigPrunableCLSAG(
            bulletproof: bulletProof, clsag: clsag, pseudoOuts: pseudoOuts);
        break;
      case RCTType.rctTypeSimple:
        base = RCTSimple(
            ecdhInfo: ecdh.cast<EcdhInfoV1>(),
            pseudoOuts: pseudoOuts,
            txnFee: txnFee,
            outPk: outPk,
            message: message,
            mixRing: mixRing);
        prunable = RctSigPrunableRangeSigs(mgs: mgs, rangeSig: rangeSig);
        break;
      default:
        throw const MoneroCryptoException("Invalid rct type.");
    }
    if (base is! S || prunable is! P) {
      throw const MoneroCryptoException("RCTSignature casting failed.");
    }
    return RCTSignature<S, P>(signature: base, rctSigPrunable: prunable);
  }

  static int nBulletproofPlusAmounts(List<BulletproofPlus> proofs) {
    int n = 0;

    for (final BulletproofPlus proof in proofs) {
      final int n2 = nBulletproofPlusAmount(proof);

      if (n2 >= mask32 - n) {
        throw Exception("Invalid number of bulletproofs");
      }

      if (n2 == 0) {
        return 0;
      }

      n += n2;
    }

    return n;
  }

  static RCTSignature<S, P>
      genRctSimple_<S extends RCTSignatureBase, P extends RctSigPrunable>(
          {required RctKey message,
          required CtKeyV inSk,
          required CtKeyV inPk,
          required KeyV destinations,
          required List<BigInt> inamounts,
          required List<BigInt> outamounts,
          required KeyV amountKeys,
          required BigInt txnFee,
          required int mixin,
          required RangeProofType rangeProofType,
          RCTType? bpVersion,
          bool createLinkable = true}) {
    final List<int> index = List.filled(inPk.length, 0);
    final CtKeyM mixRing = List.generate(
        inPk.length,
        (_) => List.generate(
            mixin + 1, (_) => CtKey(dest: RCT.zero(), mask: RCT.zero())));
    final CtKeyV outSk = List.generate(
        destinations.length, (_) => CtKey(dest: RCT.zero(), mask: RCT.zero()));
    for (int i = 0; i < inPk.length; ++i) {
      index[i] = _generateKeySimple(mixRing[i], inPk[i], mixin);
    }
    return genRctSimple(
        message: message,
        inSk: inSk,
        destinations: destinations,
        inamounts: inamounts,
        outamounts: outamounts,
        txnFee: txnFee,
        mixRing: mixRing,
        amountKeys: amountKeys,
        index: index,
        outSk: outSk,
        rangeProofType: rangeProofType,
        rctType: bpVersion,
        createLinkable: createLinkable);
  }

  static int _generateKeySimple(CtKeyV mixRing, CtKey inPk, int mixin) {
    final int index = RCT.randXmrAmount(BigInt.from(mixin)).toInt();
    int i = 0;
    for (i = 0; i <= mixin; i++) {
      if (i != index) {
        mixRing[i] = _generateRandomKey();
      } else {
        mixRing[i] = inPk;
      }
    }
    return index;
  }

  static BigInt decodeRct(
      {required RCTSignature sig,
      required RctKey secretKey,
      required int outputIndex,
      RctKey? mask}) {
    if (outputIndex >= sig.signature.ecdhInfo.length) {
      throw const MoneroCryptoException("Bad index");
    }
    if (sig.signature.outPk.length != sig.signature.ecdhInfo.length) {
      throw const MoneroCryptoException(
          "Mismatched sizes of rv.outPk and rv.ecdhInfo");
    }
    final ecdh = sig.signature.ecdhInfo[outputIndex];
    final result = RCT.ecdhDecode(ecdh: ecdh, sharedSec: secretKey);
    mask ??= RCT.zero();
    CryptoOps.scFill(mask, result.mask);
    final RctKey amount = result.amount;
    final RctKey c = sig.signature.outPk[outputIndex].mask;
    final RctKey t = RCT.zero();
    if (CryptoOps.scCheck(mask) != 0) {
      throw const MoneroCryptoException("bad ECDH mask.");
    }
    if (CryptoOps.scCheck(amount) != 0) {
      throw const MoneroCryptoException("bad ECDH amount.");
    }

    RCT.addKeys2(t, mask, amount, RCTConst.h);
    if (!BytesUtils.bytesEqual(c, t)) {
      throw const MoneroCryptoException(
          "amount decoded incorrectly, will be unable to spend");
    }
    return RCT.h2d(amount);
  }

  static BigInt? decodeRct_(
      {required RCTSignature sig,
      required RctKey secretKey,
      required int outputIndex,
      RctKey? mask}) {
    try {
      return decodeRct(
          sig: sig, secretKey: secretKey, outputIndex: outputIndex, mask: mask);
    } on MoneroCryptoException {
      return null;
    }
  }

  static int weightClawBack(RCTSignature signature) {
    final type = signature.signature.type;
    if (signature.rctSigPrunable == null) {
      throw const DartMoneroPluginException(
          "signature prunable required for calculate claw back.");
    }
    if (!type.isBulletproof && !type.isBulletproofPlus) {
      return 0;
    }
    int paddedOutputs = 0;
    if (type.isBulletproofPlus) {
      paddedOutputs = nBulletproofPlusMaxAmounts(signature.rctSigPrunable!
          .cast<RctSigPrunableBulletproofPlus>()
          .bulletproofPlus);
    } else {
      paddedOutputs = nBulletproofMaxAmounts(
          signature.rctSigPrunable!.cast<BulletproofPrunable>().bulletproof);
    }
    if (paddedOutputs <= 2) return 0;
    final isBpp = type.isBulletproofPlus;
    final int bpBase = (32 * ((isBpp ? 6 : 9) + 7 * 2)) ~/ 2;

    int nlr = 0;
    while ((1 << nlr) < paddedOutputs) {
      ++nlr;
    }
    nlr += 6;
    final int bpSize = 32 * ((isBpp ? 6 : 9) + 2 * nlr);
    final int bpClawback = (bpBase * paddedOutputs - bpSize) * 4 ~/ 5;
    return bpClawback;
  }
}
