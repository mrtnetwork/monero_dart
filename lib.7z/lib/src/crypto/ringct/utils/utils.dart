import 'package:monero_dart/src/crypto/ringct/utils/rct_crypto.dart';
import 'package:monero_dart/src/crypto/types/types.dart';

class RCTUtils {
  static RctKey strToKey(String data) {
    List<int> toBytes = data.codeUnits;
    if (toBytes.length > 32) {
      toBytes = toBytes.sublist(0, 32);
    }
    final key = RCT.zero();
    for (int i = 0; i < toBytes.length; i++) {
      key[i] = toBytes[i];
    }
    return key;
  }
}
