import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:monero_dart/src/crypto/exception/exception.dart';
import 'package:monero_dart/src/models/transaction/signature/rct_prunable.dart';
import 'package:monero_dart/src/models/transaction/signature/signature.dart';
import 'package:monero_dart/src/crypto/models/ct_key.dart';
import 'package:monero_dart/src/crypto/ringct/utils/rct_crypto.dart';
import 'package:monero_dart/src/crypto/types/types.dart';

class MLSAGUtils {
  static MgSig generate(
      RctKey message, KeyM pk, KeyV xx, int index, int dsRows) {
    final int cols = pk.length;
    if (pk.length < 2) {
      throw const MoneroCryptoException("Error! What is c if cols = 1!");
    }
    if (index >= pk.length) {
      throw const MoneroCryptoException("Index out of range");
    }

    final int rows = pk[0].length;
    if (rows < 1) {
      throw const MoneroCryptoException("Empty pk");
    }

    // Check if pk is rectangular
    for (int i = 1; i < cols; ++i) {
      if (pk[i].length != rows) {
        throw const MoneroCryptoException("pk is not rectangular");
      }
    }

    if (xx.length != rows) {
      throw const MoneroCryptoException("Bad xx size");
    }
    if (dsRows > rows) {
      throw const MoneroCryptoException("Bad dsRows size");
    }
    int i = 0, j = 0;
    RctKey c = RCT.zero(),
        cOld = RCT.zero(),
        L = RCT.zero(),
        R = RCT.zero(),
        hI = RCT.zero();
    final GroupElementP3 hiP3 = GroupElementP3();
    final List<GroupElementDsmp> ip =
        List.generate(dsRows, (_) => GroupElementCached.dsmp);
    final KeyV ii = List.generate(dsRows, (_) => RCT.zero());
    final KeyV alpha = List.generate(rows, (_) => RCT.zero());
    final KeyV aG = List.generate(rows, (_) => RCT.zero());
    final KeyM ss =
        List.generate(cols, (_) => List.generate(rows, (_) => RCT.zero()));
    final KeyV aHP = List.generate(dsRows, (_) => RCT.zero());
    final KeyV toHash = List.filled(
        1 + 3 * dsRows + 2 * (rows - dsRows), RCT.zero(clone: false));
    RctKey cc = RCT.zero();
    toHash[0] = message;
    for (i = 0; i < dsRows; i++) {
      toHash[3 * i + 1] = pk[index][i];
      RCT.hashToP3(hiP3, pk[index][i]);
      CryptoOps.geP3Tobytes(hI, hiP3);
      mlsagPrepare(hI, xx[i], alpha[i], aG[i], aHP[i], ii[i]);
      toHash[3 * i + 2] = aG[i];
      toHash[3 * i + 3] = aHP[i];
      RCT.precomp(ip[i], ii[i]);
    }
    final int ndsRows = 3 * dsRows;
    for (int i = dsRows, ii = 0; i < rows; i++, ii++) {
      RCT.skpkGen(alpha[i], aG[i]);
      toHash[ndsRows + 2 * ii + 1] = pk[index][i];
      toHash[ndsRows + 2 * ii + 2] = aG[i];
    }
    cOld = RCT.hashToScalarKeys(toHash);
    i = (index + 1) % cols;
    if (i == 0) {
      cc = cOld.clone();
    }
    while (i != index) {
      ss[i] = RCT.skvGen(rows);
      CryptoOps.scZero(c);
      for (j = 0; j < dsRows; j++) {
        RCT.addKeys2(L, ss[i][j], cOld, pk[i][j]);
        RCT.hashToP3(hiP3, pk[i][j]);
        CryptoOps.geP3Tobytes(hI, hiP3);
        RCT.addKeys3(R, ss[i][j], hI, cOld, ip[j]);
        toHash[3 * j + 1] = pk[i][j];
        toHash[3 * j + 2] = L.clone();
        toHash[3 * j + 3] = R.clone();
      }
      for (int j = dsRows, ii = 0; j < rows; j++, ii++) {
        RCT.addKeys2(L, ss[i][j], cOld, pk[i][j]);
        toHash[ndsRows + 2 * ii + 1] = pk[i][j];
        toHash[ndsRows + 2 * ii + 2] = L.clone();
      }
      c = RCT.hashToScalarKeys(toHash);
      cOld = c.clone();
      i = (i + 1) % cols;

      if (i == 0) {
        cc = cOld.clone();
      }
    }
    mlsagSign(c, xx, alpha, rows, dsRows, ss[index]);

    return MgSig(ss: ss, cc: cc, ii: ii);
  }

  static void mlsagPrepare(
      RctKey H, RctKey xx, RctKey a, RctKey aG, RctKey aHP, RctKey ii) {
    RCT.skpkGen(a, aG);
    RCT.scalarmultKey(aHP, H, a);
    RCT.scalarmultKey(ii, H, xx);
  }

  static void mlsagSign(
      RctKey c, KeyV xx, KeyV alpha, int rows, int dsRows, KeyV ss) {
    if (dsRows > rows) {
      throw const MoneroCryptoException("dsRows greater than rows");
    }
    if (xx.length != rows) {
      throw const MoneroCryptoException("xx size does not match rows");
    }
    if (alpha.length != rows) {
      throw const MoneroCryptoException("alpha size does not match rows");
    }
    if (ss.length != rows) {
      throw const MoneroCryptoException("ss size does not match rows");
    }

    for (int j = 0; j < rows; j++) {
      CryptoOps.scMulSub(ss[j], c, xx[j], alpha[j]);
    }
  }

  static bool verify(RctKey message, KeyM pk, MgSig rv, int dsRows) {
    final int cols = pk.length;
    if (cols < 2) {
      throw const MoneroCryptoException(
          "Signature must contain more than one public key");
    }

    final int rows = pk[0].length;
    if (rows < 1) {
      throw const MoneroCryptoException("Bad total row number");
    }

    for (int i = 1; i < cols; i++) {
      if (pk[i].length != rows) {
        throw const MoneroCryptoException("Bad public key matrix dimensions");
      }
    }

    if (rv.ii.length != dsRows) {
      throw const MoneroCryptoException("Wrong number of key images present");
    }

    if (rv.ss.length != cols) {
      throw const MoneroCryptoException("Bad scalar matrix dimensions");
    }

    for (int i = 0; i < cols; i++) {
      if (rv.ss[i].length != rows) {
        throw const MoneroCryptoException("Bad scalar matrix dimensions");
      }
    }

    if (dsRows > rows) {
      throw const MoneroCryptoException(
          "Non-double-spend rows cannot exceed total rows");
    }
    int i = 0, j = 0;
    RctKey c = RCT.zero(), L = RCT.zero(), R = RCT.zero();
    RctKey cOld = rv.cc.clone();
    final List<GroupElementDsmp> ip =
        List.generate(dsRows, (_) => GroupElementCached.dsmp);
    for (i = 0; i < dsRows; i++) {
      if (BytesUtils.bytesEqual(rv.ii[i], RCT.identity(clone: false))) {
        throw const MoneroCryptoException("Bad key image");
      }
      RCT.precomp(ip[i], rv.ii[i]);
    }
    final int ndsRows = 3 * dsRows;
    final KeyV toHash = List.filled(
        1 + 3 * dsRows + 2 * (rows - dsRows), RCT.zero(clone: false));
    toHash[0] = message;
    i = 0;
    while (i < cols) {
      // c = RCT.zero();
      CryptoOps.scZero(c);
      for (j = 0; j < dsRows; j++) {
        RCT.addKeys2(L, rv.ss[i][j], cOld, pk[i][j]);

        // Compute R directly
        final GroupElementP3 hash8P3 = GroupElementP3();
        RCT.hashToP3(hash8P3, pk[i][j]);
        final GroupElementP2 rP2 = GroupElementP2();
        CryptoOps.geDoubleScalarMultPrecompVartime(
            rP2, rv.ss[i][j], hash8P3, cOld, ip[j]);
        CryptoOps.geToBytes(R, rP2);

        toHash[3 * j + 1] = pk[i][j];
        toHash[3 * j + 2] = L.clone();
        toHash[3 * j + 3] = R.clone();
      }
      for (int j = dsRows, ii = 0; j < rows; j++, ii++) {
        RCT.addKeys2(L, rv.ss[i][j], cOld, pk[i][j]);
        toHash[ndsRows + 2 * ii + 1] = pk[i][j];
        toHash[ndsRows + 2 * ii + 2] = L.clone();
      }
      c = RCT.hashToScalarKeys(toHash);
      if (BytesUtils.bytesEqual(c, RCT.zero(clone: false))) {
        throw const MoneroCryptoException("Bad signature hash");
      }
      cOld = c.clone();
      i = (i + 1);
    }
    CryptoOps.scSub(c, cOld, rv.cc);
    return CryptoOps.scIsNonZero(c) == 0;
  }

  static MgSig prove(RctKey message, CtKeyM pubs, CtKeyV inSk, KeyV outSk,
      CtKeyV outPk, int index, RctKey txnFeeKey) {
    final int cols = pubs.length;
    if (cols < 1) {
      throw const MoneroCryptoException("Empty pubs");
    }

    final int rows = pubs[0].length;
    if (rows < 1) {
      throw const MoneroCryptoException("Empty pubs");
    }

    for (int i = 1; i < cols; i++) {
      if (pubs[i].length != rows) {
        throw const MoneroCryptoException("pubs is not rectangular");
      }
    }

    if (inSk.length != rows) {
      throw const MoneroCryptoException("Bad inSk size");
    }

    if (outSk.length != outPk.length) {
      throw const MoneroCryptoException("Bad outSk/outPk size");
    }
    final KeyV sk = List.generate(rows + 1, (_) => RCT.zero());
    int i = 0, j = 0;
    final KeyM M = List.generate(
        cols, (_) => List.generate(rows + 1, (_) => RCT.identity()));
    for (i = 0; i < cols; i++) {
      M[i][rows] = RCT.identity();
      for (j = 0; j < rows; j++) {
        M[i][j] = pubs[i][j].dest;
        RCT.addKeys(M[i][rows], M[i][rows],
            pubs[i][j].mask); //add input commitments in last row
      }
    }
    for (j = 0; j < rows; j++) {
      sk[j] = inSk[j].dest.clone();
      CryptoOps.scAdd(sk[rows], sk[rows], inSk[j].mask); //add masks in last row
    }
    for (i = 0; i < cols; i++) {
      for (int j = 0; j < outPk.length; j++) {
        RCT.subKeys(M[i][rows], M[i][rows],
            outPk[j].mask); //subtract output Ci's in last row
      }
      //subtract txn fee output in last row
      RCT.subKeys(M[i][rows], M[i][rows], txnFeeKey);
    }
    for (int j = 0; j < outPk.length; j++) {
      CryptoOps.scSub(
          sk[rows], sk[rows], outSk[j]); //subtract output masks in last row..
    }
    return generate(message, M, sk, index, rows);
  }

  static MgSig fakeProve(CtKeyV pubs) {
    final int cols = pubs.length;
    final ss = List.filled(cols, List.filled(2, RCT.identity(clone: false)));
    return MgSig(
        ss: ss,
        cc: RCT.identity(clone: false),
        ii: List.filled(1, RCT.identity(clone: false)));
  }

  static MgSig proveSimple(RctKey message, CtKeyV pubs, CtKey inSk, RctKey a,
      RctKey cout, int index) {
    const int rows = 1;
    final int cols = pubs.length;
    if (pubs.isEmpty) {
      throw const MoneroCryptoException("Empty pubs");
    }
    final KeyV sk = List.generate(rows + 1, (_) => RCT.zero());
    int i;
    final KeyM M =
        List.generate(cols, (_) => List.generate(rows + 1, (_) => RCT.zero()));
    sk[0] = inSk.dest.clone();
    CryptoOps.scSub(sk[1], inSk.mask, a);
    for (i = 0; i < cols; i++) {
      M[i][0] = pubs[i].dest;
      RCT.subKeys(M[i][1], pubs[i].mask, cout);
    }
    return generate(message, M, sk, index, rows);
  }

  static bool verRctMG(
      MgSig mg, CtKeyM pubs, CtKeyV outPk, RctKey txnFeeKey, RctKey message) {
    final int cols = pubs.length;
    if (cols < 1) {
      throw const MoneroCryptoException("Empty pubs");
    }

    final int rows = pubs[0].length;
    if (rows < 1) {
      throw const MoneroCryptoException("Empty pubs");
    }

    for (int i = 1; i < cols; i++) {
      if (pubs[i].length != rows) {
        throw const MoneroCryptoException("pubs is not rectangular");
      }
    }
    int i = 0, j = 0;
    final KeyM M = List.generate(
        cols, (_) => List.generate(rows + 1, (_) => RCT.identity()));

    for (j = 0; j < rows; j++) {
      for (i = 0; i < cols; i++) {
        M[i][j] = pubs[i][j].dest;
        RCT.addKeys(M[i][rows], M[i][rows], pubs[i][j].mask);
      }
    }
    for (i = 0; i < cols; i++) {
      for (j = 0; j < outPk.length; j++) {
        RCT.subKeys(M[i][rows], M[i][rows], outPk[j].mask);
      }
      RCT.subKeys(M[i][rows], M[i][rows], txnFeeKey);
    }
    return verify(message, M, mg, rows);
  }

  static bool verifySimple(RctKey message, MgSig mg, CtKeyV pubs, RctKey C) {
    try {
      const int rows = 1;
      final int cols = pubs.length;
      if (pubs.isEmpty) {
        throw const MoneroCryptoException("Empty pubs");
      }
      int i;
      final KeyM M = List.generate(
          cols, (_) => List.generate(rows + 1, (_) => RCT.zero()));
      final GroupElementP3 cP3 = GroupElementP3();
      if (CryptoOps.geFromBytesVartime_(cP3, C) != 0) {
        throw const MoneroCryptoException("point conv failed");
      }
      final GroupElementCached cCached = GroupElementCached();
      CryptoOps.geP3ToCached(cCached, cP3);
      final GroupElementP1P1 p1 = GroupElementP1P1();
      for (i = 0; i < cols; i++) {
        M[i][0] = pubs[i].dest;
        final GroupElementP3 p3 = GroupElementP3();
        if (CryptoOps.geFromBytesVartime_(p3, pubs[i].mask) != 0) {
          throw const MoneroCryptoException("point conv failed");
        }
        CryptoOps.geSub(p1, p3, cCached);
        CryptoOps.geP1P1ToP3(p3, p1);
        CryptoOps.geP3Tobytes(M[i][1], p3);
      }
      return verify(message, M, mg, rows);
    } catch (_) {
      return false;
    }
  }

  static RctKey getPreMlsagHash(RCTSignature rv) {
    final KeyV hashes = [];
    if (rv.signature.message == null ||
        (rv.signature.mixRing?.isEmpty ?? true)) {
      throw const MoneroCryptoException(
          "message and mixRing required for generate mlsag hash.");
    }
    final message = rv.signature.message!;
    final mixRing = rv.signature.mixRing!;
    hashes.add(message);
    final int inputs =
        rv.signature.type.isSimple ? mixRing.length : mixRing[0].length;
    final int outputs = rv.signature.ecdhInfo.length;
    final ss = RCTSignature.layout(
            inputLength: inputs, outputLength: outputs, forcePrunable: true)
        .serialize(rv.toLayoutStruct());
    final h = QuickCrypto.keccack256Hash(ss);
    hashes.add(h);
    final KeyV kv = [];
    if (rv.signature.type == RCTType.rctTypeBulletproof ||
        rv.signature.type == RCTType.rctTypeBulletproof2 ||
        rv.signature.type == RCTType.rctTypeCLSAG) {
      final bulletproofs = rv.rctSigPrunable!.cast<BulletproofPrunable>();
      for (final p in bulletproofs.bulletproof) {
        // V are not hashed as they're expanded from outPk.mask
        // (and thus hashed as part of rctSigBase above)
        kv.add(p.a);
        kv.add(p.s);
        kv.add(p.t1);
        kv.add(p.t2);
        kv.add(p.taux);
        kv.add(p.mu);
        for (int n = 0; n < p.l.length; ++n) {
          kv.add(p.l[n]);
        }
        for (int n = 0; n < p.r.length; ++n) {
          kv.add(p.r[n]);
        }
        kv.add(p.a_);
        kv.add(p.b);
        kv.add(p.t);
      }
    } else if (rv.signature.type == RCTType.rctTypeBulletproofPlus) {
      final bulletproofs =
          rv.rctSigPrunable!.cast<RctSigPrunableBulletproofPlus>();
      for (final p in bulletproofs.bulletproofPlus) {
        kv.add(p.a);
        kv.add(p.a1);
        kv.add(p.b);
        kv.add(p.r1);
        kv.add(p.s1);
        kv.add(p.d1);
        for (int n = 0; n < p.l.length; ++n) {
          kv.add(p.l[n]);
        }
        for (int n = 0; n < p.r.length; ++n) {
          kv.add(p.r[n]);
        }
      }
    } else {
      final range = rv.rctSigPrunable!.cast<RctSigPrunableRangeSigs>();
      for (final r in range.rangeSig) {
        for (int n = 0; n < 64; ++n) {
          kv.add(r.asig.s0[n]);
        }
        for (int n = 0; n < 64; ++n) {
          kv.add(r.asig.s1[n]);
        }
        kv.add(r.asig.ee);
        for (int n = 0; n < 64; ++n) {
          kv.add(r.ci[n]);
        }
      }
    }
    hashes.add(QuickCrypto.keccack256Hash(kv.expand((e) => e).toList()));
    return QuickCrypto.keccack256Hash(hashes.expand((e) => e).toList());
  }
}
