import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:monero_dart/src/crypto/exception/exception.dart';
import 'package:monero_dart/src/models/transaction/signature/rct_prunable.dart';
import 'package:monero_dart/src/crypto/ringct/const/const.dart';
import 'package:monero_dart/src/crypto/ringct/utils/rct_crypto.dart';
import 'package:monero_dart/src/crypto/types/types.dart';

class BoroSigUtils {
  static BoroSig generateFakeBorromean() {
    final Key64 fake =
        List<List<int>>.generate(64, (_) => RCT.zero(clone: false));
    return BoroSig(s0: fake, s1: fake, ee: RCT.identity(clone: false));
  }

  static BoroSig generateBorromean(
      {required Key64 x,
      required Key64 p1,
      required Key64 p2,
      required List<int> indices}) {
    final Key64 s0 = List<List<int>>.generate(64, (_) => RCT.zero());
    final Key64 s1 = List<List<int>>.generate(64, (_) => RCT.zero());
    final List<Key64> L = [
      List<List<int>>.generate(64, (_) => RCT.zero()),
      List<List<int>>.generate(64, (_) => RCT.zero()),
    ];
    final Key64 alpha = List<List<int>>.generate(64, (_) => RCT.zero());
    RctKey c = RCT.zero();
    int naught = 0, prime = 0, ii = 0, jj = 0;
    for (ii = 0; ii < 64; ii++) {
      naught = indices[ii];
      prime = (indices[ii] + 1) % 2;
      RCT.skGen(alpha[ii]);
      RCT.scalarmultBase(L[naught][ii], alpha[ii]);
      if (naught == 0) {
        RCT.skGen(s1[ii]);
        c = RCT.hashToScalar_(L[naught][ii]);
        RCT.addKeys2(L[prime][ii], s1[ii], c, p2[ii]);
      }
    }
    final ee = RCT.hashToScalarKeys(L[1]);
    RctKey ll = RCT.zero(), cc = RCT.zero();
    for (jj = 0; jj < 64; jj++) {
      if (indices[jj] == 0) {
        CryptoOps.scMulSub(s0[jj], x[jj], ee, alpha[jj]);
      } else {
        RCT.skGen(s0[jj]);
        RCT.addKeys2(ll, s0[jj], ee, p1[jj]);
        cc = RCT.hashToScalar_(ll);
        CryptoOps.scMulSub(s1[jj], x[jj], cc, alpha[jj]);
      }
    }
    return BoroSig(s0: s0, s1: s1, ee: ee);
  }

  static bool verifyBorromean(
      BoroSig bb, List<GroupElementP3> p1, List<GroupElementP3> p2) {
    final Key64 lv1 = List.generate(64, (_) => RCT.zero());
    RctKey chash = RCT.zero(), ll = RCT.zero();
    int ii = 0;
    final GroupElementP2 p2P = GroupElementP2();
    for (ii = 0; ii < 64; ii++) {
      CryptoOps.geDoubleScalarMultBaseVartime(p2P, bb.ee, p1[ii], bb.s0[ii]);
      CryptoOps.geToBytes(ll, p2P);
      chash = RCT.hashToScalar_(ll);
      CryptoOps.geDoubleScalarMultBaseVartime(p2P, chash, p2[ii], bb.s1[ii]);
      CryptoOps.geToBytes(lv1[ii], p2P);
    }
    final RctKey eeComputed = RCT.hashToScalarKeys(lv1);
    return BytesUtils.bytesEqual(eeComputed, bb.ee);
  }

  static bool verifyBorromean_(BoroSig bb, Key64 p1, Key64 p2) {
    final List<GroupElementP3> p1P3 =
            List.generate(64, (_) => GroupElementP3()),
        p2P3 = List.generate(64, (_) => GroupElementP3());
    for (int i = 0; i < 64; ++i) {
      if (CryptoOps.geFromBytesVartime_(p1P3[i], p1[i]) != 0) {
        throw const MoneroCryptoException("point conv failed");
      }
      if (CryptoOps.geFromBytesVartime_(p2P3[i], p2[i]) != 0) {
        throw const MoneroCryptoException("point conv failed");
      }
    }
    return verifyBorromean(bb, p1P3, p2P3);
  }

  static RangeSig fakeProveRange() {
    final asig = generateFakeBorromean();
    return RangeSig(asig: asig, ci: asig.s0);
  }

  static RangeSig proveRange(RctKey C, RctKey mask, BigInt amount) {
    CryptoOps.scZero(mask);
    CryptoOps.scFill(C, RCT.identity(clone: false));
    final Bits b = RCT.bits();
    RCT.d2b(b, amount);
    final Key64 ai = List.generate(64, (_) => RCT.zero());
    final Key64 cIH = List.generate(64, (_) => RCT.zero());
    final Key64 sigCi = List.generate(64, (_) => RCT.zero());
    int i = 0;
    for (i = 0; i < 64; i++) {
      RCT.skGen(ai[i]);
      if (b[i] == 0) {
        RCT.scalarmultBase(sigCi[i], ai[i]);
      }
      if (b[i] == 1) {
        RCT.addKeys1(aGbB: sigCi[i], a: ai[i], b: RCTConst.h2[i]);
      }
      RCT.subKeys(cIH[i], sigCi[i], RCTConst.h2[i]);
      CryptoOps.scAdd(mask, mask, ai[i]);
      RCT.addKeys(C, C, sigCi[i]);
    }
    final asig = generateBorromean(x: ai, p1: sigCi, p2: cIH, indices: b);
    return RangeSig(asig: asig, ci: sigCi);
  }

  static bool verifyRange(RctKey C, RangeSig as) {
    try {
      final List<GroupElementP3> cIH =
          List.generate(64, (_) => GroupElementP3());
      final List<GroupElementP3> asCi =
          List.generate(64, (_) => GroupElementP3());
      int i = 0;
      final GroupElementP3 ctempP3 = RCTConst.identityP3.clone();
      for (i = 0; i < 64; i++) {
        final GroupElementCached cached = GroupElementCached();
        final GroupElementP3 p3 = GroupElementP3();
        final GroupElementP1P1 p1 = GroupElementP1P1();
        if (CryptoOps.geFromBytesVartime_(p3, RCTConst.h2[i]) != 0) {
          throw const MoneroCryptoException("point conv failed");
        }
        CryptoOps.geP3ToCached(cached, p3);
        if (CryptoOps.geFromBytesVartime_(asCi[i], as.ci[i]) != 0) {
          throw const MoneroCryptoException("point conv failed");
        }
        CryptoOps.geSub(p1, asCi[i], cached);
        CryptoOps.geP3ToCached(cached, asCi[i]);
        CryptoOps.geP1P1ToP3(cIH[i], p1);
        CryptoOps.geAdd(p1, ctempP3, cached);
        CryptoOps.geP1P1ToP3(ctempP3, p1);
      }
      final RctKey cTemp = RCT.zero();
      CryptoOps.geP3Tobytes(cTemp, ctempP3);
      if (!BytesUtils.bytesEqual(C, cTemp)) return false;
      if (!verifyBorromean(as.asig, asCi, cIH)) return false;
      return true;
    } catch (_) {
      return false;
    }
  }
}
