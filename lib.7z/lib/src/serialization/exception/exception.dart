import 'package:monero_dart/src/exception/exception.dart';

class MoneroSerializationException extends DartMoneroPluginException {
  const MoneroSerializationException(String message,
      {Map<String, dynamic>? details})
      : super(message, details: details);
}
