import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:monero_dart/src/serialization/exception/exception.dart';
import 'package:monero_dart/src/serialization/storage_format/constant/constant.dart';
import 'package:monero_dart/src/serialization/storage_format/tools/serializer.dart';
import 'package:monero_dart/src/serialization/storage_format/types/types.dart';
import 'package:monero_dart/src/serialization/storage_format/tools/validator.dart';

class MoneroStorage {
  factory MoneroStorage.fromJson(Map<String, dynamic> json) {
    return MoneroStorage(MoneroSection.fromJson(json));
  }
  factory MoneroStorage.deserialize(List<int> bytes) {
    return MoneroStorage(
        MoneroSection.fromJson(MoneroStorageSerializer.deserialize(bytes)));
  }
  final MoneroSection section;
  const MoneroStorage(this.section);
  List<int> serialize() {
    return [
      ...MoneroSerializationConst.signaturePartBAndVersionVersion,
      ...section.serialize()
    ];
  }

  String serializeHex() {
    return BytesUtils.toHexString(serialize());
  }
}

class MoneroSection {
  final List<MoneroStorageEntry> enteries;
  MoneroSection(List<MoneroStorageEntry> enteries)
      : enteries = enteries.immutable;

  factory MoneroSection.fromJson(Map<String, dynamic> json) {
    final sortedMap = json.keys.toList()..sort();
    return MoneroSection(sortedMap
        .map((k) => MoneroStorageEntry.fromObject(name: k, value: json[k]))
        .toList());
  }
  bool get hasValue {
    final enteries = this.enteries.where((e) => e.hasValue);
    return enteries.isNotEmpty;
  }

  List<int> serialize() {
    final enteries = this.enteries.where((e) => e.hasValue);
    return [
      ...MoneroStorageSerializer.encodeVarintInt(enteries.length),
      ...enteries.expand((e) => e.serialize())
    ];
  }

  String serializeHex() {
    return BytesUtils.toHexString(serialize());
  }
}

abstract class MoneroStorageEntry<T> {
  final T value;
  final String name;
  final MoneroStorageTypes type;
  bool get hasValue => value != null;
  MoneroStorageEntry(
      {required this.type, required String name, required this.value})
      : name = MoneroStorageFormatValidator.asValidName(name);
  factory MoneroStorageEntry.fromObject({required String name, Object? value}) {
    final MoneroStorageEntry entry;
    if (value == null) {
      entry = MoneroStorageEntryNull(name);
    } else {
      final type = MoneroStorageFormatValidator.findType(value);

      if (type.isPrimitive) {
        entry = MoneroStorageEntryPromitive(name: name, value: value);
      } else if (type == MoneroStorageTypes.object) {
        entry = MoneroStorageEntrySection(
            json: MoneroStorageFormatValidator.asMap(value), name: name);
      } else {
        final list = MoneroStorageFormatValidator.asArrayOf<Object>(value,
            allowEmpty: true);
        if (list.isEmpty) {
          entry = MoneroStorageEntryNull(name);
        } else {
          entry = MoneroStorageEntryList(name: name, value: list);
        }
      }
    }
    if (entry is! MoneroStorageEntry<T>) {
      throw MoneroSerializationException(
          "Incorrect MoneroStorageEntry<$T> type",
          details: {"excepted": "$T", "entery": entry.runtimeType});
    }
    return entry;
  }

  List<int> serialize();
  String serializeHex() {
    return BytesUtils.toHexString(serialize());
  }
}

class MoneroStorageEntryNull extends MoneroStorageEntry<Null> {
  MoneroStorageEntryNull._({
    required String name,
  }) : super(name: name, type: MoneroStorageTypes.unknown, value: null);
  factory MoneroStorageEntryNull(String name) {
    return MoneroStorageEntryNull._(name: name);
  }

  @override
  List<int> serialize() {
    return [0x00];
  }
}

class MoneroStorageEntryPromitive<T> extends MoneroStorageEntry<T> {
  MoneroStorageEntryPromitive._(
      {required String name,
      required MoneroStorageTypes type,
      required T value})
      : super(name: name, type: type, value: value);
  factory MoneroStorageEntryPromitive(
      {required String name, required T value}) {
    final correctValue = MoneroStorageFormatValidator.asPrimitiveType<T>(value);
    return MoneroStorageEntryPromitive._(
        name: name, type: correctValue.item2, value: correctValue.item1);
  }

  @override
  List<int> serialize() {
    return [
      name.length,
      ...StringUtils.encode(name),
      ...MoneroStorageSerializer.encodePrimitive(type: type, value: value!)
    ];
  }
}

class MoneroStorageEntryList<T extends Object>
    extends MoneroStorageEntry<List<T>> {
  final MoneroStorageTypes childType;
  MoneroStorageEntryList._(
      {required String name,
      required this.childType,
      required MoneroStorageTypes type,
      required List<T> value})
      : super(name: name, type: type, value: value);
  factory MoneroStorageEntryList(
      {required String name, required List<T> value}) {
    final values = MoneroStorageFormatValidator.toArrayObject<T>(value);
    return MoneroStorageEntryList._(
        name: name,
        childType: values.item1,
        type: MoneroStorageTypes.array,
        value: values.item2);
  }
  @override
  bool get hasValue => value.isNotEmpty;
  @override
  List<int> serialize() {
    return [
      name.length,
      ...StringUtils.encode(name),
      ...MoneroStorageSerializer.encodeList(childType: childType, value: value)
    ];
  }
}

class MoneroStorageEntrySection extends MoneroStorageEntry<MoneroSection> {
  MoneroStorageEntrySection._(
      {required String name,
      required MoneroStorageTypes type,
      required MoneroSection value})
      : super(name: name, type: type, value: value);
  factory MoneroStorageEntrySection(
      {required Map<String, dynamic> json, required String name}) {
    return MoneroStorageEntrySection._(
        name: name,
        type: MoneroStorageTypes.object,
        value: MoneroSection.fromJson(json));
  }

  @override
  List<int> serialize() {
    if (!value.hasValue) return [0x00];
    return [
      name.length,
      ...StringUtils.encode(name),
      MoneroStorageTypes.object.flag,
      ...value.serialize(),
    ];
  }
}
