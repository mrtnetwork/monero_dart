import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:monero_dart/src/serialization/storage_format/tools/serializer.dart';
import 'package:monero_dart/src/serialization/storage_format/types/types.dart';

abstract class MoneroStorageContainer {
  final MoneroStorageTypes type;
  const MoneroStorageContainer(this.type);
  List<int> serialize();
}

class MoneroStorageBinary extends MoneroStorageContainer {
  final List<int> data;
  MoneroStorageBinary(List<int> data)
      : data = data.asImmutableBytes,
        super(MoneroStorageTypes.string);

  @override
  List<int> serialize() {
    return [...MoneroStorageSerializer.encodeVarintInt(data.length), ...data];
  }
}

class MoneroStorageBinaryHex extends MoneroStorageContainer {
  final List<int> data;
  MoneroStorageBinaryHex(List<String> data)
      : data = data
            .map((e) => BytesUtils.fromHexString(e).immutable)
            .expand((e) => e)
            .immutable,
        super(MoneroStorageTypes.string);

  @override
  List<int> serialize() {
    if (data.isEmpty) return [];
    return [
      ...MoneroStorageSerializer.encodeVarintInt(data.length),
      ...data
    ];
  }
}
