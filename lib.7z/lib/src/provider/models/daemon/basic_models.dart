
import 'package:blockchain_utils/helper/helper.dart';
import 'package:blockchain_utils/utils/utils.dart';

class DaemonBaseResponse {
  final BigInt? credits;
  final String status;
  final String? topHash;
  final bool? untrusted;
  const DaemonBaseResponse(
      {required this.credits,
      required this.status,
      required this.topHash,
      required this.untrusted});
  DaemonBaseResponse.fromJson(Map<String, dynamic> json)
      : credits = BigintUtils.tryParse(json["credits"]),
        status = json["status"],
        topHash = json["top_hash"],
        untrusted = json["untrusted"];

  bool get isOk => status == "OK";
}

abstract class DaemonBaseParams {
  Map<String, dynamic> toJson();
  const DaemonBaseParams();
}

class DaemonBannedResponse extends DaemonBaseResponse {
  final bool banned;
  final int seconds;
  DaemonBannedResponse.fromJson(Map<String, dynamic> json)
      : banned = json["banned"],
        seconds = json["seconds"] ?? 0,
        super.fromJson(json);
}

class DaemonChainInfo {
  final String blockHash;
  final BigInt height;
  final BigInt length;
  final BigInt difficulty;
  final String wideDifficulty;
  final BigInt difficultyTop64;
  final List<String> blockHashes;
  final String mainChainParentBlock;

  // fromJson constructor
  DaemonChainInfo.fromJson(Map<String, dynamic> json)
      : blockHash = json['block_hash'],
        height = BigintUtils.parse(json['height']),
        length = BigintUtils.parse(json['length']),
        difficulty = BigintUtils.parse(json['difficulty']),
        wideDifficulty = json['wide_difficulty'],
        difficultyTop64 = BigintUtils.parse(json['difficulty_top64']),
        blockHashes = List<String>.from(json['block_hashes']),
        mainChainParentBlock = json['main_chain_parent_block'];
}

class DaemonGetAlternateChainsResponse extends DaemonBaseResponse {
  /// unsigned int; Number of blocks in longest chain seen by the node.
  final List<DaemonChainInfo> chains;

  DaemonGetAlternateChainsResponse.fromJson(Map<String, dynamic> json)
      : chains = (json["chains"] as List?)
                ?.map((e) => DaemonChainInfo.fromJson(e))
                .toImutableList ??
            [],
        super.fromJson(json);
}

class DaemonSyncInfoResponse extends DaemonBaseResponse {
  final DaemonConnectionInfoResponse info;

  DaemonSyncInfoResponse.fromJson(Map<String, dynamic> json)
      : info = DaemonConnectionInfoResponse.fromJson(json["info"]),
        super.fromJson(json);
}

class DaemonCoinbaseTxSumResponse extends DaemonBaseResponse {
  final BigInt emissionAmount;
  final String wideEmissionAmount;
  final BigInt emissionAmountTop64;
  final BigInt feeAmount;
  final String wideFeeAmount;
  final BigInt feeAmountTop64;

  // fromJson constructor
  DaemonCoinbaseTxSumResponse.fromJson(Map<String, dynamic> json)
      : emissionAmount = BigintUtils.parse(json['emission_amount']),
        wideEmissionAmount = json['wide_emission_amount'],
        emissionAmountTop64 = BigintUtils.parse(json['emission_amount_top64']),
        feeAmount = BigintUtils.parse(json['fee_amount']),
        wideFeeAmount = json['wide_fee_amount'],
        feeAmountTop64 = BigintUtils.parse(json['fee_amount_top64']),
        super.fromJson(json);
}

class DaemonGetBlockCountResponse extends DaemonBaseResponse {
  /// unsigned int; Number of blocks in longest chain seen by the node.
  final int count;

  DaemonGetBlockCountResponse.fromJson(Map<String, dynamic> json)
      : count = IntUtils.parse(json["count"]),
        super.fromJson(json);
}

class DaemonGenerateBlockResponse extends DaemonBaseResponse {
  /// unsigned int; Number of blocks in longest chain seen by the node.
  final List<String> blocks;
  final BigInt height;
  DaemonGenerateBlockResponse(
      {required List<String> blocks,
      required this.height,
      required BigInt? credits,
      required String status,
      required String? topHash,
      required bool untrusted})
      : blocks = blocks.immutable,
        super(
            credits: credits,
            status: status,
            topHash: topHash,
            untrusted: untrusted);
  DaemonGenerateBlockResponse.fromJson(Map<String, dynamic> json)
      : blocks = (json["count"] as List).cast<String>().immutable,
        height = BigintUtils.parse(json["height"]),
        super.fromJson(json);
}

class DaemonTxBacklogEntry {
  final String id;
  final BigInt weight;
  final BigInt fee;

  DaemonTxBacklogEntry.fromJson(Map<String, dynamic> json)
      : id = json['id'],
        weight = BigintUtils.parse(json['weight']),
        fee = BigintUtils.parse(json['fee']);
}

class DaemonGetTxPoolBackLogResponse extends DaemonBaseResponse {
  final List<DaemonTxBacklogEntry> backlog;

  DaemonGetTxPoolBackLogResponse.fromJson(Map<String, dynamic> json)
      : backlog = (json["backlog"] as List)
            .map((e) => DaemonTxBacklogEntry.fromJson(e))
            .toImutableList,
        super.fromJson(json);
}

class DaemonGetMinerDataResponse extends DaemonBaseResponse {
  final int majorVersion;
  final BigInt height;
  final String prevId;
  final String seedHash;
  final String difficulty;
  final BigInt medianWeight;
  final BigInt alreadyGeneratedCoins;
  final List<DaemonTxBacklogEntry> txBacklog;
  // fromJson constructor
  DaemonGetMinerDataResponse.fromJson(Map<String, dynamic> json)
      : majorVersion = json['major_version'],
        height = BigintUtils.parse(json['height']),
        prevId = json['prev_id'],
        seedHash = json['seed_hash'],
        difficulty = json['difficulty'],
        medianWeight = BigintUtils.parse(json['median_weight']),
        alreadyGeneratedCoins =
            BigRational.parseDecimal(json['already_generated_coins'].toString())
                .toBigInt(),
        txBacklog = (json["tx_backlog"] as List?)
                ?.map((e) => DaemonTxBacklogEntry.fromJson(e))
                .toImutableList ??
            [],
        super.fromJson(json);
}

class DaemonPruneBlockchainResponse extends DaemonBaseResponse {
  final bool pruned;
  final BigInt pruningSeed;
  DaemonPruneBlockchainResponse.fromJson(Map<String, dynamic> json)
      : pruned = json['pruned'],
        pruningSeed = BigintUtils.parse(json['pruning_seed']),
        super.fromJson(json);
}

class DaemonAddAuxPowResponse extends DaemonBaseResponse {
  final String blocktemplateBlob;
  final String blockhashingBlob;
  final String merkleRoot;
  final BigInt merkleTreeDepth;
  final List<DaemonAuxPowParams> auxPow;
  DaemonAddAuxPowResponse.fromJson(Map<String, dynamic> json)
      : blocktemplateBlob = json['blocktemplate_blob'],
        blockhashingBlob = json["blockhashing_blob"],
        merkleRoot = json["merkle_root"],
        merkleTreeDepth = BigintUtils.parse(json['merkle_tree_depth']),
        auxPow = (json["aux_pow"] as List?)
                ?.map((e) => DaemonAuxPowParams.fromJson(e))
                .toImutableList ??
            [],
        super.fromJson(json);
}

class DaemonGetHashesBinResponse extends DaemonBaseResponse {
  final BigInt startHeight;
  final BigInt currentHeight;
  final List<String> mBlockIds;

  DaemonGetHashesBinResponse.fromJson(Map<String, dynamic> json)
      : mBlockIds = (json["mBlockIds"] as List).cast<String>().toImutableList,
        currentHeight = BigintUtils.parse(json["current_height"]),
        startHeight = BigintUtils.parse(json["start_height"]),
        super.fromJson(json);
}

class DaemonPublicNodeResponse {
  final String host;
  final BigInt lastSeen;
  final int port;
  final int rpcCreditsPerHash;

  DaemonPublicNodeResponse.fromJson(Map<String, dynamic> json)
      : host = json["host"],
        lastSeen = BigintUtils.parse(json["last_seen"]),
        port = json["rpc_port"],
        rpcCreditsPerHash = json["rpc_credits_per_hash"];
}

class DaemonGetPublicNodeResponse extends DaemonBaseResponse {
  final List<DaemonPublicNodeResponse> white;
  final List<DaemonPublicNodeResponse> gray;

  DaemonGetPublicNodeResponse.fromJson(Map<String, dynamic> json)
      : white = (json["white"] as List?)
                ?.map((e) => DaemonPublicNodeResponse.fromJson(e))
                .toImutableList ??
            [],
        gray = (json["gray"] as List?)
                ?.map((e) => DaemonPublicNodeResponse.fromJson(e))
                .toImutableList ??
            [],
        super.fromJson(json);
}

class DaemonGetTransactionPoolHashesResponse extends DaemonBaseResponse {
  final List<String> txHashes;

  DaemonGetTransactionPoolHashesResponse.fromJson(Map<String, dynamic> json)
      : txHashes = (json["tx_hashes"] as List).cast(),
        super.fromJson(json);
}

class DaemonPopBlocksResponse extends DaemonBaseResponse {
  final BigInt height;

  DaemonPopBlocksResponse.fromJson(Map<String, dynamic> json)
      : height = BigintUtils.parse(json["height"]),
        super.fromJson(json);
}

class DaemonUpdateResponse extends DaemonBaseResponse {
  final bool update;
  final String version;
  final String userUri;
  final String autoUri;
  final String hash;
  final String path;

  DaemonUpdateResponse.fromJson(Map<String, dynamic> json)
      : update = json["update"],
        version = json["version"],
        userUri = json["user_uri"],
        autoUri = json["auto_uri"],
        path = json["path"],
        hash = json["hash"],
        super.fromJson(json);
}

class DaemonGetNetStatsResponse extends DaemonBaseResponse {
  final BigInt startTime;
  final BigInt totalPacketsIn;
  final BigInt totalBytesIn;
  final BigInt totalPacketsOut;
  final BigInt totalBytesOut;

  DaemonGetNetStatsResponse.fromJson(Map<String, dynamic> json)
      : startTime = BigintUtils.parse(json["start_time"]),
        totalPacketsIn = BigintUtils.parse(json["total_packets_in"]),
        totalBytesIn = BigintUtils.parse(json["total_bytes_in"]),
        totalPacketsOut = BigintUtils.parse(json["total_packets_out"]),
        totalBytesOut = BigintUtils.parse(json["total_bytes_out"]),
        super.fromJson(json);
}

class DaemonInPeersResponse extends DaemonBaseResponse {
  final int inPeers;

  DaemonInPeersResponse.fromJson(Map<String, dynamic> json)
      : inPeers = json["in_peers"],
        super.fromJson(json);
}

class DaemonOutPeersResponse extends DaemonBaseResponse {
  final int outPeers;

  DaemonOutPeersResponse.fromJson(Map<String, dynamic> json)
      : outPeers = json["out_peers"],
        super.fromJson(json);
}

class DaemonLimitResponse extends DaemonBaseResponse {
  final BigInt limitDown;
  final BigInt limitUp;

  DaemonLimitResponse.fromJson(Map<String, dynamic> json)
      : limitDown = BigintUtils.parse(json["limit_down"]),
        limitUp = BigintUtils.parse(json["limit_up"]),
        super.fromJson(json);
}

class DaemonTxPoolHistoResponse {
  final int txs;
  final BigInt bytes;

  DaemonTxPoolHistoResponse.fromJson(Map<String, dynamic> json)
      : txs = json["txs"],
        bytes = BigintUtils.parse(json["bytes"]);
}

class DaemonTxPoolStatsResponse {
  final BigInt bytesTotal;
  final int bytesMin;
  final int bytesMax;
  final int bytesMed;
  final BigInt feeTotal;
  final BigInt oldest;
  final int txsTotal;
  final int numFailing;
  final int num10m;
  final int numNotRelayed;
  final BigInt histo_98pc;
  final List<DaemonTxPoolHistoResponse> histo;
  final int numDoubleSpends;

  DaemonTxPoolStatsResponse.fromJson(Map<String, dynamic> json)
      : bytesTotal = BigintUtils.parse(json["bytes_total"]),
        bytesMin = json["bytes_min"],
        bytesMax = json["bytes_max"],
        bytesMed = json["bytes_med"],
        txsTotal = json["txs_total"],
        numFailing = json["num_failing"],
        num10m = json["num_10m"],
        numNotRelayed = json["num_not_relayed"],
        numDoubleSpends = json["num_double_spends"],
        feeTotal = BigintUtils.parse(json["fee_total"]),
        oldest = BigintUtils.parse(json["oldest"]),
        histo_98pc = BigintUtils.parse(json["histo_98pc"]),
        histo = (json["histo"] as List?)
                ?.map((e) => DaemonTxPoolHistoResponse.fromJson(e))
                .toImutableList ??
            [];
}

class DaemonGetTransactionPoolStatsResponse extends DaemonBaseResponse {
  final DaemonTxPoolStatsResponse poolStats;

  DaemonGetTransactionPoolStatsResponse.fromJson(Map<String, dynamic> json)
      : poolStats = DaemonTxPoolStatsResponse.fromJson(json["pool_stats"]),
        super.fromJson(json);
}

class DaemonSetLogCategoriesResponse extends DaemonBaseResponse {
  final String categories;

  DaemonSetLogCategoriesResponse.fromJson(Map<String, dynamic> json)
      : categories = json["categories"],
        super.fromJson(json);
}

class DaemonPeerResponse {
  final BigInt id;
  final String host;
  final int ip;
  final int port;
  final int rpcPort;
  final int rpcCreditsPerHash;
  final int pruningSeed;
  final BigInt lastSeen;

  DaemonPeerResponse.fromJson(Map<String, dynamic> json)
      : id = BigintUtils.parse(json["id"]),
        host = json["host"],
        ip = json["ip"],
        port = json["port"],
        rpcPort = json["rpc_port"],
        rpcCreditsPerHash = json["rpc_credits_per_hash"],
        pruningSeed = json["pruning_seed"],
        lastSeen = BigintUtils.parse(json["last_seen"]);
}

class DaemonGetPeerListResponse extends DaemonBaseResponse {
  final List<DaemonPeerResponse> whiteList;
  final List<DaemonPeerResponse> grayList;
  DaemonGetPeerListResponse.fromJson(Map<String, dynamic> json)
      : whiteList = (json["white_list"] as List?)
                ?.map((e) => DaemonPeerResponse.fromJson(e))
                .toImutableList ??
            [],
        grayList = (json["gray_list"] as List?)
                ?.map((e) => DaemonPeerResponse.fromJson(e))
                .toImutableList ??
            [],
        super.fromJson(json);
}

class DaemonMininStatusResponse extends DaemonBaseResponse {
  final bool active;
  final BigInt speed;
  final int threadsCount;
  final String address;
  final String powAlgorithm;
  bool isBackgroundMiningEnabled;
  final int bgIdleThreshold;
  final int bgMinIdleSeconds;
  bool bgIgnoreBattery;
  final int bgTarget;
  final int blockTarget;
  final BigInt blockReward;
  final BigInt difficulty;
  final String wideDifficulty;
  final BigInt difficultyTop64;

  DaemonMininStatusResponse.fromJson(Map<String, dynamic> json)
      : active = json['active'],
        speed = BigintUtils.parse(json['speed']),
        threadsCount = json['threads_count'],
        address = json['address'],
        powAlgorithm = json['pow_algorithm'],
        isBackgroundMiningEnabled = json['is_background_mining_enabled'],
        bgIdleThreshold = json['bg_idle_threshold'],
        bgMinIdleSeconds = json['bg_min_idle_seconds'],
        bgIgnoreBattery = json['bg_ignore_battery'],
        bgTarget = json['bg_target'],
        blockTarget = json['block_target'],
        blockReward = BigintUtils.parse(json['block_reward']),
        difficulty = BigintUtils.parse(json['difficulty']),
        wideDifficulty = json['wide_difficulty'],
        difficultyTop64 = BigintUtils.parse(json['difficulty_top64']),
        super.fromJson(json);
}

enum DaemonKeyImageSpentStatus {
  unspent,
  spentInBlockchain,
  spentInPool,
}

class DaemonIsKeyImageSpentResponse extends DaemonBaseResponse {
  final List<DaemonKeyImageSpentStatus> spentStatus;

  DaemonIsKeyImageSpentResponse.fromJson(Map<String, dynamic> json)
      : spentStatus = (json["spent_status"] as List)
            .cast<int>()
            .map((e) => DaemonKeyImageSpentStatus.values.elementAt(e))
            .toImutableList,
        super.fromJson(json);
}

class DaemonGetAltBlockHashesResponse extends DaemonBaseResponse {
  final List<String> blksHashes;

  DaemonGetAltBlockHashesResponse.fromJson(Map<String, dynamic> json)
      : blksHashes =
            (json["blks_hashes"] as List).cast<String>().toImutableList,
        super.fromJson(json);
}

class DaemonSendRawTxResponse extends DaemonBaseResponse {
  final String reason;
  final bool notRelayed;
  final bool lowMixin;
  final bool doubleSpend;
  final bool invalidInput;
  final bool invalidOutput;
  final bool tooBig;
  final bool overspend;
  final bool feeTooLow;
  final bool tooFewOutputs;
  final bool sanityCheckFailed;
  final bool txExtraTooBig;
  final bool nonzeroUnlockTime;

  DaemonSendRawTxResponse.fromJson(Map<String, dynamic> json)
      : reason = json['reason'] ?? '',
        notRelayed = json['not_relayed'] ?? false,
        lowMixin = json['low_mixin'] ?? false,
        doubleSpend = json['double_spend'] ?? false,
        invalidInput = json['invalid_input'] ?? false,
        invalidOutput = json['invalid_output'] ?? false,
        tooBig = json['too_big'] ?? false,
        overspend = json['overspend'] ?? false,
        feeTooLow = json['fee_too_low'] ?? false,
        tooFewOutputs = json['too_few_outputs'] ?? false,
        sanityCheckFailed = json['sanity_check_failed'] ?? false,
        txExtraTooBig = json['tx_extra_too_big'] ?? false,
        nonzeroUnlockTime = json['nonzero_unlock_time'] ?? false,
        super.fromJson(json);
}

class DaemonGetTxGlobalOutputIndexesResponse extends DaemonBaseResponse {
  final List<BigInt> oIndexes;

  DaemonGetTxGlobalOutputIndexesResponse.fromJson(Map<String, dynamic> json)
      : oIndexes = (json["o_indexes"] as List)
            .map((e) => BigintUtils.parse(e))
            .toImutableList,
        super.fromJson(json);
}

class DaemonBanParams extends DaemonBaseParams {
  final String host;
  final int ip;
  final bool ban;
  final int seconds;
  const DaemonBanParams(
      {required this.host,
      required this.ip,
      required this.ban,
      required this.seconds});
  factory DaemonBanParams.fromJson(Map<String, dynamic> json) {
    return DaemonBanParams(
        host: json["host"],
        ip: json["ip"],
        ban: json["ban"] ?? true,
        seconds: json["seconds"]);
  }
  @override
  Map<String, dynamic> toJson() {
    return {"host": host, "ip": ip, "ban": ban, "seconds": seconds};
  }
}

class DaemonGetBanResponse extends DaemonBaseResponse {
  final List<DaemonBanParams> bans;

  DaemonGetBanResponse.fromJson(Map<String, dynamic> json)
      : bans = (json["bans"] as List?)
                ?.map((e) => DaemonBanParams.fromJson(e))
                .toImutableList ??
            [],
        super.fromJson(json);
}

class DaemonGetLastBlockHeaderResponse extends DaemonBaseResponse {
  final DaemonBlockHeaderResponse blockHeader;

  DaemonGetLastBlockHeaderResponse.fromJson(Map<String, dynamic> json)
      : blockHeader = DaemonBlockHeaderResponse.fromJson(json["block_header"]),
        super.fromJson(json);
}

class DaemonGetBlockResponse extends DaemonBaseResponse {
  final DaemonBlockHeaderResponse blockHeader;
  final List<String> txHashes;
  final String blob;
  final String json;
  DaemonGetBlockResponse.fromJson(Map<String, dynamic> json)
      : blockHeader = DaemonBlockHeaderResponse.fromJson(json["block_header"]),
        txHashes = (json["tx_hashes"] as List).cast<String>().toImutableList,
        blob = json["blob"],
        json = json["json"],
        super.fromJson(json);
}

class DaemonBlockHeadersResponse extends DaemonBaseResponse {
  final DaemonBlockHeaderResponse? blockHeader;
  final List<DaemonBlockHeaderResponse> blockHeaders;

  DaemonBlockHeadersResponse.fromJson(Map<String, dynamic> json)
      : blockHeader = json["block_header"] == null
            ? null
            : DaemonBlockHeaderResponse.fromJson(json["block_header"]),
        blockHeaders = (json["block_headers"] as List?)
                ?.map((e) => DaemonBlockHeaderResponse.fromJson(e))
                .toImutableList ??
            [],
        super.fromJson(json);
}

class DaemonBlockHeadersByRangeResponse extends DaemonBaseResponse {
  final List<DaemonBlockHeaderResponse> headers;

  DaemonBlockHeadersByRangeResponse.fromJson(Map<String, dynamic> json)
      : headers = (json["headers"] as List)
            .map((e) => DaemonBlockHeaderResponse.fromJson(e))
            .toImutableList,
        super.fromJson(json);
}

class DaemonBlockHeaderResponse {
  final int majorVersion;
  final int minorVersion;
  final BigInt timestamp;
  final String prevHash;
  final int nonce;
  final bool orphanStatus;
  final BigInt height;
  final BigInt depth;
  final String hash;
  final BigInt difficulty;
  final String wideDifficulty;
  final BigInt difficultyTop64;
  final BigInt cumulativeDifficulty;
  final String wideCumulativeDifficulty;
  final BigInt cumulativeDifficultyTop64;
  final BigInt reward;
  final BigInt blockSize;
  final BigInt blockWeight;
  final BigInt numTxes;
  final String powHash;
  final BigInt longTermWeight;
  final String minerTxHash;

  // fromJson constructor
  DaemonBlockHeaderResponse.fromJson(Map<String, dynamic> json)
      : majorVersion = json['major_version'],
        minorVersion = json['minor_version'],
        timestamp = BigintUtils.parse(json['timestamp']),
        prevHash = json['prev_hash'],
        nonce = json['nonce'],
        orphanStatus = json['orphan_status'],
        height = BigintUtils.parse(json['height']),
        depth = BigintUtils.parse(json['depth']),
        hash = json['hash'],
        difficulty = BigintUtils.parse(json['difficulty']),
        wideDifficulty = json['wide_difficulty'],
        difficultyTop64 = BigintUtils.parse(json['difficulty_top64']),
        cumulativeDifficulty = BigintUtils.parse(json['cumulative_difficulty']),
        wideCumulativeDifficulty = json['wide_cumulative_difficulty'],
        cumulativeDifficultyTop64 =
            BigintUtils.parse(json['cumulative_difficulty_top64']),
        reward = BigintUtils.parse(json['reward']),
        blockSize = BigintUtils.tryParse(json['block_size']) ?? BigInt.zero,
        blockWeight = BigintUtils.tryParse(json['block_weight']) ?? BigInt.zero,
        numTxes = BigintUtils.parse(json['num_txes']),
        powHash = json['pow_hash'],
        longTermWeight =
            BigintUtils.tryParse(json['long_term_weight']) ?? BigInt.zero,
        minerTxHash = json['miner_tx_hash'];
}

class DaemonHFEnteryResponse {
  final int hfVersion;
  final BigInt height;
  const DaemonHFEnteryResponse({required this.height, required this.hfVersion});
  factory DaemonHFEnteryResponse.fromJson(Map<String, dynamic> json) {
    return DaemonHFEnteryResponse(
        height: BigintUtils.parse(json["height"]),
        hfVersion: json["hf_version"]);
  }
}

class DaemonGetVersionResponse extends DaemonBaseResponse {
  final int version;
  final bool release;
  final BigInt currentHeight;
  final BigInt targetHeight;
  final List<DaemonHFEnteryResponse> hardForks;
  DaemonGetVersionResponse.fromJson(Map<String, dynamic> json)
      : version = json["version"],
        release = json["release"],
        currentHeight =
            BigintUtils.tryParse(json["current_height"]) ?? BigInt.zero,
        targetHeight =
            BigintUtils.tryParse(json["target_height"]) ?? BigInt.zero,
        hardForks = (json["hardForks"] as List?)
                ?.map((e) => DaemonHFEnteryResponse.fromJson(e))
                .toImutableList ??
            [],
        super.fromJson(json);
}

class DaemonGetOutputHistogramResponse extends DaemonBaseResponse {
  final List<DaemonHistogramResponse> histogram;
  DaemonGetOutputHistogramResponse.fromJson(Map<String, dynamic> json)
      : histogram = (json["histogram"] as List?)
                ?.map((e) => DaemonHistogramResponse.fromJson(e))
                .toList() ??
            [],
        super.fromJson(json);
}

class DaemonHistogramResponse {
  final BigInt amount;
  final BigInt recentInstances;
  final BigInt totalInstances;
  final BigInt unlockedInstances;
  const DaemonHistogramResponse(
      {required this.amount,
      required this.recentInstances,
      required this.totalInstances,
      required this.unlockedInstances});
  factory DaemonHistogramResponse.fromJson(Map<String, dynamic> json) {
    return DaemonHistogramResponse(
      amount: BigintUtils.parse(json["amount"]),
      recentInstances: BigintUtils.parse(json["recent_instances"]),
      totalInstances: BigintUtils.parse(json["total_instances"]),
      unlockedInstances: BigintUtils.parse(json["unlocked_instances"]),
    );
  }
}

class DaemonGetBlockHeightResponse extends DaemonBaseResponse {
  final String hash;
  final int height;
  DaemonGetBlockHeightResponse({
    required this.hash,
    required this.height,
    required BigInt credits,
    required String status,
    required String topHash,
    required bool untrusted,
  }) : super(
            credits: credits,
            status: status,
            topHash: topHash,
            untrusted: untrusted);
  DaemonGetBlockHeightResponse.fromJson(Map<String, dynamic> json)
      : hash = json["hash"],
        height = IntUtils.parse(json["height"]),
        super.fromJson(json);
}

class DaemonHardForkResponse extends DaemonBaseResponse {
  int earliestHeight;
  bool enabled;
  int state;
  int threshold;
  int version;
  int votes;
  int voting;
  int window;

  DaemonHardForkResponse({
    required BigInt? credits,
    required this.earliestHeight,
    required this.enabled,
    required this.state,
    required String status,
    required this.threshold,
    required String? topHash,
    required bool untrusted,
    required this.version,
    required this.votes,
    required this.voting,
    required this.window,
  }) : super(
            credits: credits,
            status: status,
            topHash: topHash,
            untrusted: untrusted);

  DaemonHardForkResponse.fromJson(Map<String, dynamic> json)
      : earliestHeight = json['earliest_height'],
        enabled = json['enabled'],
        state = json['state'],
        threshold = json['threshold'],
        version = json['version'],
        votes = json['votes'],
        voting = json['voting'],
        window = json['window'],
        super.fromJson(json);
}

class DaemonAuxPowParams extends DaemonBaseParams {
  final String id;
  final String hash;
  const DaemonAuxPowParams({required this.id, required this.hash});
  factory DaemonAuxPowParams.fromJson(Map<String, dynamic> json) {
    return DaemonAuxPowParams(id: json["id"], hash: json["hash"]);
  }

  @override
  Map<String, dynamic> toJson() {
    return {"id": id, "hash": hash};
  }
}

class DaemonGetConnectionsResponse extends DaemonBaseResponse {
  final List<DaemonConnectionInfoResponse> connections;

  DaemonGetConnectionsResponse.fromJson(Map<String, dynamic> json)
      : connections = (json["connections"] as List)
            .map((e) => DaemonConnectionInfoResponse.fromJson(e))
            .toImutableList,
        super.fromJson(json);
}

class DaemonConnectionInfoResponse {
  final bool incoming;
  final bool localhost;
  final bool localIp;
  final bool ssl;

  final String address;
  final String host;
  final String ip;
  final String port;
  final int rpcPort;
  final int rpcCreditsPerHash;

  final String peerId;

  final BigInt recvCount;
  final BigInt recvIdleTime;

  final BigInt sendCount;
  final BigInt sendIdleTime;

  final String state;

  final BigInt liveTime;

  final BigInt avgDownload;
  final BigInt currentDownload;

  final BigInt avgUpload;
  final BigInt currentUpload;

  final int supportFlags;

  final String connectionId;

  final BigInt height;

  final int pruningSeed;

  final int addressType;

  // fromJson constructor
  DaemonConnectionInfoResponse.fromJson(Map<String, dynamic> json)
      : incoming = json['incoming'],
        localhost = json['localhost'],
        localIp = json['local_ip'],
        ssl = json['ssl'],
        address = json['address'],
        host = json['host'],
        ip = json['ip'],
        port = json['port'],
        rpcPort = json['rpc_port'],
        rpcCreditsPerHash = json['rpc_credits_per_hash'],
        peerId = json['peer_id'],
        recvCount = BigintUtils.parse(json['recv_count']),
        recvIdleTime = BigintUtils.parse(json['recv_idle_time']),
        sendCount = BigintUtils.parse(json['send_count']),
        sendIdleTime = BigintUtils.parse(json['send_idle_time']),
        state = json['state'],
        liveTime = BigintUtils.parse(json['live_time']),
        avgDownload = BigintUtils.parse(json['avg_download']),
        currentDownload = BigintUtils.parse(json['current_download']),
        avgUpload = BigintUtils.parse(json['avg_upload']),
        currentUpload = BigintUtils.parse(json['current_upload']),
        supportFlags = json['support_flags'],
        connectionId = json['connection_id'],
        height = BigintUtils.parse(json['height']),
        pruningSeed = json['pruning_seed'],
        addressType = json['address_type'];
}

class DaemonGetEstimateFeeResponse extends DaemonBaseResponse {
  final BigInt fee;
  final List<BigInt> fees;
  final BigInt quantizationMask;
  DaemonGetEstimateFeeResponse.fromJson(Map<String, dynamic> json)
      : fee = BigintUtils.parse(json["fee"]),
        fees = (json["fees"] as List)
            .map((e) => BigintUtils.parse(e))
            .toImutableList,
        quantizationMask = BigintUtils.parse(json["quantization_mask"]),
        super.fromJson(json);
  DaemonGetEstimateFeeResponse(
      {required this.fee,
      required List<BigInt> fees,
      required this.quantizationMask,
      required BigInt? credits,
      required String status,
      required String? topHash,
      required bool untrusted})
      : fees = fees.immutable,
        super(
            credits: credits,
            status: status,
            topHash: topHash,
            untrusted: untrusted);
}

class DaemonGetOutRequestParams {
  final BigInt amount;
  final BigInt index;
  const DaemonGetOutRequestParams({required this.amount, required this.index});
  factory DaemonGetOutRequestParams.fromJson(Map<String, dynamic> json) {
    return DaemonGetOutRequestParams(
        amount: BigintUtils.parse(json["amount"]),
        index: BigintUtils.parse(json["index"]));
  }
  Map<String, dynamic> toJson() {
    return {"amount": amount.toString(), "index": index.toString()};
  }
}
