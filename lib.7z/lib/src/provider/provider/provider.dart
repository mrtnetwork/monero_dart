import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:monero_dart/src/provider/core/core.dart';
import 'package:monero_dart/src/provider/service/service.dart';
import 'package:monero_dart/src/serialization/storage_format/tools/serializer.dart';

/// Facilitates communication with the monero deamon api by making requests using a provided [MoneroProvider].
class MoneroProvider {
  /// The underlying deamon service provider used for network communication.
  final MoneroServiceProvider rpc;

  /// Constructs a new [MoneroProvider] instance with the specified [rpc] service provider.
  MoneroProvider(this.rpc);

  int _id = 0;

  static dynamic _parseResponse(
      {required MoneroServiceResponse response,
      required DemonRequestDetails request}) {
    // print(response.)
    String body = "Daemon request failed with status code ${response.status}";
    bool encodeAsUtf8 = false;
    if (response.responseBytes.isNotEmpty) {
      final encode = StringUtils.tryDecode(response.responseBytes);
      if (encode != null) {
        encodeAsUtf8 = true;
      }
      body = encode ?? body;
    }
    if (!response.isSuccess) {
      throw RPCError(
          message: body, errorCode: null, details: StringUtils.tryToJson(body));
    }

    if (request.requestType == DemonRequestType.binary) {
      return MoneroStorageSerializer.deserialize(response.responseBytes);
    }
    Map<String, dynamic>? bodyJson;
    if (encodeAsUtf8) {
      bodyJson = StringUtils.tryToJson(body);
    } else {
      final String? tJ = StringUtils.tryDecode(response.responseBytes,
          allowInvalidOrMalformed: true);
      // // if (tJ != null) {
      // //   final f = File(r"C:\in_work\monero_dart\test\e.txt");
      // //   f.writeAsStringSync(tJ!);

      // // }
      // RegExp backlogRegex = RegExp(r'"distribution":\s*"(.*?)"', dotAll: true);
      bodyJson = StringUtils.toJson(tJ);
    }
    if (bodyJson == null) {
      throw RPCError(message: body, errorCode: null);
    }
    if (request.requestType == DemonRequestType.jsonRPC) {
      final error = bodyJson["error"];
      if (error != null) {
        throw RPCError(
            message: error["message"] ?? body,
            errorCode: int.tryParse(error["code"]?.toString() ?? ""),
            details: error is Map ? Map<String, dynamic>.from(error) : null);
      }
      return bodyJson["result"];
    }

    return bodyJson;
  }

  /// Sends a request to the monero network using the specified [request] parameter.
  ///
  /// The [timeout] parameter, if provided, sets the maximum duration for the request.
  /// Whatever is received will be returned
  Future<dynamic> requestDynamic(MoneroDaemonRequestParam request,
      [Duration? timeout]) async {
    final id = ++_id;
    final params = request.toRequest(id);
    final data = await rpc.post(params, timeout);
    return _parseResponse(response: data, request: params);
  }

  /// Sends a request to the monero network using the specified [request] parameter.
  ///
  /// The [timeout] parameter, if provided, sets the maximum duration for the request.
  Future<T> request<T, E>(MoneroDaemonRequestParam<T, E> request,
      [Duration? timeout]) async {
    final data = await requestDynamic(request, timeout);
    if (data is Map && data.containsKey("status")) {
      if (data["status"] != "OK") {
        throw RPCError(
            message: data["status"],
            errorCode: null,
            details: Map<String, dynamic>.from(data));
      }
    }
    final Object result;
    if (E == List<Map<String, dynamic>>) {
      result = (data as List)
          .map((e) => (e as Map).cast<String, dynamic>())
          .toList();
    } else {
      result = data;
    }
    return request.onResonse(result as E);
  }
}
