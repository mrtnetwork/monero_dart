import 'package:blockchain_utils/utils/string/string.dart';
import 'package:monero_dart/src/serialization/storage_format/types/entry.dart';

enum DemonRequestType { json, jsonRPC, binary }

abstract class DaemonRequestParams {
  abstract final String method;
}

abstract class MoneroDaemonRequestParam<RESULT, RESPONSE>
    implements DaemonRequestParams {
  const MoneroDaemonRequestParam();
  Object get params => {};
  final Map<String, String>? header = null;
  DemonRequestType get requestType => DemonRequestType.json;
  // final DaemonCustomResponseParse? parser = null;

  DemonRequestDetails toRequest(int v) {
    final p = params;
    Object? body;
    if (requestType == DemonRequestType.binary) {
      if (p is Map && p.isNotEmpty) {
        final storage = MoneroStorage.fromJson(p.cast());
        body = storage.serialize();
      }
    } else if (requestType == DemonRequestType.json) {
      body = StringUtils.fromJson(params);
    } else {
      body = StringUtils.fromJson({
        "jsonrpc": "2.0",
        "id": v,
        "method": method,
        "params": params,
      });
    }

    return DemonRequestDetails(
        id: v,
        method: method,
        header: header ?? {},
        body: body,
        requestType: requestType);
  }

  RESULT onResonse(RESPONSE result) {
    return result as RESULT;
  }
}

abstract class MoneroWalletRequestParam<RESULT, RESPONSE>
    implements DaemonRequestParams {
  const MoneroWalletRequestParam();
  Object get params => {};
  final Map<String, String>? header = null;
  DemonRequestType get requestType => DemonRequestType.jsonRPC;

  DemonRequestDetails toRequest(int v) {
    final Object body = StringUtils.fromJson({
      "jsonrpc": "2.0",
      "id": v,
      "method": method,
      "params": params,
    });
    return DemonRequestDetails(
        id: v,
        method: method,
        header: header ?? {},
        body: body,
        requestType: requestType);
  }

  RESULT onResonse(RESPONSE result) {
    return result as RESULT;
  }
}

typedef DaemonCustomResponseParse = Object Function(List<int> responseBytes);

class DemonRequestDetails {
  const DemonRequestDetails(
      {required this.id,
      required this.method,
      required this.requestType,
      this.responseParser,
      this.header = const {},
      this.body});

  DemonRequestDetails copyWith({
    int? id,
    String? method,
    Map<String, String>? header,
    Object? body,
  }) {
    return DemonRequestDetails(
        id: id ?? this.id,
        method: method ?? this.method,
        header: header ?? this.header,
        body: body ?? this.body,
        requestType: requestType);
  }

  final int id;

  final String method;
  // final String? path;

  final Map<String, String> header;

  final Object? body;

  final DemonRequestType requestType;
  final DaemonCustomResponseParse? responseParser;

  Uri toUrl(String baseUrl) {
    // if (!baseUrl.endsWith("/")) {
    //   baseUrl = "$baseUrl/";
    // }
    if (requestType == DemonRequestType.binary) {
      return Uri.parse(baseUrl).replace(path: method);
    }
    if (requestType == DemonRequestType.json) {
      return Uri.parse(baseUrl).replace(path: method);
    } else {
      return Uri.parse(baseUrl).replace(path: "json_rpc");
    }
  }
}
