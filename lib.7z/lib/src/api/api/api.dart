part of 'package:monero_dart/src/api/api.dart';

enum MoneroFeePrority { low, medium, hight }

class MoneroApi extends MoneroApiInterface with MoneroApiUtils {
  @override
  final QuickMoneroProvider provider;
  MoneroApi(this.provider);
  Future<MoneroMultisigTxBuilder> createMultisigTransfer({
    required MoneroBaseAccountInfo account,
    required List<MoneroUnlockedMultisigPayment> payments,
    required List<TxDestination> destinations,
    required MoneroAddress changeAddress,
    required List<MoneroPublicKey> signers,
    MoneroFeePrority prority = MoneroFeePrority.medium,
  }) async {
    if (payments.toSet().length != payments.length) {
      throw const DartMoneroPluginException(
          "Multiple payment with same keyimage detected.");
    }
    final outAmounts =
        destinations.fold<BigInt>(BigInt.zero, (p, c) => p + c.amount);
    final inAmounts =
        payments.fold<BigInt>(BigInt.zero, (p, c) => p + c.output.amount);
    if (outAmounts >= inAmounts) {
      throw const DartMoneroPluginException(
          "output amounts exceed the total input amount and the fee.");
    }
    if (!account.type.isMultisig) {
      throw const DartMoneroPluginException("Account is not a valid multisig.");
    }
    if (payments.isEmpty) {
      throw const DartMoneroPluginException(
          "No payment details were provided.");
    }

    final baseFee = await provider.baseFee();
    TxDestination change = _getChange(
        destinations: destinations,
        change: changeAddress,
        inamount: inAmounts,
        fee: baseFee.fee);
    List<SpendablePayment<MoneroUnlockedMultisigPayment>> spendablePayment =
        provider.generateFakePaymentOuts(payments: payments);
    final estimateTx = MoneroMultisigTxBuilder(
        account: account as MoneroMultisigAccountInfo,
        destinations: [...destinations, change],
        sources: spendablePayment,
        fee: baseFee.fee,
        signers: signers,
        fakeSignature: true);
    // final ser = estimateTx.serialize();
    // MoneroMultisigTxBuilder.deserialize(ser);
    // throw Exception();

    final BigInt fee =
        _calcuateFee(baseFee: baseFee, weight: estimateTx.weight());
    change = _getChange(
        destinations: destinations,
        change: changeAddress,
        inamount: inAmounts,
        fee: fee);
    spendablePayment =
        await provider.generatePaymentOutputs(payments: payments);
    return MoneroMultisigTxBuilder(
        account: account,
        destinations: destinations,
        sources: spendablePayment,
        fee: fee,
        change: change,
        signers: signers,
        fakeSignature: false);
  }

  Future<MoneroRctTxBuilder> createTransfer({
    required MoneroBaseAccountInfo account,
    required List<MoneroUnLockedPayment> payments,
    required List<TxDestination> destinations,
    required MoneroAddress changeAddress,
    MoneroFeePrority prority = MoneroFeePrority.medium,
  }) async {
    if (payments.toSet().length != payments.length) {
      throw const DartMoneroPluginException(
          "Multiple payment with same keyimage detected.");
    }
    final outAmounts =
        destinations.fold<BigInt>(BigInt.zero, (p, c) => p + c.amount);
    final inAmounts =
        payments.fold<BigInt>(BigInt.zero, (p, c) => p + c.output.amount);
    if (outAmounts >= inAmounts) {
      throw const DartMoneroPluginException(
          "output amounts exceed the total input amount and the fee.");
    }
    final baseFee = await provider.baseFee();
    TxDestination change = _getChange(
        destinations: destinations,
        change: changeAddress,
        inamount: inAmounts,
        fee: baseFee.fee);
    List<SpendablePayment> spendablePayment =
        provider.generateFakePaymentOuts(payments: payments);
    MoneroRctTxBuilder tx = MoneroRctTxBuilder(
        account: account,
        destinations: [...destinations, change],
        sources: spendablePayment,
        fee: baseFee.fee,
        fakeSignature: true);
    final BigInt fee = _calcuateFee(baseFee: baseFee, weight: tx.weight());
    change = _getChange(
        destinations: destinations,
        change: changeAddress,
        inamount: inAmounts,
        fee: fee);
    spendablePayment =
        await provider.generatePaymentOutputs(payments: payments);
    tx = MoneroRctTxBuilder(
        account: account,
        destinations: destinations,
        sources: spendablePayment,
        fee: fee,
        change: change,
        fakeSignature: false);
    return tx;
  }

  @override
  Future<List<MoneroUnLockedPayment>> unlockOutputs(
      {required List<String> txHashes,
      required MoneroBaseAccountInfo account}) async {
    // accountIndexes =
    //     _getIndexes(account: account, accountIndexes: accountIndexes);
    final transactions = await provider.getTxes(txHashes: txHashes);
    return unlockTransactionOutputs(
        transactions: transactions, account: account);
  }

  List<MoneroUnlockedMultisigPayment> unlockMultisigOutput(
      {required MoneroMultisigAccountInfo account,
      required List<UnlockMultisigOutputRequest> payments}) {
    return payments
        .map((e) => _toMultisigUnlockedOutput(
            account: account,
            payment: e.payment,
            multisigInfos: e.multisigInfos))
        .toList();
  }

  @override
  List<MoneroUnLockedPayment> unlockTransactionOutputs(
      {required List<MoneroTransactionWithOutputIndeces> transactions,
      required MoneroBaseAccountInfo account}) {
    // accountIndexes =
    //     _getIndexes(account: account, accountIndexes: accountIndexes);
    final List<MoneroUnLockedPayment> outputs = [];
    for (final tx in transactions) {
      for (int i = 0; i < tx.transaction.vout.length; i++) {
        for (final index in account.indexes) {
          final txOutputs = _getUnlockOutputs2(
              tx: tx.transaction,
              account: account,
              index: index,
              out: tx.transaction.vout[i],
              outIndex: i,
              indices: tx.outputIndices);
          if (txOutputs == null) continue;
          outputs.add(txOutputs);
          break;
        }
      }
    }
    return outputs;
  }

  @override
  Future<List<MoneroLockedPayment>> watchOutPuts(
      {required List<String> txHashes,
      required MoneroBaseAccountInfo account}) async {
    final transactions = await provider.getTxes(txHashes: txHashes);
    return watchTransactionOutputs(
        transactions: transactions, account: account);
  }

  @override
  List<MoneroLockedPayment> watchTransactionOutputs(
      {required List<MoneroTransactionWithOutputIndeces> transactions,
      required MoneroBaseAccountInfo account}) {
    final List<MoneroLockedPayment> outputs = [];
    for (final tx in transactions) {
      for (final index in account.indexes) {
        final txOutputs = _getLockedOutputs(
            tx: tx.transaction,
            account: account,
            index: index,
            indices: tx.outputIndices);
        outputs.addAll(txOutputs);
      }
    }
    return outputs;
  }
}
