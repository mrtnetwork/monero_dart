part of 'package:monero_dart/src/api/api.dart';

abstract class MoneroApiInterface {
  abstract final QuickMoneroProvider provider;

  // Future<MoneroTxBuilder> createTran

  /// Read transactions outputs for watch only wallets.
  List<MoneroLockedPayment> watchTransactionOutputs(
      {required List<MoneroTransactionWithOutputIndeces> transactions,
      required MoneroBaseAccountInfo account});

  /// Read transaction outputs for watch only wallets.
  Future<List<MoneroLockedPayment>> watchOutPuts(
      {required List<String> txHashes, required MoneroBaseAccountInfo account});

  /// read transactions outputs and retrive keyimage.
  List<MoneroUnLockedPayment> unlockTransactionOutputs(
      {required List<MoneroTransactionWithOutputIndeces> transactions,
      required MoneroBaseAccountInfo account});

  /// read transactions outputs and retrive keyimage.
  Future<List<MoneroUnLockedPayment>> unlockOutputs(
      {required List<String> txHashes, required MoneroBaseAccountInfo account});
}
