import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:monero_dart/src/address/address/address.dart';
import 'package:monero_dart/src/crypto/models/ct_key.dart';
import 'package:monero_dart/src/crypto/multisig/models/models.dart';
import 'package:monero_dart/src/crypto/types/types.dart';
import 'package:monero_dart/src/exception/exception.dart';
import 'package:monero_dart/src/helper/extension.dart';
import 'package:monero_dart/src/helper/transaction.dart';
import 'package:monero_dart/src/models/transaction/transaction/output.dart';
import 'package:monero_dart/src/models/transaction/transaction/transaction.dart';
import 'package:monero_dart/src/serialization/serialization.dart';

class MoneroOutputType {
  final int value;
  final String name;
  const MoneroOutputType._({required this.value, required this.name});
  static const MoneroOutputType locked =
      MoneroOutputType._(value: 0, name: "locked");
  static const MoneroOutputType unlocked =
      MoneroOutputType._(value: 1, name: "unlocked");
  static const MoneroOutputType unlockedMultisig =
      MoneroOutputType._(value: 2, name: "unlockedMultisig");
  static const List<MoneroOutputType> values = [locked, unlocked];
  static MoneroOutputType fromName(String? name) {
    return values.firstWhere((e) => e.name == name,
        orElse: () => throw DartMoneroPluginException("Invalid output type.",
            details: {"type": name}));
  }

  @override
  String toString() {
    return "MoneroOutputType.$name";
  }
}

class MoneroPaymentType {
  final int value;
  final String name;
  const MoneroPaymentType._({required this.value, required this.name});
  static const MoneroPaymentType locked =
      MoneroPaymentType._(value: 0, name: "locked");
  static const MoneroPaymentType unlocked =
      MoneroPaymentType._(value: 1, name: "unlocked");
  static const MoneroPaymentType unlockedMultisig =
      MoneroPaymentType._(value: 2, name: "unlockedMultisig");
  static const List<MoneroPaymentType> values = [
    locked,
    unlocked,
    unlockedMultisig
  ];
  static MoneroPaymentType fromName(String? name) {
    return values.firstWhere((e) => e.name == name,
        orElse: () => throw DartMoneroPluginException("Invalid payment type.",
            details: {"type": name}));
  }

  @override
  String toString() {
    return "MoneroPaymentType.$name";
  }
}

abstract class MoneroOutput extends MoneroVariantSerialization {
  final BigInt amount;
  final MoneroAccountIndex accountIndex;
  final bool isRCT;
  final MoneroOutputType type;
  final RctKey mask;
  final RctKey derivation;
  final BigInt globalIndex;
  final MoneroPublicKey outputPublicKey;
  MoneroOutput(
      {required BigInt amount,
      required this.accountIndex,
      required this.isRCT,
      required this.type,
      required RctKey mask,
      required RctKey derivation,
      required BigInt globalIndex,
      required this.outputPublicKey})
      : amount = amount.asUint64,
        mask = mask.asImmutableBytes.exceptedLen(32),
        derivation = derivation.asImmutableBytes.exceptedLen(32),
        globalIndex = globalIndex.asUint64;

  factory MoneroOutput.fromStruct(Map<String, dynamic> json) {
    final decode = MoneroVariantSerialization.toVariantDecodeResult(json);
    final type = MoneroOutputType.fromName(decode.variantName);
    switch (type) {
      case MoneroOutputType.locked:
        return MoneroLockedOutput.fromStruct(decode.value);
      case MoneroOutputType.unlocked:
        return MoneroUnlockedOutput.fromStruct(decode.value);
      case MoneroOutputType.unlockedMultisig:
        return MoneroUnlockedMultisigOutput.fromStruct(decode.value);
      default:
        throw UnimplementedError("Invalid monero output type.");
    }
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnum([
      LazyVariantModel(
        layout: MoneroLockedOutput.layout,
        property: MoneroOutputType.locked.name,
        index: MoneroOutputType.locked.value,
      ),
      LazyVariantModel(
        layout: MoneroUnlockedOutput.layout,
        property: MoneroOutputType.unlocked.name,
        index: MoneroOutputType.unlocked.value,
      ),
      LazyVariantModel(
        layout: MoneroUnlockedMultisigOutput.layout,
        property: MoneroOutputType.unlockedMultisig.name,
        index: MoneroOutputType.unlockedMultisig.value,
      ),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String get variantName => type.name;
  Map<String, dynamic> toJson() {
    return {
      "amount": amount,
      "mask": mask,
      "isRCT": isRCT,
      "derivation": BytesUtils.toHexString(derivation),
      // "ephemeralSecretKey": ephemeralSecretKey,
      // "ephemeralPublicKey": ephemeralPublicKey,
      // "keyImage": keyImage,
      "globalIndex": globalIndex,
      "accountIndex": accountIndex.toJson(),
      "outputPublicKey": outputPublicKey.toHex()
    };
  }

  T cast<T extends MoneroOutput>() {
    if (this is! T) {
      throw DartMoneroPluginException("Monero output casting failed.",
          details: {"excepted": "$T", "type": type.name});
    }
    return this as T;
  }

  @override
  String toString() {
    return "{amount: ${MoneroTransactionHelper.fromXMR(amount)} status: ${type.name} globalIndex: $globalIndex accountIndex: $accountIndex}";
  }
}

// class MoneroAccountInfo2 {
//   final MoneroAccount account;
//   const MoneroAccountInfo2({required this.account, this.multisigAccount});

//   MoneroAccountIndex defaultIndex() {
//     return MoneroAccountIndex(address: MoneroAddress(account.primaryAddress));
//   }

//   MoneroAddress toPrimaryAddress() {
//     return MoneroAddress(account.primaryAddress);
//   }

//   MoneroAddress toSubAddress() {
//     return MoneroAddress(account.subaddress(1));
//   }

//   bool get isMultisig => multisigAccount != null;
//   final MoneroMultisigAccount? multisigAccount;

// RctKey getPrivateSpendKey() {
//   if (!isMultisig) return account.privSkey!.key;
//   final spendKey = RCT.zero();
//   for (final i in multisigAccount!.multisigPrivateKeys) {
//     CryptoOps.scAdd(spendKey, i.key, spendKey);
//   }
//   return spendKey;
// }
// }

class MoneroLockedOutput extends MoneroOutput {
  MoneroLockedOutput(
      {required BigInt amount,
      required bool isRCT,
      required RctKey mask,
      required RctKey derivation,
      required BigInt globalIndex,
      required MoneroPublicKey outputPublicKey,
      required MoneroAccountIndex accountIndex})
      : super(
            amount: amount,
            isRCT: isRCT,
            accountIndex: accountIndex,
            type: MoneroOutputType.locked,
            derivation: derivation,
            globalIndex: globalIndex,
            mask: mask,
            outputPublicKey: outputPublicKey);

  factory MoneroLockedOutput.fromStruct(Map<String, dynamic> json) {
    return MoneroLockedOutput(
        amount: json.as("amount"),
        isRCT: json.as("isRCT"),
        accountIndex: MoneroAccountIndex.fromStruct(json.asMap("accountIndex")),
        mask: json.asBytes("mask"),
        derivation: json.asBytes("derivation"),
        globalIndex: json.as("globalIndex"),
        outputPublicKey:
            MoneroPublicKey.fromBytes(json.asBytes("outputPublicKey")));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      MoneroLayoutConst.varintBigInt(property: "amount"),
      MoneroAccountIndex.layout(property: "accountIndex"),
      LayoutConst.boolean(property: "isRCT"),
      LayoutConst.fixedBlob32(property: "mask"),
      LayoutConst.fixedBlob32(property: "derivation"),
      LayoutConst.fixedBlob32(property: "outputPublicKey"),
      MoneroLayoutConst.varintBigInt(property: "globalIndex"),
    ], property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "amount": amount,
      "isRCT": isRCT,
      "accountIndex": accountIndex.toLayoutStruct(),
      "globalIndex": globalIndex,
      "mask": mask,
      "derivation": derivation,
      "outputPublicKey": outputPublicKey.key
    };
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }
}

class MoneroUnlockedOutput extends MoneroOutput {
  final RctKey ephemeralSecretKey;
  final RctKey ephemeralPublicKey;
  final RctKey keyImage;
  CtKey get toSecretKey => CtKey(dest: ephemeralSecretKey, mask: mask);
  MoneroUnlockedOutput._({
    required BigInt amount,
    required RctKey derivation,
    required RctKey ephemeralSecretKey,
    required RctKey ephemeralPublicKey,
    required RctKey keyImage,
    required RctKey mask,
    required MoneroPublicKey outputPublicKey,
    required bool isRCT,
    required BigInt globalIndex,
    required MoneroAccountIndex accountindex,
    MoneroOutputType type = MoneroOutputType.unlocked,
  })  : ephemeralPublicKey =
            ephemeralPublicKey.asImmutableBytes.exceptedLen(32),
        ephemeralSecretKey =
            ephemeralSecretKey.asImmutableBytes.exceptedLen(32),
        keyImage = keyImage.asImmutableBytes.exceptedLen(32),
        super(
            amount: amount,
            accountIndex: accountindex,
            type: MoneroOutputType.unlocked,
            isRCT: isRCT,
            derivation: derivation,
            globalIndex: globalIndex,
            mask: mask,
            outputPublicKey: outputPublicKey);
  factory MoneroUnlockedOutput({
    required BigInt amount,
    required RctKey derivation,
    required RctKey ephemeralSecretKey,
    required RctKey ephemeralPublicKey,
    required RctKey keyImage,
    required RctKey mask,
    required MoneroPublicKey outputPublicKey,
    required bool isRCT,
    required BigInt globalIndex,
    required MoneroAccountIndex accountindex,
  }) {
    return MoneroUnlockedOutput._(
        amount: amount,
        derivation: derivation,
        ephemeralSecretKey: ephemeralSecretKey,
        ephemeralPublicKey: ephemeralPublicKey,
        keyImage: keyImage,
        mask: mask,
        outputPublicKey: outputPublicKey,
        isRCT: isRCT,
        globalIndex: globalIndex,
        accountindex: accountindex);
  }
  factory MoneroUnlockedOutput.fromStruct(Map<String, dynamic> json) {
    return MoneroUnlockedOutput(
        amount: json.as("amount"),
        accountindex: MoneroAccountIndex.fromStruct(json.asMap("accountIndex")),
        derivation: json.asBytes("derivation"),
        mask: json.asBytes("mask"),
        ephemeralPublicKey: json.asBytes("ephemeralPublicKey"),
        ephemeralSecretKey: json.asBytes("ephemeralSecretKey"),
        globalIndex: json.as("globalIndex"),
        keyImage: json.asBytes("keyImage"),
        outputPublicKey: MoneroPublicKey.fromBytes(json.asBytes("outputPublicKey")),
        isRCT: json.as("isRCT"));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      MoneroLayoutConst.varintBigInt(property: "amount"),
      LayoutConst.fixedBlob32(property: "mask"),
      LayoutConst.fixedBlob32(property: "derivation"),
      LayoutConst.fixedBlob32(property: "outputPublicKey"),
      LayoutConst.boolean(property: "isRCT"),
      MoneroLayoutConst.varintBigInt(property: "globalIndex"),
      LayoutConst.fixedBlob32(property: "ephemeralSecretKey"),
      LayoutConst.fixedBlob32(property: "ephemeralPublicKey"),
      LayoutConst.fixedBlob32(property: "keyImage"),
      MoneroAccountIndex.layout(property: "accountIndex")
    ], property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "amount": amount,
      "mask": mask,
      "isRCT": isRCT,
      "derivation": derivation,
      "ephemeralSecretKey": ephemeralSecretKey,
      "ephemeralPublicKey": ephemeralPublicKey,
      "keyImage": keyImage,
      "globalIndex": globalIndex,
      "accountIndex": accountIndex.toLayoutStruct(),
      "outputPublicKey": outputPublicKey.key
    };
  }

  @override
  Map<String, dynamic> toJson() {
    return {
      ...super.toJson(),
      "ephemeralSecretKey": BytesUtils.toHexString(ephemeralSecretKey),
      "ephemeralPublicKey": BytesUtils.toHexString(ephemeralPublicKey),
      "keyImage": BytesUtils.toHexString(keyImage),
    };
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }
}

class MoneroUnlockedMultisigOutput extends MoneroUnlockedOutput {
  final RctKey multisigKeyImage;
  MoneroUnlockedMultisigOutput({
    required BigInt amount,
    required RctKey derivation,
    required RctKey ephemeralSecretKey,
    required RctKey ephemeralPublicKey,
    required RctKey multisigKeyImage,
    required RctKey keyImage,
    required RctKey mask,
    required MoneroPublicKey outputPublicKey,
    required bool isRCT,
    required BigInt globalIndex,
    required MoneroAccountIndex accountindex,
  })  : multisigKeyImage = multisigKeyImage.asImmutableBytes.exceptedLen(32),
        super._(
            ephemeralPublicKey: ephemeralPublicKey,
            ephemeralSecretKey: ephemeralSecretKey,
            keyImage: keyImage,
            amount: amount,
            accountindex: accountindex,
            type: MoneroOutputType.unlockedMultisig,
            isRCT: isRCT,
            derivation: derivation,
            globalIndex: globalIndex,
            mask: mask,
            outputPublicKey: outputPublicKey);
  factory MoneroUnlockedMultisigOutput.fromStruct(Map<String, dynamic> json) {
    return MoneroUnlockedMultisigOutput(
        amount: json.as("amount"),
        accountindex: MoneroAccountIndex.fromStruct(json.asMap("accountIndex")),
        derivation: json.asBytes("derivation"),
        mask: json.asBytes("mask"),
        ephemeralPublicKey: json.asBytes("ephemeralPublicKey"),
        ephemeralSecretKey: json.asBytes("ephemeralSecretKey"),
        globalIndex: json.as("globalIndex"),
        keyImage: json.asBytes("keyImage"),
        outputPublicKey: MoneroPublicKey.fromBytes(json.asBytes("outputPublicKey")),
        isRCT: json.as("isRCT"),
        multisigKeyImage: json.asBytes("multisigKeyImage"));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      MoneroLayoutConst.varintBigInt(property: "amount"),
      LayoutConst.fixedBlob32(property: "mask"),
      LayoutConst.fixedBlob32(property: "derivation"),
      LayoutConst.fixedBlob32(property: "outputPublicKey"),
      LayoutConst.boolean(property: "isRCT"),
      MoneroLayoutConst.varintBigInt(property: "globalIndex"),
      LayoutConst.fixedBlob32(property: "ephemeralSecretKey"),
      LayoutConst.fixedBlob32(property: "ephemeralPublicKey"),
      LayoutConst.fixedBlob32(property: "keyImage"),
      LayoutConst.fixedBlob32(property: "multisigKeyImage"),
      MoneroAccountIndex.layout(property: "accountIndex")
    ], property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "amount": amount,
      "mask": mask,
      "isRCT": isRCT,
      "derivation": derivation,
      "ephemeralSecretKey": ephemeralSecretKey,
      "ephemeralPublicKey": ephemeralPublicKey,
      "keyImage": keyImage,
      "globalIndex": globalIndex,
      "accountIndex": accountIndex.toLayoutStruct(),
      "outputPublicKey": outputPublicKey.key,
      "multisigKeyImage": multisigKeyImage
    };
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }
}

abstract class MoneroPayment<T extends MoneroOutput>
    extends MoneroVariantSerialization {
  final MoneroPaymentType type;
  final T output;
  bool get isRCT => output.isRCT;
  final MoneroPublicKey txPubkey;
  final RctKey? paymentId;
  final RctKey? encryptedPaymentid;
  final int index;
  MoneroPayment({
    required this.type,
    required this.output,
    required this.txPubkey,
    required RctKey? paymentId,
    required RctKey? encryptedPaymentid,
    required this.index,
  })  : paymentId = paymentId?.asImmutableBytes,
        encryptedPaymentid = encryptedPaymentid?.asImmutableBytes;

  factory MoneroPayment.fromStruct(Map<String, dynamic> json) {
    final decode = MoneroVariantSerialization.toVariantDecodeResult(json);
    final type = MoneroPaymentType.fromName(decode.variantName);
    final MoneroPayment payment;
    switch (type) {
      case MoneroPaymentType.locked:
        payment = MoneroLockedPayment.fromStruct(decode.value);
        break;
      case MoneroPaymentType.unlocked:
        payment = MoneroUnLockedPayment.fromStruct(decode.value);
        break;
      case MoneroPaymentType.unlockedMultisig:
        payment = MoneroUnlockedMultisigPayment.fromStruct(decode.value);
        break;
      default:
        throw UnimplementedError("Invalid monero payment type.");
    }
    if (payment is! MoneroPayment<T>) {
      throw DartMoneroPluginException("Monero payment casting failed.",
          details: {"excepted": "$T", "type": type.name});
    }
    return payment;
  }

  @override
  String get variantName => type.name;
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnum([
      LazyVariantModel(
        layout: MoneroLockedPayment.layout,
        property: MoneroPaymentType.locked.name,
        index: MoneroPaymentType.locked.value,
      ),
      LazyVariantModel(
        layout: MoneroUnLockedPayment.layout,
        property: MoneroPaymentType.unlocked.name,
        index: MoneroPaymentType.unlocked.value,
      ),
      LazyVariantModel(
        layout: MoneroUnlockedMultisigPayment.layout,
        property: MoneroPaymentType.unlockedMultisig.name,
        index: MoneroPaymentType.unlockedMultisig.value,
      ),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  E cast<E extends MoneroPayment>() {
    if (this is! E) {
      throw DartMoneroPluginException("Payment casting failed.",
          details: {"excepted": "$E", "type": type.name});
    }
    return this as E;
  }

  @override
  String toString() {
    return output.toString();
  }
}

class MoneroLockedPayment extends MoneroPayment<MoneroLockedOutput> {
  MoneroLockedPayment({
    required MoneroLockedOutput output,
    required MoneroPublicKey txPubkey,
    required RctKey? paymentId,
    required RctKey? encryptedPaymentid,
    required int index,
  }) : super(
            output: output,
            txPubkey: txPubkey,
            paymentId: paymentId,
            encryptedPaymentid: encryptedPaymentid,
            type: MoneroPaymentType.locked,
            index: index);
  factory MoneroLockedPayment.fromStruct(Map<String, dynamic> json) {
    return MoneroLockedPayment(
        output: MoneroLockedOutput.fromStruct(json.asMap("output")),
        txPubkey: MoneroPublicKey.fromBytes(json.asBytes("txPubkey")),
        encryptedPaymentid: json.asBytes("encryptedPaymentid"),
        paymentId: json.asBytes("paymentId"),
        index: json.as("index"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      MoneroLockedOutput.layout(property: "output"),
      LayoutConst.fixedBlob32(property: "txPubkey"),
      LayoutConst.optional(LayoutConst.fixedBlobN(8), property: "paymentId"),
      LayoutConst.optional(LayoutConst.fixedBlobN(8),
          property: "encryptedPaymentid"),
      MoneroLayoutConst.varintInt(property: "index")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "output": output.toLayoutStruct(),
      "txPubkey": txPubkey.key,
      "paymentId": paymentId,
      "encryptedPaymentid": encryptedPaymentid,
      "index": index
    };
  }
}

class MoneroUnLockedPayment<T extends MoneroUnlockedOutput>
    extends MoneroPayment<T> {
  RctKey get keyImage => output.keyImage;
  MoneroUnLockedPayment._(
      {required T output,
      required MoneroPublicKey txPubkey,
      required RctKey? paymentId,
      required RctKey? encryptedPaymentid,
      required int index,
      required MoneroPaymentType type})
      : super(
            output: output,
            txPubkey: txPubkey,
            paymentId: paymentId,
            encryptedPaymentid: encryptedPaymentid,
            type: type,
            index: index);
  MoneroUnLockedPayment(
      {required T output,
      required MoneroPublicKey txPubkey,
      required RctKey? paymentId,
      required RctKey? encryptedPaymentid,
      required int index})
      : super(
            output: output,
            txPubkey: txPubkey,
            paymentId: paymentId,
            encryptedPaymentid: encryptedPaymentid,
            type: MoneroPaymentType.unlocked,
            index: index);
  factory MoneroUnLockedPayment.fromStruct(Map<String, dynamic> json) {
    return MoneroUnLockedPayment(
        output: MoneroUnlockedOutput.fromStruct(json.asMap("output")).cast<T>(),
        txPubkey: MoneroPublicKey.fromBytes(json.asBytes("txPubkey")),
        encryptedPaymentid: json.asBytes("encryptedPaymentid"),
        paymentId: json.asBytes("paymentId"),
        index: json.as("index"));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      MoneroUnlockedOutput.layout(property: "output"),
      LayoutConst.fixedBlob32(property: "txPubkey"),
      LayoutConst.optional(LayoutConst.fixedBlobN(8), property: "paymentId"),
      LayoutConst.optional(LayoutConst.fixedBlobN(8),
          property: "encryptedPaymentid"),
      MoneroLayoutConst.varintInt(property: "index")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "output": output.toLayoutStruct(),
      "txPubkey": txPubkey.key,
      "paymentId": paymentId,
      "encryptedPaymentid": encryptedPaymentid,
      "index": index
    };
  }

  @override
  operator ==(other) {
    if (other is! MoneroUnLockedPayment) return false;
    if (identical(this, other)) return true;
    return BytesUtils.bytesEqual(keyImage, other.keyImage);
  }

  @override
  int get hashCode => HashCodeGenerator.generateBytesHashCode(keyImage);
}

class MoneroUnlockedMultisigPayment
    extends MoneroUnLockedPayment<MoneroUnlockedMultisigOutput> {
  @override
  RctKey get keyImage => output.multisigKeyImage;
  final List<MoneroMultisigOutputInfo> multisigInfos;
  MoneroUnlockedMultisigPayment({
    required MoneroUnlockedMultisigOutput output,
    required MoneroPublicKey txPubkey,
    required RctKey? paymentId,
    required RctKey? encryptedPaymentid,
    required int index,
    required List<MoneroMultisigOutputInfo> multisigInfos,
  })  : multisigInfos = multisigInfos.immutable,
        super._(
            output: output,
            txPubkey: txPubkey,
            paymentId: paymentId,
            encryptedPaymentid: encryptedPaymentid,
            index: index,
            type: MoneroPaymentType.unlockedMultisig);
  factory MoneroUnlockedMultisigPayment.fromStruct(Map<String, dynamic> json) {
    return MoneroUnlockedMultisigPayment(
        output: MoneroUnlockedMultisigOutput.fromStruct(json.asMap("output")),
        txPubkey: MoneroPublicKey.fromBytes(json.asBytes("txPubkey")),
        encryptedPaymentid: json.asBytes("encryptedPaymentid"),
        paymentId: json.asBytes("paymentId"),
        index: json.as("index"),
        multisigInfos: json
            .asListOfMap("multisigInfos")!
            .map((e) => MoneroMultisigOutputInfo.fromStruct(e))
            .toList());
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      MoneroUnlockedMultisigOutput.layout(property: "output"),
      LayoutConst.fixedBlob32(property: "txPubkey"),
      LayoutConst.optional(LayoutConst.fixedBlobN(8), property: "paymentId"),
      LayoutConst.optional(LayoutConst.fixedBlobN(8),
          property: "encryptedPaymentid"),
      MoneroLayoutConst.varintInt(property: "index"),
      MoneroLayoutConst.variantVec(MoneroMultisigOutputInfo.layout(),
          property: "multisigInfos")
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "output": output.toLayoutStruct(),
      "txPubkey": txPubkey.key,
      "paymentId": paymentId,
      "encryptedPaymentid": encryptedPaymentid,
      "index": index,
      "multisigInfos": multisigInfos.map((e) => e.toLayoutStruct()).toList()
    };
  }

  @override
  operator ==(other) {
    if (other is! MoneroUnlockedMultisigPayment) return false;
    if (identical(this, other)) return true;
    return BytesUtils.bytesEqual(keyImage, other.keyImage);
  }

  @override
  int get hashCode => HashCodeGenerator.generateBytesHashCode(keyImage);
}

class SpendablePayment<T extends MoneroUnLockedPayment>
    extends MoneroSerialization {
  final T payment;
  final List<OutsEntery> outs;
  final int realOutIndex;

  SpendablePayment(
      {required this.payment,
      required List<OutsEntery> outs,
      required this.realOutIndex})
      : outs = outs.immutable;

  factory SpendablePayment.fromStruct(Map<String, dynamic> json) {
    return SpendablePayment(
        payment: MoneroPayment.fromStruct(json.asMap("payment")).cast<T>(),
        outs: json
            .asListOfMap("outs")!
            .map((e) => OutsEntery.fromStruct(e))
            .toList(),
        realOutIndex: json.as("realOutIndex"));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      MoneroPayment.layout(property: "payment"),
      MoneroLayoutConst.variantVec(OutsEntery.layout(), property: "outs"),
      MoneroLayoutConst.varintInt(property: "realOutIndex")
    ], property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "payment": payment.toVariantLayoutStruct(),
      "outs": outs.map((e) => e.toLayoutStruct()).toList(),
      "realOutIndex": realOutIndex
    };
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }
}

class UnlockMultisigOutputRequest {
  final List<MoneroMultisigOutputInfo> multisigInfos;
  final MoneroUnLockedPayment payment;
  UnlockMultisigOutputRequest(
      {required this.payment,
      required List<MoneroMultisigOutputInfo> multisigInfos})
      : multisigInfos = multisigInfos.immutable;
}

class MoneroTransactionWithOutputIndeces {
  final MoneroTransaction transaction;
  final List<BigInt> outputIndices;
  MoneroTransactionWithOutputIndeces._(
      {required this.transaction, required List<BigInt> outputIndices})
      : outputIndices = outputIndices.immutable;
  factory MoneroTransactionWithOutputIndeces({
    required MoneroTransaction transaction,
    required List<BigInt> outputIndices,
  }) {
    if (transaction.vout.length != outputIndices.length) {
      throw const DartMoneroPluginException(
          "Invalid output indices length: the number of transaction outputs must match the number of output indices.");
    }
    return MoneroTransactionWithOutputIndeces._(
        transaction: transaction, outputIndices: outputIndices);
  }
}

class TxDestination extends MoneroSerialization {
  final BigInt amount;
  final MoneroAddress address;
  const TxDestination({required this.amount, required this.address});

  factory TxDestination.fromStruct(Map<String, dynamic> json) {
    return TxDestination(
        amount: json.as("amount"),
        address: MoneroAddress.fromStruct(json.asMap("address")));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      MoneroLayoutConst.varintBigInt(property: "amount"),
      MoneroAddress.layout(property: "address"),
    ], property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"amount": amount, "address": address.toLayoutStruct()};
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String toString() {
    return {
      "amount": MoneroTransactionHelper.fromXMR(amount),
      "address": address.toString()
    }.toString();
  }
}

class MoneroAccountIndex extends MoneroSerialization {
  final int major;
  final int minor;
  const MoneroAccountIndex({this.major = 0, this.minor = 0});
  static const MoneroAccountIndex primary = MoneroAccountIndex();
  static const MoneroAccountIndex minor1 = MoneroAccountIndex(minor: 1);
  bool get isSubaddress {
    return major != 0 || minor != 0;
  }

  factory MoneroAccountIndex.fromStruct(Map<String, dynamic> json) {
    return MoneroAccountIndex(major: json.as("major"), minor: json.as("minor"));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      LayoutConst.u32(property: "major"),
      LayoutConst.u32(property: "minor")
    ], property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"major": major, "minor": minor};
  }

  Map<String, dynamic> toJson() {
    return {"major": major, "minor": minor};
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  String toString() {
    return {"major": major, "minor": minor}.toString();
  }

  @override
  operator ==(other) {
    if (other is! MoneroAccountIndex) return false;
    if (identical(this, other)) return true;
    return major == other.major && minor == other.minor;
  }

  @override
  int get hashCode => HashCodeGenerator.generateHashCode([major, minor]);
}

class OutsEntery extends MoneroSerialization {
  final BigInt index;
  final CtKey key;
  const OutsEntery({required this.index, required this.key});
  factory OutsEntery.fromStruct(Map<String, dynamic> json) {
    return OutsEntery(
        index: json.as("index"), key: CtKey.fromStruct(json.asMap("key")));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      MoneroLayoutConst.varintBigInt(property: "index"),
      CtKey.layout(property: "key")
    ], property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {"index": index, "key": key.toLayoutStruct()};
  }

  Map<String, dynamic> toJson() {
    return {"index": index, "key": key.toJson()};
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is OutsEntery &&
          runtimeType == other.runtimeType &&
          index == other.index &&
          key == other.key);

  @override
  int get hashCode => HashCodeGenerator.generateHashCode([index, key]);
}

class TxEpemeralKeyResult {
  final TxoutTarget txOut;
  final List<int> amountKey;
  final MoneroPublicKey? additionalTxPubKey;
  TxEpemeralKeyResult(
      {required this.txOut,
      required List<int> amountKey,
      this.additionalTxPubKey})
      : amountKey = amountKey.immutable;
}
