part of 'package:monero_dart/src/api/api.dart';

mixin MoneroApiUtils on MoneroApiInterface {
  MoneroLockedPayment? _getLockedOutputs1(
      {required MoneroTxout out,
      required int i,
      required MoneroTransaction tx,
      required MoneroBaseAccountInfo account,
      required MoneroAccountIndex index,
      required List<BigInt> indices}) {
    final outPublicKey = out.target.getPublicKey();
    if (outPublicKey == null) {
      return null;
    }
    final additionalPubKeys = tx.getTxAdditionalPubKeys();
    // MoneroPublicKey txPubKey = tx.getTxExtraPubKey();
    final List<MoneroPublicKey> publicKeys = [
      tx.getTxExtraPubKey(),
      if (additionalPubKeys != null) additionalPubKeys.pubKeys[i]
    ];

    // bool isAccOut = MoneroTransactionHelper.inOuttoAcc(
    //     publicSpendKey: account.getSpendPublicKey(index),
    //     viewSecretKey: account.account.privVkey,
    //     txPubkey: txPubKey,
    //     out: out,
    //     outIndex: i);

    // if (!isAccOut && additionalPubKeys != null) {
    //   txPubKey = additionalPubKeys.pubKeys[i];
    //   isAccOut = MoneroTransactionHelper.inOuttoAcc(
    //       publicSpendKey: account.getSpendPublicKey(index),
    //       viewSecretKey: account.account.privVkey,
    //       txPubkey: txPubKey,
    //       out: out,
    //       outIndex: i);
    // }
    for (final p in publicKeys) {
      final derivation = MoneroCrypto.generateKeyDerivation(
          pubkey: p, secretKey: account.account.privVkey);
      final sharedSec =
          MoneroCrypto.derivationToScalar(derivation: derivation, outIndex: i);
      final mask = RCT.zero();
      final amount = RCTGeneratorUtils.decodeRct_(
          sig: tx.signature.cast(),
          secretKey: sharedSec,
          outputIndex: i,
          mask: mask);
      print("amount $amount");
      if (amount == null) return null;
      final out = MoneroLockedOutput(
          amount: amount,
          isRCT: true,
          mask: mask,
          derivation: derivation,
          globalIndex: indices[i],
          outputPublicKey: outPublicKey,
          accountIndex: index);
      return _toPayment(
          out: out,
          transaction: tx,
          account: account,
          index: index,
          realIndex: i) as MoneroLockedPayment;
    }
    // if (isAccOut) {

    // }
    return null;
  }

  List<MoneroLockedPayment> _getLockedOutputs(
      {required MoneroTransaction tx,
      required MoneroBaseAccountInfo account,
      required MoneroAccountIndex index,
      required List<BigInt> indices}) {
    final List<MoneroPayment> outputs = [];
    final additionalPubKeys = tx.getTxAdditionalPubKeys();
    for (int i = 0; i < tx.vout.length; i++) {
      MoneroPublicKey txPubKey = tx.getTxExtraPubKey();
      final out = tx.vout[i];
      final outPublicKey = out.target.getPublicKey();
      if (outPublicKey == null) {
        continue;
      }
      bool isAccOut = MoneroTransactionHelper.inOuttoAcc(
          publicSpendKey: account.getSpendPublicKey(index),
          viewSecretKey: account.account.privVkey,
          txPubkey: txPubKey,
          out: out,
          outIndex: i);

      if (!isAccOut && additionalPubKeys != null) {
        txPubKey = additionalPubKeys.pubKeys[i];
        isAccOut = MoneroTransactionHelper.inOuttoAcc(
            publicSpendKey: account.getSpendPublicKey(index),
            viewSecretKey: account.account.privVkey,
            txPubkey: txPubKey,
            out: out,
            outIndex: i);
      }
      if (isAccOut) {
        final derivation = MoneroCrypto.generateKeyDerivation(
            pubkey: txPubKey, secretKey: account.account.privVkey);
        final sharedSec = MoneroCrypto.derivationToScalar(
            derivation: derivation, outIndex: i);
        final mask = RCT.zero();
        final amount = RCTGeneratorUtils.decodeRct_(
            sig: tx.signature.cast(),
            secretKey: sharedSec,
            outputIndex: i,
            mask: mask);
        if (amount == null) continue;
        final out = MoneroLockedOutput(
            amount: amount,
            isRCT: true,
            mask: mask,
            derivation: derivation,
            globalIndex: indices[i],
            outputPublicKey: outPublicKey,
            accountIndex: index);
        outputs.add(_toPayment(
            out: out,
            transaction: tx,
            account: account,
            index: index,
            realIndex: i));
      }
    }
    return outputs.cast<MoneroLockedPayment>().toList();
  }

  MoneroUnLockedPayment? _getUnlockOutputs2(
      {required MoneroTransaction tx,
      required MoneroBaseAccountInfo account,
      required MoneroAccountIndex index,
      required List<BigInt> indices,
      required int outIndex,
      required MoneroTxout out}) {
    final lockedOut = _getLockedOutputs1(
        tx: tx,
        account: account,
        index: index,
        indices: indices,
        i: outIndex,
        out: out);
    if (lockedOut == null) return null;
    return _toUnlockedOutput2(account: account, lockedOut: lockedOut);
  }

  MoneroUnlockedMultisigPayment _toMultisigUnlockedOutput(
      {required MoneroMultisigAccountInfo account,
      required MoneroUnLockedPayment payment,
      required List<MoneroMultisigOutputInfo> multisigInfos}) {
    final MoneroUnlockedOutput unlockedOut = payment.output;
    final multisigAccount = account.multisigAccount;
    if (multisigInfos.map((e) => e.signer).toSet().length !=
        multisigInfos.length) {
      throw const DartMoneroPluginException(
          "Duplicate multisig info provided.");
    }
    final signer = multisigAccount.multisigSignerPubKey;
    for (final i in multisigInfos) {
      if (!multisigAccount.signers.contains(i.signer)) {
        throw const DartMoneroPluginException(
            "Invalid multisig info. signer does not exist.");
      }
    }
    final ownerMultisigInfo = multisigInfos.firstWhere(
        (e) => e.signer == signer,
        orElse: () => multisigAccount.outputMultisigInfo2(payment.output));
    final otherSigners =
        multisigInfos.where((e) => e.signer != signer).toList();

    if (otherSigners.length + 1 < account.multisigAccount.threshold) {
      throw const DartMoneroPluginException(
          "Some multisig output info missing.");
    }
    final multisigKeyImage =
        MoneroMultisigUtils.generateMultisigCompositeKeyImage(
            infos: otherSigners,
            keyImage: unlockedOut.keyImage,
            exclude: ownerMultisigInfo.partialKeyImages.clone());

    final multisigOut = MoneroUnlockedMultisigOutput(
        amount: unlockedOut.amount,
        derivation: unlockedOut.derivation,
        ephemeralSecretKey: unlockedOut.ephemeralSecretKey,
        ephemeralPublicKey: unlockedOut.ephemeralPublicKey,
        multisigKeyImage: multisigKeyImage,
        keyImage: unlockedOut.keyImage,
        mask: unlockedOut.mask,
        outputPublicKey: unlockedOut.outputPublicKey,
        isRCT: unlockedOut.isRCT,
        globalIndex: unlockedOut.globalIndex,
        accountindex: unlockedOut.accountIndex);
    return MoneroUnlockedMultisigPayment(
        output: multisigOut,
        txPubkey: payment.txPubkey,
        paymentId: payment.paymentId,
        encryptedPaymentid: payment.encryptedPaymentid,
        index: payment.index,
        multisigInfos: otherSigners);
  }

  MoneroUnLockedPayment? _toUnlockedOutput2(
      {required MoneroBaseAccountInfo account,
      required MoneroLockedPayment lockedOut}) {
    final out = lockedOut.output;
    final RctKey spendKey = account.getPrivateSpendKey();
    final scalarStep1 = MoneroCrypto.deriveSecretKey(
        derivation: out.derivation,
        outIndex: lockedOut.index,
        privateSpendKey: spendKey);
    MoneroPrivateKey secretKey;
    MoneroPrivateKey? subSecretKey;
    if (out.accountIndex.isSubaddress) {
      subSecretKey = account.getSecretSpendKey(out.accountIndex);
      secretKey = MoneroCrypto.scSecretAdd(a: scalarStep1, b: subSecretKey);
    } else {
      secretKey = scalarStep1;
    }

    final MoneroPrivateKey ephemeralSecretKey = secretKey;
    MoneroPublicKey ephemeralPublicKey;
    if (account.type.isMultisig) {
      ephemeralPublicKey = MoneroCrypto.derivePublicKey(
          derivation: out.derivation,
          outIndex: lockedOut.index,
          basePublicKey: account.account.publicSpendKey);
      print("is multisig!");
      if (out.accountIndex.isSubaddress) {
        final subAddrPk = subSecretKey!.publicKey;
        print("is subbaddr $subAddrPk");
        ephemeralPublicKey =
            MoneroCrypto.addPublicKey(ephemeralPublicKey, subAddrPk);
      }
    } else {
      ephemeralPublicKey = ephemeralSecretKey.publicKey;
    }
    print(out.accountIndex.toJson());
    assert(out.outputPublicKey == ephemeralPublicKey, "should be equal.");
    if (out.outputPublicKey != ephemeralPublicKey) {
      return null;
    }
    final keyImage = MoneroCrypto.generateKeyImage(
        pubkey: ephemeralPublicKey, secretKey: ephemeralSecretKey);
    final outInfo = MoneroUnlockedOutput(
        amount: out.amount,
        derivation: out.derivation,
        ephemeralPublicKey: ephemeralPublicKey.key,
        ephemeralSecretKey: ephemeralSecretKey.key,
        keyImage: keyImage,
        mask: out.mask,
        isRCT: true,
        outputPublicKey: out.outputPublicKey,
        globalIndex: out.globalIndex,
        accountindex: out.accountIndex);
    // outputs.add();
    return MoneroUnLockedPayment(
        output: outInfo,
        txPubkey: lockedOut.txPubkey,
        paymentId: lockedOut.paymentId,
        encryptedPaymentid: lockedOut.encryptedPaymentid,
        index: lockedOut.index);
  }

  // List<AccountIndex> _getIndexes(
  //     {required MoneroBaseAccountInfo account,
  //     List<AccountIndex> accountIndexes = const []}) {
  //   if (accountIndexes.isNotEmpty) return accountIndexes;
  //   return [account.defaultIndex()];
  // }

  MoneroPayment _toPayment(
      {required MoneroOutput out,
      required MoneroTransaction transaction,
      required MoneroBaseAccountInfo account,
      required MoneroAccountIndex index,
      required int realIndex,
      List<MoneroMultisigOutputInfo>? multisigInfos}) {
    final txPubKey = transaction.getTxExtraPubKey();
    final paymentId = transaction.getTxPaymentId();
    List<int>? encryptedPaymentId = transaction.getTxEncryptedPaymentId();
    if (encryptedPaymentId != null) {
      encryptedPaymentId = MoneroTransactionHelper.encryptPaymentId(
          paymentId: encryptedPaymentId,
          pubKey: txPubKey,
          secretKey: account.account.privateViewKey);
    }
    if (out.type == MoneroOutputType.locked) {
      return MoneroLockedPayment(
          output: out as MoneroLockedOutput,
          txPubkey: txPubKey,
          paymentId: paymentId,
          encryptedPaymentid: encryptedPaymentId,
          index: realIndex);
    }
    if (out.type == MoneroOutputType.unlockedMultisig) {
      return MoneroUnlockedMultisigPayment(
          output: out as MoneroUnlockedMultisigOutput,
          txPubkey: txPubKey,
          paymentId: paymentId,
          encryptedPaymentid: encryptedPaymentId,
          index: realIndex,
          multisigInfos: multisigInfos!);
    }
    return MoneroUnLockedPayment(
        output: out as MoneroUnlockedOutput,
        txPubkey: txPubKey,
        paymentId: paymentId,
        encryptedPaymentid: encryptedPaymentId,
        index: realIndex);
  }

  TxDestination _getChange(
      {required List<TxDestination> destinations,
      required MoneroAddress change,
      required BigInt inamount,
      required BigInt fee}) {
    final outAmounts =
        destinations.fold<BigInt>(BigInt.zero, (p, c) => p + c.amount) + fee;

    final changeAmount = inamount - outAmounts;
    if (changeAmount.isNegative) {
      throw const DartMoneroPluginException(
          "output amounts exceed the total input amount and the fee.");
    }
    return TxDestination(amount: inamount - outAmounts, address: change);
  }

  BigInt _calcuateFee(
      {required BigInt weight, required DaemonGetEstimateFeeResponse baseFee}) {
    BigInt fee = weight * baseFee.fees.first;
    fee = (fee + baseFee.quantizationMask - BigInt.one) ~/
        baseFee.quantizationMask *
        baseFee.quantizationMask;
    return fee;
  }
}
