part of 'address.dart';

class MoneroAccountAddress extends MoneroAddress {
  MoneroAccountAddress._(
      {required MoneroPublicKey pubSpendKey,
      required MoneroPublicKey pubViewKey,
      required String address,
      required MoneroNetwork network,
      required XmrAddressType type})
      : super._(
            pubSpendKey: pubSpendKey,
            pubViewKey: pubViewKey,
            address: address,
            network: network,
            type: type);

  factory MoneroAccountAddress(String address,
      {MoneroNetwork? network, XmrAddressType? type}) {
    final decode = XmrAddrDecoder().decode(address);
    if (decode.type == XmrAddressType.integrated) {
      throw const DartMoneroPluginException(
          "Use `MoneroIntegratedAddress` for creating a MoneroAccount address.");
    }
    if (type != null && decode.type != type) {
      throw DartMoneroPluginException("Invalid address type.", details: {
        "excepted": type.toString(),
        "type": decode.type.toString()
      });
    }
    final addrNetwork = MoneroNetwork.findNetwork(decode.type);
    if (network != null && addrNetwork != network) {
      throw DartMoneroPluginException("Invalid address network.", details: {
        "excepted": network.toString(),
        "type": addrNetwork.toString()
      });
    }
    return MoneroAccountAddress._(
        pubSpendKey: MoneroPublicKey.fromBytes(decode.publicSpendKey),
        pubViewKey: MoneroPublicKey.fromBytes(decode.publicViewKey),
        address: address,
        network: addrNetwork,
        type: decode.type);
  }

  factory MoneroAccountAddress.fromPubKeys({
    required List<int> pubSpendKey,
    required List<int> pubViewKey,
    MoneroNetwork network = MoneroNetwork.mainnet,
    XmrAddressType type = XmrAddressType.primaryAddress,
  }) {
    if (type == XmrAddressType.integrated) {
      throw const DartMoneroPluginException(
          "Use `MoneroIntegratedAddress` for creating a MoneroAccount address.");
    }
    final encode = XmrAddrEncoder().encode(
        pubSpendKey: pubSpendKey,
        pubViewKey: pubViewKey,
        netVarBytes: network.findPrefix(type));
    return MoneroAccountAddress._(
        pubSpendKey: MoneroPublicKey.fromBytes(pubSpendKey),
        pubViewKey: MoneroPublicKey.fromBytes(pubViewKey),
        address: encode,
        network: network,
        type: type);
  }
  bool get isSubAddress => type == XmrAddressType.subaddress;
}
