import 'package:blockchain_utils/helper/helper.dart';
import 'package:blockchain_utils/layout/layout.dart';
import 'package:monero_dart/src/models/block/header.dart';
import 'package:monero_dart/src/models/transaction/transaction/transaction.dart';
import 'package:monero_dart/src/serialization/layout/constant/const.dart';

class MoneroBlock extends MoneroBlockheader {
  final MoneroTransaction minerTx;
  final List<List<int>> txHashes;
  MoneroBlock(
      {required int majorVersion,
      required int minorVersion,
      required BigInt timestamp,
      required List<int> hash,
      required int nonce,
      required this.minerTx,
      required List<List<int>> txHashes})
      : txHashes = txHashes.map((e) => e.asImmutableBytes).toList().immutable,
        super(
            majorVersion: majorVersion,
            minorVersion: minorVersion,
            timestamp: timestamp,
            hash: hash,
            nonce: nonce);
  static Layout layout({String? property}) {
    return LayoutConst.struct([
      MoneroLayoutConst.varintInt(property: "majorVersion"),
      MoneroLayoutConst.varintInt(property: "minorVersion"),
      MoneroLayoutConst.varintBigInt(property: "timestamp"),
      LayoutConst.fixedBlob32(property: "hash"),
      LayoutConst.u32(property: "nonce"),
      MoneroTransaction.layout(property: "minerTx", forcePrunable: false),
      MoneroLayoutConst.variantVec(LayoutConst.fixedBlob32(),
          property: "txHashes"),
    ]);
  }
}
