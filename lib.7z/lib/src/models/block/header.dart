import 'package:blockchain_utils/blockchain_utils.dart';

abstract class MoneroBlockheader {
  final int majorVersion;
  final int minorVersion;
  final BigInt timestamp;
  final List<int> hash;
  final int nonce;
  MoneroBlockheader({
    required this.majorVersion,
    required this.minorVersion,
    required BigInt timestamp,
    required List<int> hash,
    required int nonce,
  })  : timestamp = timestamp.asUint64,
        hash = hash.asImmutableBytes,
        nonce = nonce.asUint32;
}
