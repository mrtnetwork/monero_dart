import 'package:blockchain_utils/bip/address/xmr_addr.dart';
import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:monero_dart/src/address/address/address.dart';
import 'package:monero_dart/src/api/models/models.dart';
import 'package:monero_dart/src/crypto/multisig/account/account.dart';
import 'package:monero_dart/src/crypto/multisig/core/account.dart';
import 'package:monero_dart/src/crypto/ringct/utils/rct_crypto.dart';
import 'package:monero_dart/src/crypto/types/types.dart';
import 'package:monero_dart/src/exception/exception.dart';
import 'package:monero_dart/src/helper/extension.dart';
import 'package:monero_dart/src/network/network.dart';
import 'package:monero_dart/src/serialization/layout/layout.dart';

class MoneroAccountInfoType {
  final String name;
  final int value;
  const MoneroAccountInfoType._({required this.name, required this.value});
  static const MoneroAccountInfoType simple =
      MoneroAccountInfoType._(name: "Simple", value: 0);
  static const MoneroAccountInfoType multisig =
      MoneroAccountInfoType._(name: "Multisig", value: 1);
  static const List<MoneroAccountInfoType> values = [simple, multisig];
  static MoneroAccountInfoType fromName(String? name) {
    return values.firstWhere((e) => e.name == name,
        orElse: () => throw DartMoneroPluginException(
            "Invalod account info type.",
            details: {"name": name}));
  }

  bool get isMultisig => this == MoneroAccountInfoType.multisig;

  @override
  String toString() {
    return "MoneroAccountInfoType.$name";
  }
}

abstract class MoneroBaseAccountInfo extends MoneroVariantSerialization {
  final MoneroNetwork network;
  List<MoneroAccountIndex> indexes;
  final MoneroAccountInfoType type;
  final MoneroAccount account;
  MoneroBaseAccountInfo._(
      {required this.network,
      required List<MoneroAccountIndex> indexes,
      required this.type,
      required this.account})
      : indexes = indexes.toImutableList;

  factory MoneroBaseAccountInfo.fromStruct(Map<String, dynamic> json) {
    final decode = MoneroVariantSerialization.toVariantDecodeResult(json);
    final type = MoneroAccountInfoType.fromName(decode.variantName);
    switch (type) {
      case MoneroAccountInfoType.multisig:
        return MoneroMultisigAccountInfo.fromStruct(decode.value);
      case MoneroAccountInfoType.simple:
        return MoneroAccountInfo.fromStruct(decode.value);
      default:
        throw const DartMoneroPluginException("Invalod account info type.");
    }
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.lazyEnum([
      LazyVariantModel(
          layout: MoneroAccountInfo.layout,
          property: MoneroAccountInfoType.simple.name,
          index: MoneroAccountInfoType.simple.value),
      LazyVariantModel(
          layout: MoneroMultisigAccountInfo.layout,
          property: MoneroAccountInfoType.multisig.name,
          index: MoneroAccountInfoType.multisig.value),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createVariantLayout({String? property}) {
    return layout(property: property);
  }

  MoneroBaseAccountInfo addIndex({int minor = 1, int major = 0}) {
    final index = MoneroAccountIndex(major: major, minor: minor);
    if (indexes.contains(index)) {
      throw const DartMoneroPluginException("Cccount index already exist.");
    }
    return MoneroAccountInfo(
        account: account, indexes: [...indexes, index], network: network);
  }

  RctKey getPrivateSpendKey() {
    return account.privSkey!.key;
  }

  MoneroPrivateKey getSecretSpendKey(MoneroAccountIndex index) {
    if (!indexes.contains(index)) {
      throw const DartMoneroPluginException("Index does not exists.");
    }
    final keys = account.scubaddr.computeKeys(index.minor, index.major);
    return keys.privateKey;
  }

  MoneroPublicKey getSpendPublicKey(MoneroAccountIndex index) {
    if (!indexes.contains(index)) {
      throw const DartMoneroPluginException("Index does not exists.");
    }
    if (!index.isSubaddress) {
      return account.pubSkey;
    }
    final keys = account.scubaddr.computeKeys(index.minor, index.major);
    return keys.pubSKey;
  }

  MoneroAddress integratedAddress(List<int> paymentId) {
    return MoneroIntegratedAddress.fromPubKeys(
        pubSpendKey: account.pubSkey.key,
        pubViewKey: account.pubVkey.key,
        paymentId: paymentId,
        network: network);
  }

  MoneroAddress primaryAddress() {
    return MoneroAccountAddress.fromPubKeys(
        pubSpendKey: account.pubSkey.key,
        pubViewKey: account.pubVkey.key,
        network: network);
  }

  MoneroBaseAccountInfo removeIndex(MoneroAccountIndex index) {
    final rIndex = indexes.remove(index);
    if (!rIndex) {
      throw const DartMoneroPluginException("Index does not exists.");
    }
    return MoneroAccountInfo(
        account: account, indexes: indexes, network: network);
  }

  MoneroAddress subAddress(MoneroAccountIndex index) {
    final keys = account.scubaddr.computeKeys(index.minor, index.major);
    return MoneroAccountAddress.fromPubKeys(
        pubSpendKey: keys.pubSKey.key,
        pubViewKey: keys.pubVKey.key,
        network: network,
        type: XmrAddressType.subaddress);
  }

  @override
  String get variantName => type.name;

  @override
  String toString() {
    return indexes
        .map((e) {
          return {
            "type": type.name,
            ...e.toJson(),
            "address": e.isSubaddress
                ? subAddress(e).address
                : primaryAddress().address
          };
        })
        .toList()
        .toString();
  }
}

class MoneroAccountInfo extends MoneroBaseAccountInfo {
  MoneroAccountInfo._(
      {required MoneroAccount account,
      required List<MoneroAccountIndex> indexes,
      required MoneroNetwork network})
      : super._(
            network: network,
            indexes: indexes,
            type: MoneroAccountInfoType.simple,
            account: account);
  factory MoneroAccountInfo(
      {required MoneroAccount account,
      List<MoneroAccountIndex> indexes = const [
        MoneroAccountIndex.primary,
        MoneroAccountIndex.minor1
      ],
      required MoneroNetwork network}) {
    if (indexes.isEmpty) {
      throw const DartMoneroPluginException("Indexes must not be empty");
    }
    if (indexes.toSet().length != indexes.length) {
      throw const DartMoneroPluginException("Duplicate indexes find.");
    }
    return MoneroAccountInfo._(
        account: account, indexes: indexes, network: network);
  }
  factory MoneroAccountInfo.fromStruct(Map<String, dynamic> json) {
    final List<int>? privSkey = json.asBytes("privSkey");
    final MoneroPrivateKey privVkey =
        MoneroPrivateKey.fromBytes(json.asBytes("privVkey"));
    final MoneroPublicKey pubSkey =
        MoneroPublicKey.fromBytes(json.asBytes("pubSkey"));
    MoneroAccount account;
    if (privSkey != null) {
      account = MoneroAccount.fromPrivateSpendKey(privSkey);
    } else {
      account = MoneroAccount.fromWatchOnly(privVkey.key, pubSkey.key);
    }
    if (account.privVkey != privVkey || account.pubSkey != pubSkey) {
      throw const DartMoneroPluginException("Account verification failed.");
    }
    return MoneroAccountInfo(
        account: account,
        indexes: json
            .asListOfMap("indexes")!
            .map((e) => MoneroAccountIndex.fromStruct(e))
            .toList(),
        network: MoneroNetwork.fromName(json.as("network")));
  }
  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      MoneroLayoutConst.variantString(property: "network"),
      LayoutConst.optional(LayoutConst.fixedBlob32(), property: "privSkey"),
      LayoutConst.fixedBlob32(property: "privVkey"),
      LayoutConst.fixedBlob32(property: "pubSkey"),
      MoneroLayoutConst.variantVec(MoneroAccountIndex.layout(),
          property: "indexes"),
    ], property: property);
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "network": network.name,
      "privSkey": account.privSkey?.key,
      "privVkey": account.privVkey.key,
      "pubSkey": account.pubVkey.key,
      "indexes": indexes.map((e) => e.toLayoutStruct()).toList()
    };
  }
}

class MoneroMultisigAccountInfo extends MoneroBaseAccountInfo {
  final MoneroMultisigAccount multisigAccount;
  MoneroMultisigAccountInfo._(
      {required this.multisigAccount,
      required List<MoneroAccountIndex> indexes,
      MoneroNetwork network = MoneroNetwork.mainnet})
      : super._(
            network: network,
            indexes: indexes,
            type: MoneroAccountInfoType.multisig,
            account: multisigAccount.toAccount());
  factory MoneroMultisigAccountInfo(
      {required MoneroMultisigAccount multisigAccount,
      List<MoneroAccountIndex> indexes = const [
        MoneroAccountIndex.primary,
        MoneroAccountIndex.minor1
      ],
      MoneroNetwork network = MoneroNetwork.mainnet}) {
    if (indexes.isEmpty) {
      throw const DartMoneroPluginException("Indexes must not be empty");
    }
    if (indexes.toSet().length != indexes.length) {
      throw const DartMoneroPluginException("Duplicate indexes find.");
    }
    return MoneroMultisigAccountInfo._(
        multisigAccount: multisigAccount, indexes: indexes, network: network);
  }
  factory MoneroMultisigAccountInfo.fromStruct(Map<String, dynamic> json) {
    return MoneroMultisigAccountInfo(
        multisigAccount:
            MoneroMultisigAccount.fromStruct(json.asMap("account")),
        indexes: json
            .asListOfMap("indexes")!
            .map((e) => MoneroAccountIndex.fromStruct(e))
            .toList(),
        network: MoneroNetwork.fromName(json.as("network")));
  }

  static Layout<Map<String, dynamic>> layout({String? property}) {
    return LayoutConst.struct([
      MoneroLayoutConst.variantString(property: "network"),
      MoneroMultisigAccountCore.layout(property: "account"),
      MoneroLayoutConst.variantVec(MoneroAccountIndex.layout(),
          property: "indexes"),
    ], property: property);
  }

  @override
  RctKey getPrivateSpendKey() {
    final spendKey = RCT.zero();
    for (final i in multisigAccount.multisigPrivateKeys) {
      CryptoOps.scAdd(spendKey, i.key, spendKey);
    }
    return spendKey;
  }

  @override
  Layout<Map<String, dynamic>> createLayout({String? property}) {
    return layout(property: property);
  }

  @override
  Map<String, dynamic> toLayoutStruct() {
    return {
      "network": network.name,
      "account": multisigAccount.toLayoutStruct(),
      "indexes": indexes.map((e) => e.toLayoutStruct()).toList()
    };
  }
}
